/* global StatusBar, success, error */
var db = null;
var BaseUrl = 'http://www.abanpet.com';
var mobileNumber = null;
var Logined;
var flagReadMessage = false;
var isOnline = false;
var oneRun = false;
var objectJson;
var idGallery = null;

var imageProfileDefualt = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAACXBIWXMAARCQAAEQkAGJrNK4AAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAIjFJREFUeNrs3Xncbfdg7/HPOSdzYky2lBIZSFCzoMZWVVtBDTXcW2pohVI1NOWqVmuoKlpVHa6iah4aQ2smaM1BECFxCSFJ0XoEiSDTyXP/WDvt6elJcoZn2Huv9/v12q/DiTbP892/tdZ3/dZav7VheXk5AGBcNooAABQAAGAEdhPBrllaWhIC6+0K1aHTz0HT/77vdn6qfridnx9UZ1anTT/niH59TSYTIaAAwALbVF1ri4P8JZ9Dpn8esKvHkZ38vztrWgS+tkUpuORzZnWRrw4UAGD7HVrdtrrN9M8bzui2uv/0c8tt/LOLqlOqj1cfm/55qq8WZscGTwHsGpcA2EV7VUducbC/TXXggv6u39mqEHyq+pEhsPNcAkABUACYH7tXd6ruOj3g32z6d2N0UfW5aSF4T/W+6nxDRAFAAVAAWBR7Vr9Q/Ur1y9VVRLJN51Rvr95UvdvsgAKAAqAAMI/2qY6aHvTv1nBnPtvvR9W7pmXg7Q1PIKAAoAAoAMykK1b3mB70f6naWyQr4vzquGkZ+OfqeyJRAFAAFABmwfWrx1W/Nj3zZ3XLwOuqv6xOVAAUAHaelQBhJ8vz9Cz/3dXJ1SMd/NfEntVDq89W/1rd234MFABYC/tWj2p4xv1d1S9OywBr72eqN1dfqX6nupJIYAfOYlwC2DUuAYzGQdVvVUfnLv5ZdW718uqFjWTRIZcAMAMAq+c6DdecT6ue5OA/0/arHlN9qXpbdWORgAIAO+oq1fMbru//r4b1+JkPG6q7N9wn8NLqJ0QCCgBcnt0b7uj/SvWEag+RzPX+7TcaLgc8NY9lggIAl+Je0zP+F1RXFcfC2K96RvXl6sG5aRMUAJi6RfXB6i3VdcWxsK5ZvaI6oeEJAlAAYKSuXr2y4a10dxTHaNy8YQ2Bf6oOEwcKAIzLfarPN6zeZ0p4nO7Z8DbCh4sCBQAW337V3zesK7+/OEZv3+olDZd/DhAHCgAspls3PBr266JgK/eqTmpY2REUAFgQm6o/rD7SsLAPbMvVG5Z3fmG1lzhQAGC+HVJ9qHp6tZs4uBwbqt+uPl3dVBwoADCfHtxwk9dtRcEOukH1iep3c5MoCgDMjU3Vixue+b6CONhJe1TPq97acLMgKAAww/ad7rCPFgUr5O4N6wYcKAoUAJhNBzas6HeUKFhhR1bHV9cTBQoAzJbrTXfQtxAFq+Tg6qPVHUSBAgCz4Q7THfPBomCVXbU6rnqAKFAAYH3db7pD9vY+1sqe1euqJ4oCBQDWxzHVG6Y7ZFhLG6rnVn/T8NQJKACwRp5T/Vme0WZ9Pbr6RyUABQDWxu9VTxIDM+I+1UuVURQAWF1HV38iBmbMQxsWDQIFAFbBr1QvEgMz6pjqyWJAAYCVdefqNcYsM+7Z1cPFgAIAK+PI6p9ytz/z4UUN9wWAAgC74IiGd7TvJwrmxKbqtdXPiQIFAHbONav3VgeIgjmzZ8Os1ZGiQAGAHXPl6cH/IFEwp67QMHt1HVGgAMD2e2l1fTEw5w5oWCjI/SsoALAdHtXwyB8sgps1rFoJCgBchhtXzxcDC+YxeTIABQAu1b4NL/fZSxQsoL/PK6tRAGCb/qa6nhhYUFeuXl/tLgoUAPgvD6oeIgYW3K3zLgsUAPhPh1f/VwyMxDHVUWJAAWDs9myYFrXSH2OxoXpF9ZOiQAFgzJ7b8JgUjMkBDcsF2wejADBKt6x+WwyM1B2ro8WAAsDYbKheOP0TxupZ1VXEgALAmPxa9dNiYOT2r54pBhQAxmK/6k/FAFX9ZsMKmKAAsPD+oLq6GKCqTdVfiQEFgEV3neoJYoD/5o7V/xIDCgCL7C+qPcQA/8PzGt6HAQoAC+eXqruLAbbpmtVTxIACwKLZvXqBGOAyHVMdJgYUABbJY6sjxACXac+Gy2SgALAQ9q6eLAbYLveojhQDCgCL4CENa58D2+d3RYACwCKMsd8RA+yQ+1bXFgMKAPPsHtV1xQA7ZFP1eDGgADDPTGXCznl4dWUxoAAwj25d3V4MsFP2qx4pBhQA5tExIoBd8tiGNTRAAWBuHFLdRwywS65R/W8xoAAwT57QcCMTsGvMpKEAMDeuUv26GGBF3Lj6BTGgADAPfjNvNQOzACgAjM5viABW1F2qg8SAAsAsu1neZgYrbUN1PzGgADDL7KTAtoUCgJ0UsEJunfcDoAAwo25aXUcMsGruKwIUAJz9w/jcXwQoACgAMD63ymUAFABmzE3y2l9QtFEAsFMCbGsoANgpASvjVtXBYkABYBbcqDpcDKBwowBgZwTY5lAAWHDeVAZr68jqqmJAAWA97V3dXAywpjZUtxEDCgDrfSayuxhgzd1WBCgArKfbiQAUAObPbiLATgjm0q2WlpZ2qy4aawCTycQoMAOAAgCjs0/DC7hAAWDNHVHtLwZQwFEAsPMBbIMoACw4NwCCAoACgJ0PsMauNf2AAsCauWp1PTGAIo4CwLjcpmE1MkABQAHATgewLaIAsMhuIAKwLaIAMD6HiABmwj7VgWJAAWCtHCoCsD2iADAu+1dXEAMoACgA2NkA68clORQAFACwTYICgLMNUABAAcDOBpRyUACws4HFcM1qDzGgAGAGAMa3L7+2GFAAWE2bqoPEADPHzBwKAKvqWtVuYoCZY2YOBQA7GbBtggLAyjpYBGDbRAFgfK4kArBtogAwPvuIAGbSviJAAUABAAUAFADsZMC2CQoAZgDAtokCIALsZMAMAAoAKACgAKAAgJ0MzIndpx9QADADAAo6KAAoAKAAgAKAHQzYPlEAwAwAKAAoAKAAgO0TBQCcYYDtEwWAUdtDBDCz9hQBCgCr5QIRgO0TBYDxOV8EYPtEAcAOBpgd54kABQA7GFDQQQHADgZsn6AAYAcDtk8UANgBLgGA7RMFAGcYgO0TBQA7GMD2iQLAQvqhCGAmLVc/EgMKAKtlSQQwk86qNosBBQAFAMbl2yJAAUABANsmKADYyYAZAFAAUABAAUABEAEKACgAKACgAIACgAIACgAoACgAMCw0YrERUABQABihb4oAZs6/iQAFgNX2FRHATLmgOkMMKACstq+KAGbK16qLxYACgBkAsE2CAoCdDdgmQQHAzgZskygAImAnuN4Is8V9OSgArInz88gRmAFAAcAOB1g3m6uviwEFAAUAxuX06kIxoACwVk4RAcyEL4gABYC1dKIIYCZ8RgQoAKylz4kAZsJnRYACwFr6fm48AgUABQA7HmDNnVWdKQYUANbaiSIAJRwFAAUAWFtuAEQBQAEAMwCgALA2zqi+KwZQAFAAMAsArI0fVKeKAQWA9fJBEcC6bXveyokCwLo5TgSwLt4nAhQA1tOnqnPEAMo3CgDjclH1L2KANfXNvJALBQBnIjA6pv9RALAzAqUbFADWx5eyHjmspfeLAAUAZyQwLl+oviUGFABmhcsAYFtDAWCkO6VlMcCqM9uGAsBMWao+JwZYVRdm9U0UAGZ0FgBYPR+vfigGFABmjalJsI2hADBCH67OFwOsGrNsKADMpB9XHxUDrIqzG969AQoAM8kUJayOD1SbxYACgAIA42L6HwWAmfbZ6iwxgHKNAsC4XNwwVQmsnNOrU8WAAsCse7MIYEW9XgQoAMyDf67OEQOsmFeKAAWAefDj6lgxwIo4oTpFDCgAOGOBcXmFCFAAmCcfrr4uBtglF1SvEwMKAPNkuXqVGGCXvCOP1aIAMIdcBoBdY/ofBYC59JWG15cCO+471TvFgAKAWQAYl9dWF4oBBYB59Ya8IhiUZxQARud71dvEADvk5OrTYkABwJkMjIub/1AAWAjvqpbEANtlc/VqMaAAsAguymImsL2Oq74lBhQAFoXLALB9TP+jALBQPp0XmsDlObvhbZqgAGAWAEbk2Ia3aYICwEJ5dXWxGOBSmf5HAWAhfaN6rxhgm06uPiIGFAAW1XNFANv0bBGgALDI/qU6Xgzw33yter0YUABwpgPj8tyGBYBAAWChva36ghigGhb9+QcxoAAwBstmAeA/PT9vzEQBYETeUJ0mBkbuu9WLxIACwJhsrp4jBkbur6pzxYACwNi8ovqmGBipc6sXigEFgDE6v+H6J4zR3zVcAgAFADtBUH5BAWAcTIMyRi5/oQBAboRiXNwAiwIAUx6FYkw8AosCAFuwGApjYBEsFADYiuVQGQPLYKMAwDZ4IQqLztk/CgBsg1eissg+kFdhowDApXp6dYEYWDAXV08UAwoAXLpTq78QAwvmJdVnxMAs2bC8vCyFXbC0tCSElbdf9aXqGqJgAXy3Orw6SxQrazKZCMEMAAvm3EyXsjie6uCPAgDb77XVR8TAnPtcw/suQAGAHfDbeSwQYxgUAEbnxOrFYmBOvbb6sBhQAGDn/EGunzJ/3MeCAgC76LvTEgDz5Jl53S8KAOyyF1efFQNz4svVC8SAAgC77uKGm6lgHjwuq1miAMCK+Wj1ajEw495avVsMKACwsp7UcHMVzKLzqieIAQUAVt63Gm6ugln0vOo0MTAvvAtgF3kXwJrbo/p8w9rqMCvOqK5f/UgUa8e7AMwAMC4XNNxkBbPkGAd/FABYfe+u3iIGZsTbqzeKAQUA1sYjGu4JgPX079WviwEFANbOd6oHV25iYb0sT8egG4FQAGCNva/6czGwTp5fHScGFABYH0+pPi0G1thnpmMPFABYJxdWv1r9UBSskR9Ox5zlflEAYJ19uXqsGFgjj6++JAYUAJgNL6uOFQOr7E3VS8WAAgCz5RENK7LBajizOloMKAAwe75fPajaLApW2MXTsfU9UaAAwGz6cPUnYmCFPbv6kBhQAGC2Pb36mBhYIcdXTxMDCgDMvs3VA6uzRcEu+sF0LF0kChQAmA9frx4lBnbRo6vTxIACAPPlddUrxcBOek31ajGgAMB8ekwWbWHHfT4zSCgAMNd+UB1VfVsUbKdvTMfMD0SBAgDz7bTqbnlfAJfvnOnB/99EgQIAi+GE6gFZJIhLd2F13+okUaAAwGJ5R67rcukeUR0nBhQAWEwvqf5YDGzladXLxYACAIvtqdUrxMDUyxtWjwQFAEbg6Oq9Yhi94xqm/kEBgJG45IavE0UxWidNx8CFokABgHG5ZI2AM0QxOv82/e7PEQUKAIzTt6q75j3vY3LJs/7fEAUKAIzbKdW9qvNFsfAurO7TsNQvKABAH6oeXC2LYqE9vHq/GEABgC39Y/VEMSysl+XtkKAAwKX48+rrYlhI7xABKABwWd4kgoVzYfU+MYACAJflWBEsnI/mkT9QAOByfLI6UwwL5Z0iAAUALs9y9UYxKACgAMD4KACL44zqZDGAAgDb4xPVuWJYCG7+AwUAttvmhnsBWIwyBygAsN0+LoKFoMiBAgA75HgRzL0fV18QAygAoACMy2eqi8QACgDsiO9kWeB59ykRgAIAO8OCQPM/AwAoALDDviGCufZ1EYACAArA+JwuAlAAQAEYl82+P1AAYGf9hwjmurxtFgMoALAzlkUwt0z/gwIAtpEROlsEYOcGtpHxuUAEYOcGtpHxOV8EYOcGO+sqIjADAAoAjM+hIphbF4oAFABQAMbnQBGAAgA76zAR+O5AAYBx2ccMwFw7pNogBlAAYEfdodpDDHNr7+onxAAKAOyonxfB3HMZABQA2GF3EcHccwkHFADYITetbiIGBQAUABiX/yOCheASACgAsENnjfcTw0K4S7WbGEABgO3xxGqTGBbCgdXdxAAKAGzPAeOhYlgovy4CUADg8jyu2ksMC+WorAcACgBchoOr3xLDwtmterAYQAGAbdmrenN1RVEsJJcBQAGAbXpRdTMxLKwjzAKAAgBbe3T1EDEsvL+qri0GUACg6jbVC8QwClesXmm/BwoA3Lz6p2p3UYzGHRvWeQAFQASM1C9WH6yuJorReUZ1OzGgAMD4PKR6e7WfKEZpj+q91V1FgQIA4xnvT61envXhx26f6q3Vg0SBAgCL7SbVxxumf6FpCXxl9ft59wMKACzkmd5zqhOqW4mDrWyo/rj6VHVLcaAAwPzbv2G6/+vVkzLlz2W7WXV89bKG2SJY/Pa7vLwshV2wtLQkhNlyu+rh1f2nZ/+wMz5Rvap6fXWWOGbTZDIRggKgAIzcAQ3LvD68ur44WEEXVu+aloG3VeeLRAFQAFAA1nnsVneujq7u1fBoF6ym71fHTsvARyo7TwVAAVAAWEPXqB5W/UZ1iDhYJ1+vXj39fEkcCoACoACwOjZVR03P9o/KI1vMlk9OZwXeUNkhKAAKgALACjhkeqb/sOmZP8yyi6p3T8vAW6vzRKIAKAAKANtvj+reDTf03bnhWj/Mm7OrN07LwIdyv4ACoAAoAFyq6zdM8f9aw139sChOr14zLQP/TxwKgAKgADA8p3//6dm+t7MxBif0X+sLfFscCoACoACMzc2nZ/u/Wl1RHIzQRdV7qr9vuF9gs0gUgLVmKWDWrGxWd68+WH26+k0Hf0Zst+pu1Zurr1ZPrK4iFhQAFsmeDVP8JzespHZHkcB/c+3qudW/VX9X/ZRIUACYZ1dteM3q6dVLskQvXJ59qkdUX6jeX93TPhoFgHlySPXC6oyG16weKBLYYT9X/VP1lep3qiuLBAWAWXVkw0pop1a/Xe0rEliRQv3nDZcH/jYzaSgAzIgNDTcy/Wv1qYZH+izTCytv3+pR1SnVe6fbnUWyUABYc3s2LNF7cvX26mdEAmvmLtPt7svV4/I0DQoAa+Aq1VMa3oT20kxHwnq6TvWChssDf1UdLhIUAFbawdVfVmdWz6p+QiQwM65QPaZhmeF3Vr+UywMoAOyiIxuWLP1K9djc2AezbEN11+pd0zLwmGo/saAAsCM7kbtV/9JwY98DcmMfzJvDGy4LfKPhMsG1RYICwGW5d3VSww1GPysOmHtXbLhR8NSG+3YOEwkKAFu6U3V8w7rkNxQHLJzdG57c+VLD2wivJxIUgHG7ecMbyT5Q3VocsPA2VQ9qeIT3DdWNRaIAMC6HTzf+E6pfEAeMct9//+rEhiWHbyESBYDF9pPVi6ft//55VAjGbkPDS4dOaHiE8DYiUQBYLFdteN3oqdXRDe8iB9jSXauPVe/La7sVAObevg0r951WPbHaWyTA5bhz9cHpjMBNxaEAMF92rx7dsIDPs6oriQTYiRmBz1SvqQ4VhwLAbNtQPbBhFbC/yZK9wK7vU351uk/56+pAkSgAzJ67NdzR+2ptHVhhu1e/VX21embeQKgAMBNuV324YfU+z/QCq2nf6g8a7it6QsOrwVEAWGM3rt5WfaS6vTiANbR/9fzqy9VDHUsUANbGIQ3T/J+t7i4OYB0dVP1D9bnq58ShALA69q6eUX2x4UY/3x0wK25Yvb86dloKUABYIfesTqmemmtuwOy6b8MTA39Y7SUOBYCdd1j1joa1ug8WBzAH9q6e3jBbeR9xKADsmL2mG9DJ1VHiAObQwdWbquOqG4hDAeDy3aNhuv8PM90PzL+fb7hJ8C+yKqkCwDYd2vBY31sb7vQHWBS7VY9veGzwN/ImUgWAqvao/qhhut9jfcAiu1r10upD1RHiUADG7JYNL9t4Wu6YBcbj9g2XBZ6S15MrACOzZ/Wn1cernxIHMNL94LOqE6pbiEMBGIOfbnhpz/+pNokDGLmbVJ+ontfwCCEKwMLZu/qz6qPV9cQB8J82Vb9bfb66kzgUgEVyu+lZ/zEyB7hUh1UfqF6SRwYVgDm3T/WChjteDxcHwHZ5eMNKgvcShQIwj+5QnVQ9Ts4AO+zq1Vuql1X7ikMBmJdM/6j6l4bpLAB23sMaHpe+uSgUgFl2jYZXYj4td/gDrJTDGx6bPiarCCoAM+iohoUtflYUACtuj4Ynqd5dHSgOBWAW7D4dlG+vDhAHwKr6hYb7q+4qil2zYXl5WQo7aWlp6ZDqDQ1L+gKwdparv6yePJlMzhfHCAvA0tLSev2r71+9OM+qAqynE6v/Xf2/tf4XTyaTuQ7OJYAdt3f1d9Mzfwd/gPV10+rT1f1EoQCspmtWH6keIQqAmbHP9KTsGXlKQAFYBbeuPpVnUQFm0YbqqdWbsnCQArCCHlj9a/UTogCYafeuPlYdLAoFYFcb5bOrV1d7iQNgLty4Ycb2jqJQAHbGfg3rUD9ZFABz54DqfdUjRaEA7IhrN0wh3VMUAHNr9+pF1V9Xu4lDAbg8t2+YOrqRKAAWwm9V782j2wrAZXhgw8t8JqIAWCh3anhLqyXbFYD/4ejqlQ0vnABg8dys+mB1dVEoAJd4bMPqfvIAWGw3qD7ccK+XAjByT254oYTVowDG4bBpCbiuAjBez2h4zh+AcbnWtATcUAEYnz9rWDYSgHE6sOGegCMVgHHYUP1tdYyxDzB6V214+uv2CsDi/74vqx5lzAMwdcXqPdVtFYDF9X+rhxrrAGxln+qt1eEKwOJ5SvUIYxyAS7F/9a7qagrA4nhg9cfGNgCX49Dq7dW+CsD8+9mG6/6e8wdge9yyen21SQGYXzdoeKWv5X0B2BF3r/5GAZhPV6/eWV3ZOAZgJzyy+j0FYL7s13AN59rGLwC74FnVgxSA+bCp+sfq5sYtALtoQ/X31U0VgNn35OquxiwAK2SP6tXVngrA7Dqy+iNjFYAV9lMt2MvjFqkA7DNtaLsbpwCsgsdXd1IAZs/zqiOMTwBWyYbq5dWVFIDZcVT1aGMTgFV2UPXXCsBsOKBhpT8AWAsPqu6rAKy/l1YHGo8ArKEXLS0tXV0BWCdLS0sPq+5pHAKwxvZvuPdsbm1YXl6e14P/3tVXG5b8BYC1dnF1o8lkcooZgLX1aAd/ANb5GDq3a8/M5QzA0tLSftVp1cT4A2AdLVc3nUwmJ5kBWBuPc/AHYBZOpKunmQFYm7P/K1dfy2t+AZgdt5hMJp8xA7C6jnHwB2DGPN0MwOqe/R8wPfvfz1gDYMbcejKZfNIMwOqd/Tv4AzCLfscMwOrNAJzesA4zAMyac6sDJpPJ+WYAVvbgf6SDPwAzbL/qLvPyw87TJYBfMbYAmHH3VgBW3n2MKwBm3C8vLS1tUgBWyNLS0k9VhxtXAMy4A6o7KAArx/Q/APNiLi4DzEsBMP0PgAKwgmb+McClpaVrVWcYTwDMkRtMJpMvmgHYNdc1jgCYMzP/2Po8FIBrGkcAzJmfVAAUAADGZ+aPXQoAAJgBUAAAwAyAEAHADMA6uZZxBIACsLJmeh2ApaWl3aoLjSMA5tDuk8nkIjMAO2c34weAOTXTx7CNvh8AGB8FAAAUAABAAQAAFAAAQAEAABQAAEABAAAUAABAAQAAFAAAQAEAABQAAEABAAAWvABs9hUBMKdm+hg20wVgMplcWJ1nDAEwZ86bHsMUgF3wPeMIgDkz88eueSgA3zeOAJgzM3/sMgMAAGYAhAgACsBsONU4AmDOzPyxax4KwOeMIwDmzMwfu+ahAJxoHAEwZ2b+2DUPBeCU6kJjCYA5ceH02KUA7IrJZHJB9UXjCYA58cXpsUsBWAHvNZ4AmBPHzcMPOS8F4FjjCYA58UYFYIVMJpNPVqcbUwDMuG9Un1AARtioABi1N08mk2UFYGX9o3EFwIybm0vWG5aXl+cm1aWlpY9WtzW+AJhBn5lMJreYlx9245yF+yfGFwAz6jnz9MPO1QzAdBbgxOomxhkAM+Qr1RGTyeRiMwCr59nGGQAz5nnzdPCf1wJwbPVZYw2AGXFq9Yp5+6HnrgBMG9bR1WZjDoAZ8KjJZHK+ArA2JeDT1QuNOQDW2asmk8n75/EH3zjHoT81qwMCsH6+Wx0zrz/83BaAyWTyw+qR1bIxCMA6ePxkMllSANanBLynepoxCMAa+7vJZPKqef4FNi7Al/DM6i3GIgBr5GPVY+f9l1iEArBcPbg62ZgEYJV9s/qV6gIFYDacW92zWjI2AVglP54e/P99EX6ZjQv0xXy1unP1HWMUgBV23vRE8/hF+YU2LtgX9Pnq56uzjFUAVsgF0zP/4xbpl9q4gF/U56Yl4LvGLAC76MLq/tU7F+0X27igX9iJ0xLwH8YuADvpvOoB1T8v4i+3cYG/uM9Wt6pOMoYB2EHfru7UAj9mvnHBv8AzqttVbzOWAdhOX5ieQB6/yL/kxhF8kedW96r+3JgG4HK8a3riuPDvmtk4ki/04up3q/s1TOsAwJYuqH6/ukd1zhh+4Y0j+4LfWN2geq2xDsDUp6qbV39SbR7LL71xhF/0WdUDGxZ0+JZxDzBa51e/V92mES4nv3HEX/xbp7MBL7cNAIzOJ6dn/X86prN+BeC/fL96WHXX6kzbA8AozvqfXN22OmXMQWw0Fqp6d3XD6sUNbxcEYPF8orpZ9ZyxnvUrANt2TvXIhhUETxUHwMI4t3pSw+N9XxSHAnBpPlBdv3pw9SVxAMz1gf/Z1cHV85z1KwDbY3P1qoabBH+1kV8nApgzP2h4pO/g6il5Q6wCsBMurl7XcH/A/fNeAYBZdk71rOmB//cd+BWAlbBcHVvdtLpPw4uGAJidA/8zpwf+P8jr4BWAVSoCb2l4dvSXG1aPAmB9nF09Y3rg/8PqeyJRANbC2xreFnVU9d6GywUArL4zpwf8g6s/cuDfORuWl+f7sfelpaVZ+VGu2fDkwEOqww0tgBV1XsMM7D9U75+Fk67JZKIAKAD/w22rh1YPqK5ouwXYaZ+cHvRf37B668xQABSAy7J3de9pGbhzLrkAbI//aHgU+x+a4cewFQAFYHtdq/q1aRm4ru0b4L+5sHr79KD/ruqiWf+BFQAFYGfcdloG7t5w7wDAGG2ujq/eWL2mmqsdugKgAOyqGzc8SXDUtBhssk8AFthZDS9ge0f1nub4mX0FQAFYSVeufnFaBn6pupp9BbAATqzeOT3oH9+CPDatACgAq/bdVEduMTtwy+nfAcy6cxse1XvH9MD/jUX8JRUABWCtXG06K3BUwyuL97ePAWbIlxtu3ntH9aHq/EX/hRUABWC9ZgeOaLhn4JLP9cwQAGvkgurT1Uerj00//zG2EBQABWBWXKW6zRaF4FbVvmIBVsC3q49vccA/YQxn+AqAAjCvNlU32WqW4NpiAS7HcsPiO5cc7D9afUUsCoACMN+uscXswI2rG03/Dhjvwf5r1eerzzXcof/xZmzJXQVAAVAAVsdVp0Vgy88NqyuIBhbKd6cH+pOmf36++kLDHfsoAAoAw7houFywdTE4otpNPDDTLqi+uNWB/qTqm6JRABQAdtYeDU8b3Ki6QXXY9HPodCYBWDtnVV/d4nPy9ED/5eZgHX0FQAFQABbHlbYoA4du9Z8PMnMAO2xzdcYWB/jTtvrznHk/ALG+7JRZKWdXn5l+tjXODtpGMTisOrjhEUYYo+9Xp291YL/kP5/uTB4zAGYAFt1eDU8jXH3655afLf/uSqJiTpzbcM39sj7fqn60K/8SMwCYAWDenTc94zntcv53+1xKMbjkv+/f8EKlKzU8xbBRtKyQ5elB/ezpWft3pwfwSzuw/0BkKACwcn7UsCDJ9ixKsmFaAq601efK2/i7S/tnV8jyyovih9OD9yUH8LO3+mzr77b8+3NakDfYgQLAGM7Yzpl+ztzJ/x8btyoRO1IeLvnsp0Tssh9v5wH70v7unFxLBwUAdsDFWxxIdtYlJWL36We3dfjz8v7ZxdWF04Pkev+59d/9sOG5dmCFzf1NgADAzp2dAAAj8/8HADBAcFX7tr/TAAAAAElFTkSuQmCC";
//var eventResumeClick = false;
function validateEmail(email) {
    var re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
}
function isValidPhone(phone) {
    var p = /^[0]9\d{8}/g;
    var str = phone;
    return p.test(str);
}
function isIranianMobileNumber(phone) {
    var p = /(0)9[1|2|3|4]([ ]|-|[()]){0,2}(?:[0-9]([ ]|-|[()]){0,2}){8}/i;
    return p.test(phone);
}

// Ionic Starter App
// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'


angular.module('app', ['ionic', 'ngResource', 'ngCordova', 'app.controller', 'app.directive', 'ui.mask', 'ui.router', 'jrCrop'])
        .config(function ($stateProvider, $urlRouterProvider, $ionicConfigProvider) {
            $urlRouterProvider.otherwise('/app');
            $ionicConfigProvider.tabs.position('bottom');

            $stateProvider
                    .state('about', {
                        url: "/about",
                        views: {
                            'about': {
                                templateUrl: "partials/about.html",
                                controller: "AboutController"
                            }
                        }
                    })
                    .state('aboutGomaneh', {
                        url: "/aboutGomaneh",
                        views: {
                            'grid': {
                                templateUrl: "partials/aboutGomaneh.html",
                                controller: "aboutGomanehController"
                            }
                        }
                    })
                    .state('micro', {
                        url: '/micro',
                        views: {
                            'micro': {
                                templateUrl: 'partials/micro.html',
                                controller: "MicroController"
                            }
                        }
                    })
                    .state('login', {
                        url: '/login',
                        views: {
                            'login': {
                                templateUrl: 'partials/login.html',
                                controller: "LoginController"
                            }
                        }
                    })
                    .state('grid', {
                        url: '/grid',
                        views: {
                            'grid': {
                                templateUrl: 'partials/grid.html',
                                controller: "MenuController"
                            }
                        }
                    })
                    .state('search', {
                        url: '/search',
                        views: {
                            'grid': {
                                templateUrl: 'partials/search.html',
                                controller: "SearchController"
                            }

                        }

                    })
                    .state('register', {
                        url: '/register',
                        views: {
                            'grid': {
                                templateUrl: 'partials/register.html',
                                controller: "RegisterController"
                            }

                        }

                    })
                    .state('contact', {
                        url: '/contact',
                        views: {
                            'grid': {
                                templateUrl: 'partials/contact.html',
                                controller: "ContactController"
                            }

                        }

                    })
                    .state('map', {
                        url: '/map',
                        views: {
                            'grid': {
                                templateUrl: 'partials/map.html'
                            }

                        }

                    })
                    .state('sendMsg', {
                        url: '/sendMsg',
                        views: {
                            'grid': {
                                templateUrl: 'partials/sendMsg.html'
                            }

                        }

                    })
                    .state('panel', {
                        url: '/panel',
                        views: {
                            'grid': {
                                templateUrl: 'partials/panel.html',
                                controller: "PanelController"
                            }

                        }

                    })
                    .state('savabegh', {
                        url: '/panel',
                        views: {
                            'grid': {
                                templateUrl: 'partials/setting/historyAnimal.html',
                                controller: "historyAnimal"
                            }

                        }

                    })
                    .state('optionProfile', {
                        url: '/panel/profile',
                        views: {
                            'grid': {
                                templateUrl: 'partials/setting/optionProfile.html',
                                controller: "PanelController"
                            }

                        }

                    })
                    .state('myAnimals', {
                        url: '/panel/myanimals',
                        views: {
                            'grid': {
                                templateUrl: 'partials/setting/myanimals.html',
                                controller: "myAnimalsController"
                            }

                        }

                    })
                    .state('myMessage', {
                        url: '/panel/myMessage',
                        views: {
                            'grid': {
                                templateUrl: 'partials/setting/myMessage.html',
                                controller: "myMessageController"
                            }

                        }

                    })
                    .state('registerMicrochip', {
                        url: '/registerMicrochip',
                        views: {
                            'grid': {
                                templateUrl: 'partials/registerMicroChip.html',
                                controller: "registerMicrochip"
                            }

                        }

                    })
                    .state('gallery', {
                        url: '/gallery',
                        views: {
                            'grid': {
                                templateUrl: 'partials/gallery.html',
                                controller: "gallery"
                            }

                        }

                    })
                    .state('galleryShowImages', {
                        url: '/galleryShowImages',
                        views: {
                            'grid': {
                                templateUrl: 'partials/galleryContent.html',
                                controller: "galleryShowImages"
                            }

                        }

                    });
        })
        .run(function ($ionicPlatform, $cordovaToast, $cordovaDeviceOrientation, $cordovaSQLite, $cordovaNetwork, $rootScope, $state, $ionicHistory, $http) {

            $ionicPlatform.ready(function () {
                $rootScope.hiddenBackbuttonGallery = false;
                $rootScope.idAnimalForSavabegh = null;
                if (navigator.splashscreen) {
                    navigator.splashscreen.hide();
                }
                $rootScope.orientation = 'portrait';
                if (Math.floor(Math.abs(window.orientation) / 90) === 1) {
                    $rootScope.orientation = 'landscape';
                }
                //StatusBar.hide();
                if ($rootScope.LoginUser) {
                    if (db == null) {
                        db = $cordovaSQLite.openDB("abanpet.db");
                    }
                    var query = "SELECT * FROM fos_user WHERE id = ?";
                    $cordovaSQLite.execute(db, query, [$rootScope.userID]).then(function (data) {
                        if (data.rows.length > 0) {
                            if (data.rows.item(0).photo == null || data.rows.item(0).photo == '' || typeof data.rows.item(0).photo == "undefined") {
                                $rootScope.imgProfile = imageProfileDefualt;
                            } else {
                                $rootScope.imgProfile = data.rows.item(0).photo;
                            }

                        } else {
                            console.log('no user info loaded');
                        }
                    });
                }
                $rootScope.checkDuplicateMessage = function (id) {
                    var flag = 0;
                    var search = "select * from user_message where(id = ?)";
                    $cordovaSQLite.execute(db, search, id).then(function (result) {
                        if (result.rows.length > 0) {
                            flag = 0;
                        } else {
                            flag = 1;
                        }
                    });
                    return  flag;
                };

                function requestForGetMessage() {
                    if ($cordovaNetwork.isOnline()) {
                        if ($rootScope.LoginUser) {
                            $http.get(BaseUrl + '/mobile/messages/user/mobile.json',
                                    {headers: {'x-wsse': $rootScope.loginInfo}}).success(function (response) {
                                if (response.length > 0) {
                                    var query = "INSERT INTO user_message VALUES (?,?,?,?,?,?,?,?,?)";
                                    var i;
                                    for (i = 0; i < response.length; i++) {
                                        try {
                                            console.log('isOnline Check Duplicate');
                                            $rootScope.checkDuplicateMessage(response[i].id);
                                            if ($rootScope.checkDuplicateMessage) { // checkDuplicate
                                                $cordovaSQLite.execute(db, query, [response[i].id, $rootScope.userID, response[i].create_at, response[i].update_at,
                                                    response[i].message_type, response[i].message, response[i].user_name_message_owner, response[i].message_owner, 0]).then(function (data) {

                                                }, function (err) {
                                                    console.error(err);
                                                });
                                            }
                                        } catch (err) {
                                            console.error(err);
                                        }
                                    }

                                    query = "SELECT * FROM user_message WHERE is_read = '0'";
                                    $cordovaSQLite.execute(db, query, []).then(function (data) {
                                        if (data.rows.length > 0) {
                                            $rootScope.messageNotReaded = [];
                                            console.warn('isOnlined : Run of DB Client');
                                            for (var i = 0; i < data.rows.length; i++) {
                                                $rootScope.messageNotReaded.push(data.rows.item(i));
                                            }
                                            flagReadMessage = true;
                                        } else {
                                            flagReadMessage = false;
                                        }
                                    });

                                } else {
                                    var query = "SELECT * FROM user_message WHERE is_read = '0'";

                                    $cordovaSQLite.execute(db, query, []).then(function (data) {
                                        if (data.rows.length > 0) {
                                            console.warn('isOnlined : Run of DB Client');
                                            $rootScope.messageNotReaded = [];
                                            for (var i = 0; i < data.rows.length; i++) {
                                                $rootScope.messageNotReaded.push(data.rows.item(i));
                                            }
                                            flagReadMessage = true;
                                        } else {
                                            flagReadMessage = false;
                                        }
                                    });
                                }
                            });
                        }
                    } else {
                        var query = "SELECT * FROM user_message WHERE is_read = '0'";
                        $cordovaSQLite.execute(db, query, []).then(function (data) {
                            if (data.rows.length > 0) {
                                console.warn('isOffline : Run of DB Client');
                                flagReadMessage = true;
                                for (var i = 0; i < data.rows.length; i++) {
                                    $rootScope.messageNotReaded.push(data.rows.item(i));
                                }
                            } else {
                                console.warn('isOffline : no Message');
                                flagReadMessage = false;
                            }
                        });
                    }
                }
                setInterval(requestForGetMessage, 3600000);

                window.setTimeout(requestForGetMessage(), 1000);


                if (window.cordova && window.cordova.plugins.Keyboard) {
                    cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
                    cordova.plugins.Keyboard.disableScroll(true);
                }
                if (window.StatusBar) {
                    StatusBar.styleDefault();
                }
                if (window.plugins.sim) {
                    window.plugins.sim.getSimInfo(successCallback, errorCallback);
                }
                function successCallback(res) {
                    mobileNumber = res.phoneNumber;
                }

                window.cordova.plugins.backgroundMode.setDefaults({
                    text: 'نرم افزار آبان پت',
                    title: 'version 1.0.0',
                    silent: true
                });


                cordova.plugins.backgroundMode.ondeactivate = function () {
                    console.log('backgroundMode deactive');
                };
                window.cordova.plugins.backgroundMode.onactivate = function () {
                    console.log('backgroundMode active');
                };

                function errorCallback() {}
                ;
                // init dataBase for first run on device
                window.plugins.sqlDB.copy("abanpet.db", function () {
                    db = $cordovaSQLite.openDB("abanpet.db");
                }, function (error) {
                    db = $cordovaSQLite.openDB("abanpet.db");
                });

            });
            $ionicPlatform.on('resume', function () {
                console.log('program to resume');
                //requestForGetMessage();
                if (flagReadMessage) {
                    $state.go('myMessage');
                    //eventResumeClick = true;
                    window.plugin.backgroundMode.disable();
                    window.cordova.plugins.backgroundMode.configure({
                        text: 'نرم افزار آبان پت',
                        title: 'version 1.0.0',
                        silent: true
                    });
                }
                $cordovaToast
                        .show('فراخوانی برنامه', 'short', 'bottom')
                        .then(function (success) {

                        }, function (error) {
                            // error
                        });
            });
            $ionicPlatform.on('pause', function () {
                console.log('program to pause');
                if (flagReadMessage && $rootScope.LoginUser) {
                    window.cordova.plugins.backgroundMode.configure({
                        text: 'پیام خوانده نشده دارید',
                        title: 'نرم افزار آبان پت',
                        silent: false
                    });
                    window.cordova.plugins.backgroundMode.enable();
                    $cordovaToast
                            .show('ورود به پس زمینه', 'long', 'bottom')
                            .then(function (success) {

                            }, function (error) {
                                // error
                            });
                } else {
                    window.plugin.backgroundMode.disable();
                    window.cordova.plugins.backgroundMode.configure({
                        text: 'نرم افزار آبان پت',
                        title: 'version 1.0.0',
                        silent: true
                    });
                }

            });
            $ionicPlatform.onHardwareBackButton(function (e) {
                //console.log($state.current.name);
                if ($state.current.name === 'login') {
                    $state.go('about');
                }
            });
            $rootScope.$on("$stateChangeStart", function (event, toState, toParams, fromState, fromParams) {
                //console.log(toState.name);
                if ($rootScope.LoginUser && toState.name.indexOf("login") > -1) {
                    event.preventDefault();
                    $state.go('about');
                    $ionicHistory.clearHistory();
                    $ionicHistory.clearCache();

                }

//                if (toState.name.indexOf("gallery") > -1) {
//                    $rootScope.hiddenBackbuttonGallery = false;
//                }
//                if (toState.name.indexOf("galleryShowImages") > -1) {
//                    $rootScope.hiddenBackbuttonGallery = true;
//                }

            });

            // Init orientation default 
            if (Math.floor(Math.abs(window.orientation) / 90) === 1) {
                $rootScope.classGrid = 'col-50';
            } else {
                $rootScope.classGrid = 'col';
            }
            window.addEventListener("orientationchange", function () {
                // Announce the new orientation number
                if (window.orientation == 0) {
                    $rootScope.classGrid = 'col';
                } else {
                    $rootScope.classGrid = 'col-50';
                }
            }, false);
        })
        .factory('Base64', function () {
            var keyStr = 'ABCDEFGHIJKLMNOP' +
                    'QRSTUVWXYZabcdef' +
                    'ghijklmnopqrstuv' +
                    'wxyz0123456789+/' +
                    '=';
            return {
                encode: function (input) {
                    var output = "";
                    var chr1, chr2, chr3 = "";
                    var enc1, enc2, enc3, enc4 = "";
                    var i = 0;

                    do {
                        chr1 = input.charCodeAt(i++);
                        chr2 = input.charCodeAt(i++);
                        chr3 = input.charCodeAt(i++);

                        enc1 = chr1 >> 2;
                        enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
                        enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
                        enc4 = chr3 & 63;

                        if (isNaN(chr2)) {
                            enc3 = enc4 = 64;
                        } else if (isNaN(chr3)) {
                            enc4 = 64;
                        }

                        output = output +
                                keyStr.charAt(enc1) +
                                keyStr.charAt(enc2) +
                                keyStr.charAt(enc3) +
                                keyStr.charAt(enc4);
                        chr1 = chr2 = chr3 = "";
                        enc1 = enc2 = enc3 = enc4 = "";
                    } while (i < input.length);

                    return output;
                },
                decode: function (input) {
                    var output = "";
                    var chr1, chr2, chr3 = "";
                    var enc1, enc2, enc3, enc4 = "";
                    var i = 0;

                    // remove all characters that are not A-Z, a-z, 0-9, +, /, or =
                    var base64test = /[^A-Za-z0-9\+\/\=]/g;
                    if (base64test.exec(input)) {
                        alert("There were invalid base64 characters in the input text.\n" +
                                "Valid base64 characters are A-Z, a-z, 0-9, '+', '/',and '='\n" +
                                "Expect errors in decoding.");
                    }
                    input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");

                    do {
                        enc1 = keyStr.indexOf(input.charAt(i++));
                        enc2 = keyStr.indexOf(input.charAt(i++));
                        enc3 = keyStr.indexOf(input.charAt(i++));
                        enc4 = keyStr.indexOf(input.charAt(i++));

                        chr1 = (enc1 << 2) | (enc2 >> 4);
                        chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
                        chr3 = ((enc3 & 3) << 6) | enc4;

                        output = output + String.fromCharCode(chr1);

                        if (enc3 != 64) {
                            output = output + String.fromCharCode(chr2);
                        }
                        if (enc4 != 64) {
                            output = output + String.fromCharCode(chr3);
                        }

                        chr1 = chr2 = chr3 = "";
                        enc1 = enc2 = enc3 = enc4 = "";

                    } while (i < input.length);

                    return output;
                }
            };
        })
        .factory('TokenHandler', ['$http', 'Base64', function ($http, Base64) {
                var tokenHandler = {};
                var token = 'none';

                tokenHandler.set = function (newToken) {
                    token = newToken;
                };

                tokenHandler.get = function () {
                    return token;
                };

                // Generate random string of length
                tokenHandler.randomString = function (length) {
                    var text = "";
                    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
                    for (var i = 0; i < length; i++) {
                        text += possible.charAt(Math.floor(Math.random() * possible.length));
                    }
                    return text;
                };

                tokenHandler.getCredentials = function (username, secret) {
                    // Generate nonce
                    var nonce = tokenHandler.randomString(30);

                    // Creation time of the token
                    var created = formatDate(new Date());

                    // Generating digest from secret, creation and nonce
                    var hash = CryptoJS.SHA1(nonce + secret);
                    var digest = hash.toString(CryptoJS.enc.Base64);
                    // Base64 Encode digest
                    var b64nonce = Base64.encode(nonce);
                    // alert('UsernameToken Username="'+username+'", PasswordDigest="'+digest+'", Nonce="'+b64nonce+'", Created="'+created+'"');
                    // Return generated token
                    return 'UsernameToken Username="' + username + '", PasswordDigest="' + digest + '"';

                };


                // Token Reinitializer
                tokenHandler.clearCredentials = function () {
                    // Clear token from cache
                    $cookieStore.remove('username');
                    $cookieStore.remove('digest');
                    $cookieStore.remove('nonce');
                    $cookieStore.remove('created');

                    // Clear token variable
                    delete $http.defaults.headers.common['x-wsse'];
                };

                // Token wrapper for resource actions
                tokenHandler.wrapActions = function (resource, actions) {
                    var wrapperResource = resource;

                    for (var i = 0; i < actions.length; i++) {
                        tokenWrapper(wrapperResource, actions[i]);
                    }

                    return wrapperResource;
                };

                // Token wrapper
                var tokenWrapper = function (resource, action) {
                    resource['_' + action] = resource[action];
                    resource[action] = function (data, success, error) {
                        if ((typeof data.username != 'undefined') && (typeof data.secret != 'undefined')) {
                            $http.defaults.headers.common['x-wsse'] = tokenHandler.getCredentials(data.username, data.secret);
                            delete data.username;
                            delete data.secret;
                        }
                        return resource['_' + action](
                                data,
                                success,
                                error
                                );
                    };
                };

                // Date formater to UTC
                var formatDate = function (d) {
                    // Padding for date creation
                    var pad = function (num) {
                        return ("0" + num).slice(-2);
                    };

                    return [d.getUTCFullYear(),
                        pad(d.getUTCMonth() + 1),
                        pad(d.getUTCDate())].join("-") + "T" +
                            [pad(d.getUTCHours()),
                                pad(d.getUTCMinutes()),
                                pad(d.getUTCSeconds())].join(":") + "Z";
                };

                return tokenHandler;
            }])
        .factory('Salt', ['$resource', function ($resource) {
                // Service to load Salt
                return $resource(BaseUrl + '/:username/salt', {username: '@id'});
            }])
        .factory('Digest', ['$q', function ($q) {
                var factory = {
                    // Symfony SHA512 encryption provider
                    cipher: function (secret, salt) {
//                        var deferred = $q.defer();
//                   
//                        var salted = secret + '{' + salt + '}';
//                        var digest = CryptoJS.SHA512(salted);
//                        for (var i = 1; i < 5000; ++i) {
//                            digest = CryptoJS.SHA512(digest.concat(CryptoJS.enc.Utf8.parse(salted)));
//                        }
//                       
//                        digest = digest.toString(CryptoJS.enc.Base64);
//
//                        deferred.resolve(digest);
//                        console.log(digest);
//                        return deferred.promise;
                    },
                    // Default Symfony plaintext encryption provider
                    plain: function (secret, salt) {
                        var deferred = $q.defer();

                        var salted = secret + '{' + salt + '}';
                        var digest = salted;

                        deferred.resolve(digest);
                        return deferred.promise;
                    }
                };
                return factory;
            }]);

