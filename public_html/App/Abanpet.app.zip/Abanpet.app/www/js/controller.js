/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* global db, BaseUrl, google, mobileNumber */


angular.module('app.controller', ['ui.router'])
        .controller('MainPageCntroller', function ($scope, $cordovaNetwork, $state, $rootScope, $ionicSideMenuDelegate, $http, $cordovaSQLite) {

            $rootScope.loginInfo = window.localStorage['logined'];
            $rootScope.userID = window.localStorage['userId'];

            if (($rootScope.loginInfo !== '') && ($rootScope.loginInfo !== null) && (typeof $rootScope.loginInfo !== 'undefined')) {
                $rootScope.LoginUser = true;
                //get user information of data base client
                $state.go('about');
            } else {
                $rootScope.LoginUser = false;
                $rootScope.imgProfile = 'img/logo.png';
                $state.go('login');
            }

            $scope.showProfileIfLogin = function () {
                if ($rootScope.LoginUser) {
                    $state.go('panel');
                } else {
                    $state.go('login');
                }
            };
            $rootScope.ShowHidden = function () {
                if ($rootScope.LoginUser) {
                    return 'ng-hide';
                } else {
                    return 'ng-show';
                }
            };
            $scope.toggleLeft = function () {
                $ionicSideMenuDelegate.toggleLeft();
            };
        })
        .controller('HomeController', function ($rootScope) {

        })
        .controller('AboutController', function ($scope, $ionicPopup, $rootScope, $cordovaSQLite) {
            $scope.touched = 0;
            $scope.showAlert = function (str) {
                var alertPopup = $ionicPopup.alert({
                    title: 'هشدار',
                    template: "<div style='direction:rtl;text-align:right'>" + str + "</div>",
                    buttons: [{// Array[Object] (optional). Buttons to place in the popup footer.
                            text: 'تایید',
                            type: 'button-default btn-submit'
                        }]
                });
            };
            var cTimer = null;
            $scope.touchCounter = function () {
                $scope.touched++;
                if (!cTimer) {
                    cTimer = setTimeout(function () {
                        cTimer = null;
                        $scope.touched = 0;
                    }, 3000);
                }
                if ($scope.touched >= 5) {
                    var htmlMessage = '';
                    htmlMessage += '<div style="text-align: center;"><img src="img/EnLogo.png" width="128px" height="auto"/></div>';
                    htmlMessage += '<div><strong>شرکت سازنده :</strong><span>گروه مشاورین گمانه </span></div>';
                    htmlMessage += '<div><strong>مدیر پروژه:</strong></div>';
                    htmlMessage += '<div>داوود رخبخش</div>';
                    htmlMessage += '<div><strong>UI/UX:</strong></div>';
                    htmlMessage += '<div>نیما اسدی</div>';
                    htmlMessage += '<div><strong>برنامه نویسان :</strong></div>';
                    htmlMessage += '<div>حمیدرضا دارش</div>';
                    htmlMessage += '<div>مصطفی حسین زاده</div>';

                    $scope.showAlert(htmlMessage);
                    $scope.touched = 0;
                }
            };
        })
        .controller('aboutGomanehController', function () {

        })
        .controller('MicroController', function ($scope, $state, $ionicPopup, $http, $cordovaBarcodeScanner, TokenHandler, $rootScope) {
            $scope.animalId = '';
            $scope.animal = null;
            $scope.showAlert = function (str) {
                var alertPopup = $ionicPopup.alert({
                    title: 'هشدار',
                    template: "<div style='direction:rtl;text-align:right'>" + str + "</div>",
                    buttons: [{// Array[Object] (optional). Buttons to place in the popup footer.
                            text: 'تایید',
                            type: 'button-default btn-submit'
                        }]
                });
            };
            $scope.ScanCodeForSearch = function () {
                $cordovaBarcodeScanner
                        .scan().then(function (result) {
                    $scope.animalId = result.text;

                },
                        function (error) {
                            alert("Scanning failed: " + error);
                        }
                );
            };
            $scope.serachAnimal = function () {
                if (!$scope.animalId) {
                    $scope.showAlert('لطفا کد الکترونیکی حیوان را وارد کنید');
                    return false;
                }
                if ($scope.animalId.length != 15) {
                    $scope.showAlert(' کد الکترونیکی وارد شده معتبر نیست');
                    return false;
                }
                $http.get(BaseUrl + '/micro_search/' + $scope.animalId).success(function (res) {
                    if (res.status) {
                        $scope.animal = res.data;
                    } else {
                        $scope.showAlert('نتیجه ای یافت نشد');
                    }

                });
            };
            $scope.closeSearchChip = function () {
                $scope.animal = null;
            };
            $scope.checkMicroLoginAdd = function () {
                if ($rootScope.LoginUser) {
                    $state.go('registerMicrochip');
                } else {
                    $scope.showAlert('شما باید لاگین کنید');
                }
            };

            $scope.blur = function (e) {
                var element = e.target.previousElementSibling.classList[2];
                e.target.previousElementSibling.classList.remove(element);
                e.target.previousElementSibling.classList.add(element.replace('-strong', ''));
            };
            $scope.focus = function (e) {
                var element = e.target.previousElementSibling.classList[2];
                e.target.previousElementSibling.classList.remove(element);
                e.target.previousElementSibling.classList.add(element + '-strong');
            };
        })
        .controller('registerMicrochip', function ($http, $ionicHistory, $cordovaSQLite, $state, $rootScope, $scope, $ionicPopup, $ionicListDelegate, $cordovaNetwork, $ionicModal, $cordovaCamera, $cordovaImagePicker, $ionicSlideBoxDelegate) {

            $scope.stepWizard = 1;

            if ($rootScope.LoginUser) {
                var query = 'SELECT * FROM fos_user WHERE(id = ?)';
                $cordovaSQLite.execute(db, query, [$rootScope.userID]).then(function success(data) {
                    if (data.rows.length > 0) {
                        $scope.user = {};
                        $scope.user = data.rows.item(0);
                    }
                    $scope.stepWizard = 2;
                });
            }

            $scope.GoStepNext = function (step) {
                $scope.stepWizard = step;
            };

            if ($cordovaNetwork.isOnline()) {
                ///animals/category/mobile.{_format} 
                $http.get(BaseUrl + '/mr/animals/category/mobile.json').success(function (response) {
                    $scope.animalCategory = response;
                    console.log(response);
                    if (response.length > 0) {
                        var i;
                        for (i = 0; i < response.length; i++) {
                            var query = 'INSERT INTO animalscategory (id,animalsType,describtion,created_at,updated_at) VALUES (?,?,?,?,?)';
                            $cordovaSQLite.execute(db, query, [response[i].id, response[i].animalstype, response[i].describtion, response[i].create_at, response[i].update_at]).then(function success() {

                            });
                        }
                    }
                });

            } else {
                var query = "SELECT * FROM animalscategory";
                $cordovaSQLite.execute(db, query, []).then(function (result) {
                    if (result.rows.length > 0) {
                        var i;
                        for (i = 0; i < result.rows.length; i++) {
                            $scope.animalCategory.push(result.rows.item(i));
                        }
                    }
                });
            }

            $scope.showAlert = function (str) {
                var alertPopup = $ionicPopup.alert({
                    title: 'هشدار',
                    template: "<div style='direction:rtl;text-align:right'>" + str + "</div>",
                    buttons: [{// Array[Object] (optional). Buttons to place in the popup footer.
                            text: 'تایید',
                            type: 'button-default btn-submit'
                        }]
                });
            };
            $scope.resetRegistration = function () {
                $scope.user = {};
                $scope.user.sex = 0;
                $scope.ItemInsertAnimal = {};
                $scope.ItemInsertAnimal.name = null;
                $scope.ItemInsertAnimal.age = null;
                $scope.ItemInsertAnimal.sex = null;
                $scope.ItemInsertAnimal.weight = null;
                $scope.ItemInsertAnimal.stature = null;
                $scope.ItemInsertAnimal.code = null;
                $scope.ItemInsertAnimal.user = $rootScope.userID;
                $scope.ItemInsertAnimal.photo = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQ4AAAErCAYAAAAv0G0gAAAACXBIWXMAAACVAAAAlQGr+O8LAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAKGlJREFUeNrsnXm8VWXVx793vlymy4yAyDyqIArOpmJqOWeapWYOZVk5lG9aeUo9qU0ftcGyV3vTNLWynMcMJQdUUFERFQUDAQGZx8sd3z/WunKBc++Z9jn72ftZ38/nfCSTc/Z+9rN/z1rrWc9aJS0tLRiGYWRDqQ2BYRgmHIZhmHAYhmHCYRiGCYdhGCYchmEYGVCe7xckk0kbxfTivCewHzAB2AMYCfRMMf6NwGpgPvAG8Drwkv650YbSCJpEIhGOcBjt0gk4ADgKOBwYC9Rk8Dz66md/oA54B5gOPA48C2yyoTUib3EYKdkbOA84EhiWx/dUAxP1cxLwb+CPwPMejWU3YDe10LoAtfrv1wEbgDXAQv3fhglHJOkNfFk/EwL+7sHA2ery3AHcBnwU03EcqBbXRGAcMEQFpErFFLXGtqp4/BeYC8wGXlYhMUw4IsFewOXAZ4CuBfydscAV+mIlgZkxGsMJwHHAEcBoFeJM5uhE4FhgJfAu8C/gYSRGZJhwOMtngR8DU4r0ezX6gg1U8bg/4uM3AviqvvxDkfhQLnO5v34mA6cBjwK3AO/bFDXhcIlS4Bzgh2pOF5tJwA0qIL8HmiM2ftX6gn9drYaqAIV1d2T36mAVj7vVvTFMOEIXjfOBq4A+IV7HEOBHej2/idD4DVGX63NAjwL9RpW6dGOAg4Brka1uI4DJb+RuaYQtGq30Vavn/IiM375qBXy5gKLRlh7AmfqbB9n0NeEIgzLgDI0t9HHouvoBCWTnxVVK1MK4FcltqSjib1cAh6p4nGbT2ISj2HwauBIJwrnGQLU8jnZ07E5BYjK7hzT3StRt+aVaOyU2nU04isEeuqoPdfgah+s1jnPM0jgR+CmSj+KCwF4DfNHEw4Sj0OwCXIakkUchhpBAsi1dEI1jgF84JriDgOuAz9t7YMJRKGo0dnB6RK63DDgeuFD/HCaTkd2MEQ6O02DgaiT2YZaHCUfg7AdcEEGxOws4LGSX4Ep18VxlDPADYJRNcxOOIOkPfFtfgqgxBPgWkrodhnB9Hwkmu85U4NKQxsmEI4ZUIDsBx0f4Ho4AvlJkl6VUXbsziU6SYev1Vti0N+HIl7HARREfp84qHJOK+Jt7Ad9ATrRGhTIkJjTZpr0JRz5U6Qo0PAb3Mg4J7FYV4be6qGs3LoLjNETFo5dNfxOOXNkT+FJM7qUEOU27fxF+6xTgBKK7S3ESkt1q74YJR07WxtnAgBjd0zAk1bqmgL/Rejy+NsLjVAlcjO2ymHDkwN7AyTG8r2Mp3CGvUrXQ9omRa2enx004shqTLyInTuPGQHVZOhXgu/dQMz8uuxJnEM04jQlHSIxCyv/FlSMIPiGrAjgVObwWF4YgCXRmdZhwZMQJSFXtuDJSxSPIF2IvtTbi9pJ9AalMZphwdEifmL4AbSlDjt0PCdDaOA4pLhxH1+40e09MONIxNWbmdntMBg4M0II5KsZz6TjcPKBnwuHQWBxDYQKHrlGNHH4Lomzf4QTfQ8Ylhqp4GCYc7a6c+3o0JvsHsJIOQgLJlTEepwp1X+0AnAlHSg4lXglf6RiO5FzkMwf2DdDlcZkJ6sYaJhzbUY4c/+7k0T2XAYeQ+7mMrsCngO4ejFUNkjxn74sJx3bsgWy7+TYe++XhrgzxxNpofU+mYGnoJhwpXqC+Ht73biqaucyDibhd2StoBqqFZZhwfMIUCnv4y1VKkK3ZbN2NHurm+FT0ppO6s5ZJasIBSEB0d8Iv6hsWE3OwtnxyU9q+K3t5ZmWZcHTABGRb0VfGkl2xohIV2tEejlVfdWtNOGwI2IdolbgLms66klZn+N93QcoO+Dh3qlU4vG+l4LtwlKmpXuP5OExCtlczoRfFrV/qEuVqbQ3wfL54LxyDcKMlYdgMJ/Oub0OB8R6P1QDsxKz3wjEc6fLuO8OQFpfpqEBqsfb0eKy6E48qZyYceTAiCxM9znRVES3L4L+b5PlYdUJiQl5vy/ouHOOQ4KAhuyvpAqTd8XM3ZUd2xe+dOK+Fo0pXWevcJYzKQET7qVvjO33xvEaHz8IxAD/TzNtjCB23NShFUtTteLm4bCYcntIfv4N8qYS0No2FNhbLYUAtszEmHH7SDwuMtqUWqbnanjBU+/6ytKFc3dxqXwfAd1el2t6BTyhDclra2y3oTnAFjuOy8HibCOazcAzCMkZ3JJ1wDLQh+oSe6u6acHhocdiOyvYMpP1cjp5YYLQtnfE4edBX4eiEHyXvsqU3EgRN5caYa7fzHDJXxTO6Iqc8jZ3dkVR1V8uJd3e7XKhBEsFMODwTDssY3ZnadqyKcjzPlExBBZmd7zHhiBFdTDiyFo4+Njw70QNPt/R9FY5u2I5KNuNSTcfJYb7S2YTDP4vDAn2pze9u7JwEZsHk9ueRCYdHVONvceKOKFOR2FE4qgimz2zc6GrC4d/KavVWd6aE1H1gO5mr0u4C5GW9Wl9fnkoTjg6FY0eLowYLJrcnHF5u6/ssHOaqZGZxlKhwmNCmdu28DLL77KqYcKQWjooUFkcqK8SQ96fC1xv3kXJ7EToU1VRWiFkcqS0OEw6PaAZabN63OzaYxWEWhwnHztQDTTbvU7LVLA4TDhOO9oWj2eb9TrQADSmsMbM4UlNiwuEXDSYc7bop9SleDnPrOhZbEw4TDu9fgvodXoYWdV9MPDITWhOOmLsqFuNoXzhS/TsT2tTC0WDC4Q+bfH3gaWgENqQQCRMOEw4TDn056mzepxTUDRm4L4YJh7fCsdHm/U6sSyGoJhwdC4fFODxio66uxvasZec8jtbxarTh2Yl6X+eRWRzGjhbHlhT/fguw3oZnJ7amcO1MOEw4vGM1qWM/dWqNGNuz2VdB9fmsygpsp2BHlrXjkmwx4WjX5TWLwzMWt2OW+8yH7QjHVhOOdoXDS8vVhMNoa4UtJPX24lZgjQ1RSuEwV8VDs3yzzf3t/PWl7bhvjcByG6KdWImn+UA+C8dyW0UzHo9GYJEN0XbUqdVa7Pe1HDmR2wmpA1ul/66MIp5gLvf4wX+kK4YhfEj7cYxG/f+bsbocbS20YghHFdLTZhCwOzAK6Kn/rhLZQl+twj4bWACsInU+jglHALQOdgtWawLgfdrfIWhWod2Ip+0AUrBFx6QQlKgwjAGO1M8YpLdNR8K9FngH+DfwAPA2BQrehiUcrtR4eBvJ/LPO9TIWW9JMymUmHJ+wnsLEfboDBwFnAkcAvbL4u7XAfvr5CnAfcDvwOgGfqSmGcFQg3a76qonV2m+zgW3bWR+rf72R4h53f1d/03fhaNSVqqNzF+vUNB9lmgHq5gZpcVQB+wBnA6eSf4e4gcC3gE8DNwJ/JcCYXiGFoyswGtgf2BfYQ/20bvq7rScLVwPzgbeAWcBM9dOKkVgzX/3B/hbfSOuvr9fxOtw0gxZgSYAWR1/gdOASYNeAr3U08GsVpWuAD1wVjmpgMnCCfka089+Vqsruop+DgPN15XsSeBR4icImHn2gE2C85y/Ce6QPFG8F5ppmfDIW8wgm83gicDFwBoXr9VMBnKsC9X1dpJ0Sjl11AL4GDMnxO8bo50vA34G7gJcpzPHlzerbH4anRWeVt0ifyFSvL0sjfgfVQeJi7wbwPUcASY1JFIPjkM5zFwNz8vmiILfWDgBuAq7NQzTa0hv4BvAn4LvAgAIN5kw8PW+gNKmLmEky3GJ1a3xnLbILlSslwEnAb4ooGq1MBX4CDHZBOD6jonFcAW50hPpmNxRokF9FgrM+xzfeztDsXpnnCxMXPkLiPblyOhKwHBPS9Z8AJMhuxyZw4TgJCb5MLOCNliCR5j/oP4PMu5ivPr6vFa5mI6nmmbA+CP84Bhba+0hQPRdOBX6a74ofAGcA5ySTyfKiC0cymTwcuI72A6BBsyfwS+CrAfrZ9Wqq13v6IrxC5tt0m3WsfC5HsEXHIFfL/BpkqzRsqoELkE2J4glHMpmcoL7S6CLf8K46+BcjKbdB8CKSp+AbG9RVy1Q0m5FdL5/jHKtUbLPlQLU0Rjh0L0OAbyeTyf5FEY5kMtkHuBzJ0QiD3sAVwDcDcrdeVvPTN3dltgpBNizVv+crC8h+R2IocLVazK7xWeCEZDJZWlDhSCaTZeofnRDyDXdH9qTPDeC71gDT8a9J03QkjyUbVue44saBehXNbM5/dNF5eqij91SNpLcPK7TFcQCyTdrJgZvuo5bH5wP4rqfw65j9amAG2Z+i3Aq8hp9b2Jt0zLLhfOA03D5VPAU4LplMVhREOJLJZA/k8MxIh256MLK1tHee3zMT2THwxV15ldwzQd8G3vRQOBZlKRxHqjvd1fH7qlBxG1YQ4QAOBk508Mb3BK4kvzMnG9Tq8MVdmU7uQc4lwH88E41G4IUsXLsBwEUa34gCk4CDNRQRnHAkk8nWgzg9Hb3xI4DLyC91/GGKX9UpDBaQX0ynDnie3HMZosgG4F9ZWKTnIUcZokI5cKy6/4FaHPsj+9CuUq3C9oU8vmOOWh1xz1N4CqnRkA9v4dfuyny1ODLh08BZuBEHzIZDgQmBCUcymawFjomAr9YHqUEwNse/3wTcS7xbAawAHif/6tyLPXJXGoFndOzS0QvZ6RsawfvsDhyeTCY7B2VxjFZXICq+2oXIkf1cmJHFyhJFXkDKFeRLg7o7CzwQjpXAQxm6KcfruxLVcpQHI8fv8xOOZDJZjRRviYqCViDnZ07O8e+vB+4hnj1XNgKPkPnZlHS8jtS3jDMtwLPIrls6hiHlIHpF+H4nkMHhu0wsjl7IUdwo0Q8pwZbrmYAndLLEjWeRIklBsVbHKs5B0k3qvm7J4F06mRzPfjhEDXBgMpmsyVc4RpJ/jkQY7EvuiTcrgVuJV8OmNUjdyaD7o7wYc9fuVWBahu78SUiQPursT5qi1KVp3JQq/ZLaCN58V+CLwLgc//5TAa/OYTMNeKwA37sEKfMYR9euEfgb6csqlgJHI/G1ODAWKeeZs8XRFQmWRNlf+yK51XJcq1ZHHFKrlwN3k9muQC48BjwXQ+GYBTyYYWzjBHIPyLvo6o/o6OBbOuEYiFQnjyrlyOm/XIoRtyC7BndHfBI0Ic15Hi/gbyzUlTlO51cagP8jfXZtKRIDnBKjey/VRbcya+FIJpMlwHAKV+uzWIxDShrmEuvYCPwWOZsRVeYAv0eCfIXkYSTXIS7MyNDa2AXJuOxEvBjb0T119DJVqupEvVdopT7YkXm8eDdQ4F6cBWKjuluzi/Bby9Q6Wx2Dl2YrcAuZ9U3ZBzkxHjeGIi0nsxaOzkiT2zgwEQle5UIL8A/g/gje96PAnUX8vceQPJGonzB+WMcuHTXqpvSMoXAM7Oi+OhKOWnVV4kA1cn6gX45/fzVS63ROhO75DeAXFDd9fi3wO4LpORIWHyEVyDOxnEYRvRynTOlOBwWVOxKOnjGIb7RlCvkFsGYhzXOi0EphGVKXdVYIv/0iElSM6vbs7/Qe0lGmLsromApHZUfufUfCsSvx6kzeR1eHfIJY9wO/wu2K6FuRgO69IV7DbUQzFf1p4M9I/kY6egCfonBtG8OmBOn1nLVwjCS4KuKucCj5NcGpR3Yo/uTo/bXoxL+JcEsDfAz8HGkZGRU+RKqQZ5pZO4zwinUXc7HNyeIoidlAjEUaYufDaqQtxB0O3t9fkEpoax24lmeBnxGNEgWbVeimZfjflyO7KYNiLhy9chGOvjEciEqCSaFfjBRJvsehe/s78EOCO/kaBHch3fcaHZ8Xt2ThooAEDg+O4cIaiMXRO6aDMYVgmuIsAn6gL0fY/FWvZZFjY12H7Eb9w+H5cD+Sp5NNYaPBFL9ZdBj0NuHYxkhgr4C+6wPgf4DrCWcXoQEJ1l6Gu82gV6qoPeTgtT2pluPCLP5OKZKNPNgD4eici3D0iulgVOhqURvQ9y3VuMLlyDZosViNNPq5KsuJHwYLgEtx67Tx08D3yL6Jdo3GN0o9EI7KXISjS4wHZA+CzVHZoL78WfpyFDpzcjpSqOh3RKeJ1DzgEqRcQdg8o5ZiLgWbexKf4/MFEY7KGA/IWILPit2KlM8/S1fXQrgOi5AA6FlIWnTUkqzmIl0A7yCc/jUtSED760iBnlwYTLRPjGdDedb/B/GpLdCeNbUnUvauPuCJuQz4ja6spyBVoUaRe7+XZhWhB5Ag6Ju4nYCWjvd1tV+INCwqVuX89cDNSLA21+zfCqREQw88pyPhiLsPN0nNzkLEJRqQsyJzkWSxz+hnPLLF1Zq9WpJCeEB2I1ap//2Yfv6r3xsHlgPXqfvyXV3BCzXfmpEzRter8Nbl8V1VxOfgZ8GEI+6MQQ69FTKg2YgEBn8H3K5xlT31RemvK1fr6rUaSZZaplbFG0hZvs3Es5/tZuTk7ovqvpyOBOSDSuFuUsviHiSTNgjXsbNaj77QbMKR2lcdSP4dzTJ1YTbqCjsPOUdSqqZvuVoeDeqCtHj0DFqA95Dt5EeQhuaHIsmHucbY6lV8pyNJXU8HGE/p45lw1OUiHI0xF5YuyHmDMsIJ1DUjAdWtGA3IobjpSO2UU5G+q4M0BlLVwVxsVLFYqxbadBXmWQE/19ZDXwM8ei5bcxGOrR5YJONUQNbZu+sEjfrCz0LiT7sjyXq7IyX6uiF5FCA7Sus1XvImUuVsDoUre1Ch1kalR8+jLlfh6BzzgRmhK5oJh3usRnrTtvanLVXLo7XUw0ad2MWyFkuB3Tx7ButyEY5NxLMkWlsGIcHJxfaeOk+zWhlh5a5UICfGfWJlRyrakeLHnV08EEcjGLqSe0vRqLIqF+H42IOBqUUi+CX2Xhhp6Eb8628EIhwrPRmcQeSe1Wn4Qy3xPfiZtfFgwiF+a5W9F0YHlKho+LTANNNBF7uOhGMpfiQj9cbvRDgjPaUqHD7Nkzok6zklHQ3EAiQxJ+771rWeTYgqZCepJ9tS3muQ3jNVbf7ZjKSFb0K2Pjch5QNWIL1HNnsoHKUe3fNafc5ZC8eHOjl8EI7qmN5bmbpiI5D+H0ORYHAvtbRqkVydCralv7d+WpCMzHokp6ce2Qr9GDnev0gXlwXAO7hV67QQropvu29L6KDQdEfCsQrJyqv1QDjilOjWA6lQtReSGTsMCQD3IfviTKkWjbbtJdYh2/YLgFeQRs2ziF9eTAlSoNgnFpNjAtg6tTpGx3yAusbA4qhQoTgMOEQFox+F76DeXT9DkcNpy5E6rLOQQ2vTiXbtkLZUeyYc88kx5XyjToK4U010o+WdgGORYkGT1LIIy3oqQw6ADUBqup4EvAD8EymYtD7Cc6QUv86ogNSCqc9FOOqBtz0YoEqi18avFDgKqTt6CLk30y6kiAzWz+FImb67kTYJm0w4nGcD8H4ikWjKRTgakKBXA/Hev46acExBamYeiaTMux7p7wscjXTQOwYpajQ9YnOkDL9yfT4gTYGrdiddIpFo0QDJ0pgPUmWEhPEspBP8mci5iShtD/YCTkYaUl8HDImYxVHmkXDMo4N0czKYeCuAd2M+SKW4f1alB3ANUmh3PNHNOylTwbgYqXR+dESuuwn321gGyWukOYWcTjg2UJzSemHSSDgVwDJlJPB7pKhvXLrrVQMHIr1oLsH97fBm4rM7lI464LVEIlGXj3BsAV6mg6KlMaDBYeEYhnRRPyWGPnYJEjy9GrjRcdfFJ+F4hw5SzTMSDo1zzCPe27INjgpjH+DHwInEO9W5C3AOUol8nKNuYzPxaU2Rjjc0RJG7cChLkHqOcaXeQf+1HDgf+IInk7UU+CzwW6RYsYviscmD59CiHsbGIIRjo35ZXNnsoBk6FTgX/477H6biMdnBF2qNB+O/DHg1kUikta7SCkcikdgKvESa7ZkIsxa3Tnr2QJoTDcFPDkDiOmMdc1VWeTD2L5JBfCNTiwOkac5LJhxF4SAkK9RnPgUkcCcjttXiiPMmQQtSUT6jWsOZCscq4NkYC4crTZFqgCOQbEvfORV3tmqbkYp4cQ6QLgNmZuKmZCwcMXdXVjs0IUboamtIstjXkMNyYQdLW5A6JHEuXvSCehYZkc0239sxtToWOWRx7IFfvUnT0UPFY7gD17KG+B6/aACeJIs6w9kIxwrkeHTcUm8/wI1dlc7IAbZOphfbcYBaHWGn2a/XRSaOvAU8n0gkMo7hZCwc+qUvEK+j9puQuoouBL0GqXAYO7ssJzlgdWymg6rfEedJpHBPxmSbkTgPeCpGA7YEdxpPjUGaKxs7Mwk52xJmrKOJDLcqI8bHwLR0Z1PyEg798qx8Icf5L24EfKvU2uhiGtHu+HyKcOt+NqhJHzdXfRpS6jErcjkD8RLweIx8Oxc61fdHyu0Z7XMgsusUFi1IPCxOhZjXAfcnEomsF8+shSORSKwB7iceW7NzcGOLbaSa40b7DFVxDbOgzgpdbOLCM8DTufzFXE9dTtcfjbpvN5/wA6OVSDuDWtOGtHP1UMLt37oROT0aB9YDDyQSieVFE45EIrESuDfiVsccYKED19EbKThspGeyWh5hUYcc+IxDBul/8gk55FPn4XHgsQgP3AzSFGQtopti8Y3MGITU7AirPkkLMJfopyR8DPyFDlo8Fkw4EonEWqRu5MIIDtw6XTnqQr6OarU2epgmZDxf9yHc3aflSD5TlHkceDTfB5EPTwP3Eb2u9m/pyhE2fZG+I0bmTCLcQ4DrkaMXUT0p+wFwJ3k2yMpLOPQk3Z+RhjtR4hnCzwIsQZK+9jEtyIrxhFurpEXn++wIjl0D0hRrWhCmX77MBm4hw3P8DrAQ+LcjbsqhWNJXtnRF+uSGWR1tEdIbN2o8j1SWzzuJLQjhaAHuAh6MiMvyDG5sqfUzNyVnJocsuJuRoxdLIjRmS5CyjO8H8WVBRac3IFWqXe/Bsg4JDIWdMl+CHKGfaBqQE3shza3DZA7wr4iMVz3wNyRxMxCC3NaaBVyPG1uc7fEEbiSuVSOVvqpMA3JiOFKTNMy2EauBv+POIcmOPIJpwK8IsH9Q0AN/JxLvcLGU/ArgHkeEbZC5KXlbbC7ULnkB2VV0mblI+9BA0yaCFo4W4AY1iVzqjtYCPEyOefkBU6qiMd7e/7yYTLinZUHq1d6DuwV+liMV458rxCQOmjXAVUjwyJVg6VzgVn3QYdMTaelYYu9+XuyBGy0kXgRux7009A1Iz+E7CrX6FYL3gMtwI8NuM7IFNcORB3oAsL+993nTA8mBCbuk4BbgT8jBT1eoA/4P+EWhFu9CBpdeV/F4JcQBbEaiyXc68kA7IWX/a+y9D4SDcKN9wgdI8NGF7dlGJD3iKgpYMqLQUenngUv1n2HwNPAz3Gnftx9wpL3vgTGF8LdlW3kCuJEM+q4WkAbk8NoVhZ7zxdjOega4SAe2mLwC/BB4xyFr41ykC70RDLsiuTClDlxLg7rEtxJOvKMOuFmt/I8K/WOlRXyJL0aCSMVI9Z4FfA+32lYeDhxj73rg8/dgpBiSC2xQC/cuinsIbo3GM36E7KQQF+FAV/5LgR8jRYILxTTg2wRwkCdAapDGQrX2rgfOAYRbFWxHliF9b2+lOP163tJF8jqKuGtY7Ij0SuCXwJv6Ih1FcEk8G1Tpf40bR+bb8jks4atQjAH2xq1zIx+qeKwGvkFh8k2akHypGylAnoZrwoGacI8huy7HAF9SczOfIrQvqcL/E/dO6Q5HYjx2CrYwVOk8egJ3WnmCZCpfh1QL+zbBlk94Bdkp/HtYghnmHvhSJD39aRWOTyPVsAZm+Pc3I1W8HkQOG81xcFJXAN/FKpgXmsOB3ZCGYS6xHqlX8zpwFnAi+dVMfVMXx/uQE96hJViWOzC47+vnYTU7x7Gt+XIvpP5CpQrFOiRiPFsfxlvIHnqToxP6FCRvo9Te7YIyFDjMQeFo5XUktncv8BldJMdnaIUuBmaqRTVD7zHsWjJOCEcrH+vnOaCbfjojgcUKHayN+lnnwuClYTxwCW4F7uJKmborf0YyOV1kA5JJPRtJAx+uC+RoJAu2m97HBrY1uH4TaeGxSF0fZ8oVljs4wC0qDOsiPJF3QTL3zEUpHvsiOR0zHL/OzWo1zEN2/jrpwliJnF+qR7I/63CjWVhkhCPqdAeuBI4zF6Wo9FbXcEaErnkrbgV0M8YmdrBUIpl7p+NOUpIvlALHq/lvmHBEhnIkO/bruHHwykcGq2gbJhyRoDPwfeByrLlSmFSouzLFhsKEIwq+9dUmGk5ZHeeriBgmHM5RguQP/BTJDLUaG+64jMcDJ2NV1kw4HKMKmIpUWTqX/NLljcJYgd9BKqEbJhxO0B85e/BnpBOb4SaTkLhTdxuKwph1RmbUIke4v6amsJnBblOGBEoXA0kcTqYy4YgnPYE9kVO8p9oKFjmX8gIkC/kmJJ3bMOEoGJXIKd29kUNJR+NObUsjO7oBP0AOlN1I+O0/TThiRmcVh5FIb9JDgQMJv1uYkT9dkYzefsBPCLirmQmHf/RC9v3HqXWxN7C7uidG/Ob6eUBfJOYxy4bEhCNTStQFGYmcaZiMxC9GIY2gjfhzvC4WNyMFcVbYkJhwpKIaSdQapy7IXvrnIfb4vWUicL26o39EurA12LCYcHRRl2Misp+/u1oZve2RG0oNcBpyruVBpMLWi7jRX9iEo8jshtSfnKqCsRuWCm50zDDkVPPnVDieRIpfv0dEa2WYcGTOQOAkffgTscNmRvYM1s+RSLm+t9lW23Y+Uk283oYpPsJxItK7Yj9kz94w8qGWbTtsn0M6oy1FeqXMB94FFiBFspeacESPfsC3gC/rSmEYQVODBNZbWxrUI1moa5GObR8iHQrfRNpzuFxx34QDKYX/XSSeYQlaRrGoRJqG90GC7SBV1depkMxHmiU9rf+M7U5N1ISjDDmZekGbB2cYYdJJP/2R+NrRwFeR2MhTSLOweXG76SgJRyVSZetCrFeJ4S6d1bUZguzuXQA8gpRhmBOXm4yKcNQAVwDfxAKgRjQoQc7IjEOaLx0P/AH4EzHIFYlCIZ/uyMGkC000jIhShXRsuwbplxz5ymSuC0dP4Fqs5YARDzohW7w3I+kDkS0G5bJwVCI7J2djOydGfCgFDlHxOIqIlu909aLLgLOQMn0mGkYcmYBUJTsxipaHi8JRguRnXIodSjPizTCkNsi+Jhz5Mw7ZQRll88rwgHEqHpHKfnZNOPogJd4OsflkeMRhulh2MeHInnLgTKSSuGH4RBlSRf88IhLvcEk49kGCoVU2jwwP6QycQ0RyPFwRjlokv3+0zR/DY8aq1eF8RrcrwnE4khhjGD5TjmzPHmDCkZ5dgK+o1WEYvjNErQ6nA6WlDvz+EfoxDEOCo1OBg0042qc/Ek227FDD2P69OBrZbTHhSKGs+2I5G4aR6r08EIeTIMMUjh7AyVj7AsNIxVgkMcyEYwfGIKXoDcPYmRpkt9HJandhCUcV0n6vj80Pw2iXSfox4VD6mrVhGGkZjBRANuFAgqLjkE7xhmG0TxkwHqld6r1wVCK7KRYUNYz0jAF2NeGQ4sP72XwwjIwYgoPbsmEIxwBX/TbDcJC+6q54LRxlSHyjn80Hw8iI1pigU9uyxRaOch2EUpsPhpExg5FWId4KRyUS7DEMI3N64tjp8WILRw+sWbRhZEsv5OCbt8LRFQmOGoaR3YLb12fh6I3lbxhGLi5+fxwqZFxa5N/aRQfBMIzsGODSoltM4ShRi6Pc5oBhZE0vX4UDc1MMI2eqgQpfLY5qe/6GkbNwOGOtF1s4rLaoYeRGla8Wh2EY+QmHlxZHM7Denr9h5ESlr8IBsM6ev2HkbHE401e52MKxXi0PwzCyowRPE8CagcVAnc0Bw8iaLS69O8UUjhZgCbDM5oBhZM1mYKuvrsoqYJ7NAcPImo0+C8dm4F2bA4aRNYuBtb4KRwMwS90WwzAyZ75aHV4KRxPwig6CYRiZsQZY4NKCG0bm6BLgBZsLhpGVm/KBSxcUhnBsBqabu2IYGfO6CQc0qsUxx+aDYaSlAXgJWO27cAAsBO43q8Mw0jIfeNW1iwpLOLYAjwJLbV4YRofMBOaacGzjbeARmxeG0S6rgSdwKH/DBeFYB/wNWGHzwzBSMgvZSHCOsAv5vKTiYRjG9tSpO7/YhGNnNgJ3IcFSwzC2MRN4yNWLc6F04GvAndgOi2G0XVD/imSLmnB0YJLdoW6LYRiS53SvyxfoSrHid4GbsNKChrEKuB1YbsKRGQ+6rrKGUWBakLjGA65fqEvCsV6tjtds/hie8g7wG2CTCUd2vAb8HMvtMPxjC/C/OJheHgXhADnD8r/I4R7D8IUHgNuicrEuCkcd8Nso+HmGERBvANfiYGp5lIQDJKJ8NVbwx4g/q1U03ozSRbvcO/ZNIIEVNzbiSz0SDL0vahfuetPpZ4CriOfx+y1IrYVXkKJGvgeE1yDHx19FMia3eHDPfwF+pQISKcodv75mJLejVgWkT0z82fuA54APddKUAt2B8cBngaOAHh7597cDzwMr9ZlXAoOAg4GTgD1jeN9PAUkVTEw4gqcB+CNQDVwB9IywL/sHJHK+UAVjx/M5ryO7SlOAbwHHRuQZ5fpc/wr8BKmnueOqO0/F9Q7gdOB8YEBM7v0l4HIcqyMaJ1dlR1/w5xFV6PnAN3SFmYd05Ep1qK8J2ABMA84FfqSrcNxoVCvjO0gMK5Wp3qLjNB+4DjgHOTEadWYBFxORfI2oC0frZLsBuAb4OGKicSHwjyz89ha1UH4G/ABHazLk4X4+rq5nps+xAXgS+Ka6NFE8Sd2iYnGRWhwtJhzFtTxuVJclCi/TGmRn6Am1JnJ5yW4B/gd4LybC8WqOz69FLY5LgBkRe/FagNm6gMwgBiUkSiN4zU07vEyuPoRm4GaNWTTl+V33qOUR9YJHi4AfIrGcXJmppn6UVu031NJ4npjUnSmN6HW36Mv0dSRJrMnBa5yDBPaC2la8F/hFhGMeGzVW8a8AvmumCpDrrUSbkfNXFwHPxsjdjKxwtDIN+KrGDzY7dF2NyE7Q+wF/783IzsymiD2nRuT80e0BrrjT1G11tYbLVuAx4DwcLTjss3CAtFn4JnA90pfWBZ5D6osEfVCvCdlZupPoJA01InkrvyT4pK5bgbv1N1xinbrT5xPx3ZM4CwdqvidUQP4T8ku1AakrUqh4xHpkm/aOCFgedepSXgp8VKBV/VrH3IAPgSuB7zm0kAVO3JKLHkACUecDnweGF/n31yApxI9T2CDYCuAynaRnAUMdfBbz1Rr4NYXdPv8Q+DHQG9gj5Ht+GUkXeJCYE8esxA+QrLzHgLOBqUj6cqFX1rka17iN4sRbViG5ELOQzMpDgIEO+PUL1AK4s4iWwLPA95E8n5Eh3PcKZPfsJl24MOGILtN1BZgKHIecexgBVAToxy5FtoSfQ9pZhtHj8xF1z6YCRwCT1dLqVUR/fjESCH4RCVq+GkLc4RF1vb+jz7qsCL+5CdnVuw34py4gmHBEny3Aw0jW4T7A/sAkFZCeQGedbM36adJP2/9dr9+zCSm0sgJYpjGMd1Q4VoV8nxt0xXsIGA1MULN9FLCbikgPoEuOz7xeBWKtumMrdRw+QlLo56prEvY4PIQEy89ADguOBroV4HdWq6X3oP7mIjyj3JP7rNeV4QXkFOog9YlrdWVq0hWysc2fm5BdkVbhaBWPdbi7o9GkL/FcjS/0BnYB+uo/ewOdgBr9dG7z52Z1Ner0/ura3PsaFcvlKg5r9eNicPZ9deHuVetrXxWQXYF+Kp7ZzJvWz3ok2Pm6ukYz8LgDYUlLizVQMwwjO0ptCAzDMOEwDMOEwzAMEw7DMEw4DMMw4TAMw8iA/x8AsOcMuf3EgO4AAAAASUVORK5CYII=";
                $scope.ItemInsertAnimal.ctg = null;
                $scope.stepWizard = 1;
            };
            $scope.resetRegistration();

            $scope.getCtgName = function (id) {
                try {
                    for (var i = 0; i < $scope.animalCategory.length; i++) {
                        if ($scope.animalCategory[i].id == id) {
                            return $scope.animalCategory[i].animalstype;
                        }
                    }
                } catch (err) {

                }

            };

            $scope.getSex = function (id) {
                if (id == 1) {
                    return 'مرد';
                } else {
                    return 'زن';
                }
            };

            $scope.SendDataToServer = function () {
                if ($cordovaNetwork.isOnline()) {

                    var strMobile = $scope.user.mobile;

                    if (strMobile.length < 11) {
                        strMobile = '0' + strMobile;
                    }

                    if (isValidPhone(strMobile))
                    {
                        $scope.user.mobile = strMobile;
                        var data = {
                            'user': $scope.user,
                            'animal': $scope.ItemInsertAnimal
                        };

                        $http({
                            method: 'post',
                            url: BaseUrl + '/MicroChip/InsertMicroChip',
                            data: data
                        }).success(function (response) {
                            $scope.error = true;
                            $scope.ErrorMsg = response.msg;
                            $scope.ErrorMsg = $scope.ErrorMsg.split(';');
                            $scope.TypeError = $scope.ErrorMsg[0];
                            if ($scope.TypeError == "success") {
                                $scope.SendOk = true;
                                $scope.showAlert('اطلاعات با موفقیت درج شد.منتظر تایید باشید');
                                $scope.resetRegistration();
                                $ionicHistory.clearHistory();
                                $state.go('about');
                            }
                            $scope.ErrorMsg = $scope.ErrorMsg[1];

                        }).error(function () {
                            $scope.showAlert('خطا در سرور رخ داده است');
                        });
                    } else {
                        $scope.showAlert('شماره موبایل را معتبر وارد کنید');
                    }
                } else {
                    $scope.showAlert('تلفن خود را به اینترنت متصل کنید');
                }
            };

            //use camera
            var options = {
                quality: 50,
                destinationType: Camera.DestinationType.DATA_URL,
                sourceType: Camera.PictureSourceType.CAMERA,
                allowEdit: true,
                encodingType: Camera.EncodingType.JPEG,
                targetWidth: 640,
                targetHeight: 480,
                popoverOptions: CameraPopoverOptions,
                saveToPhotoAlbum: false,
                correctOrientation: true
            };
            $scope.turnCamera = function () {
                $cordovaCamera.getPicture(options).then(function (imageData) {
                    convertImgToDataURLviaCanvas(imageData, function (base64image) {
                        $scope.ItemInsertAnimal['photo'] = base64image;
                    });
                }, function (err) {
                    console.error(err);
                });
            };
            var options = {
                maximumImagesCount: 1,
                width: 640,
                height: 480,
                quality: 50
            };
            function convertImgToDataURLviaCanvas(url, callback, outputFormat) {
                var img = new Image();
                img.crossOrigin = 'Anonymous';
                img.onload = function () {
                    var canvas = document.createElement('CANVAS');
                    var ctx = canvas.getContext('2d');
                    var dataURL;
                    canvas.height = options.height;
                    canvas.width = options.width;
                    ctx.drawImage(this, 0, 0);
                    dataURL = canvas.toDataURL(outputFormat);
                    callback(dataURL);
                    canvas = null;
                };
                img.src = url;
            }
            $scope.openGallery = function () {
                $cordovaImagePicker.getPictures(options)
                        .then(function (results) {
                            for (var i = 0; i < results.length; i++) {
                                convertImgToDataURLviaCanvas(results[i], function (base64Image) {
                                    $scope.ItemInsertAnimal['photo'] = base64Image;
                                });
                            }
                        }, function (error) {
                            // error getting photos
                        });
            };
            //set icon out-line
            $scope.focus = function (e) {
                var element = e.target.previousElementSibling.classList[2];
                e.target.previousElementSibling.classList.remove(element);
                e.target.previousElementSibling.classList.add(element.replace('-outline', ''));
            };
            $scope.blur = function (e) {
                var element = e.target.previousElementSibling.classList[2];
                e.target.previousElementSibling.classList.remove(element);
                e.target.previousElementSibling.classList.add(element + '-outline');
            };
        })
        .controller('LoginController', function ($scope, Salt, $state, Digest, $http, TokenHandler, $ionicModal, $ionicPopup, $rootScope, $cordovaSQLite, $ionicHistory) {
            console.log("run login controller");
            $scope.username = [];
            $scope.showAlert = function (str) {
                $ionicPopup.alert({
                    title: 'هشدار',
                    template: "<div style='direction:rtl;text-align:right'>" + str + "</div>",
                    buttons: [{// Array[Object] (optional). Buttons to place in the popup footer.
                            text: 'تایید',
                            type: 'button-default btn-submit'
                        }]
                });
            };
            $scope.loginToSite = function () {

                $http.get(BaseUrl + "/mobile/mobile/user.json",
                        {headers: {'x-wsse': 'UsernameToken Username="' + $scope.userNameLogin + '", PasswordDigest="' + $scope.passwordLogin + '"'}}).success(function (response) {

                    window.localStorage['logined'] = 'UsernameToken Username="' + $scope.userNameLogin + '", PasswordDigest="' + $scope.passwordLogin + '"';
                    window.localStorage['userId'] = response.id;
                    $rootScope.loginInfo = window.localStorage['logined'];
                    $rootScope.userID = response.id;
                    $rootScope.LoginUser = true;
                    $state.go('contact');
                    if (response.photo) {
                        $rootScope.imgProfile = response.photo;
                    } else {
                        $rootScope.imgProfile = imageProfileDefualt;
                    }
                    $rootScope.ShowHidden = function () {
                        if ($rootScope.LoginUser) {
                            return 'ng-hide';
                        } else {
                            return 'ng-show';
                        }
                    };
                    var query = "INSERT INTO fos_user VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

                    if (response.photo == null || response.photo == '' || typeof response.photo == "undefined") {
                        response.photo = imageProfileDefualt;
                    }

                    if (db == null) {
                        db = $cordovaSQLite.openDB("abanpet.db");
                    }
                    $cordovaSQLite.execute(db, query, [response.id, response.username, response.username_canonical, response.email,
                        null, response.enabled, response.salt, response.password, null,
                        null, null, null, null, null, null, null, null, response.name, response.family, response.phone,
                        response.mobile, response.sex, response.post_code, null,
                        response.address, response.photo]).then(function (data) {
                        if (data.rows.length > 0) {
                            flagReadMessage = true;
                        }
                    }, function (err) {
                        console.error(err);
                    });
                }).error(function (error, status) {
                    if (status == 403) {
                        $scope.showAlert('اطلاعات شما معتبر نمی باشد');
                    } else if (status == 404) {
                        $scope.showAlert('اینترنت شما ممکن است قطع باشد' + 'Error 404');
                    } else {
                        $scope.showAlert('با برنامه نویس تماس بگیرید');
                    }

                });
            };

            $ionicModal.fromTemplateUrl('partials/setting/modalResetPassword.html', {
                scope: $scope,
                animation: 'scale-in'
            }).then(function (modal) {
                $scope.modal = modal;
            });

            $scope.openModal = function () {
                $scope.modal.show();
            };

            $scope.closeModal = function () {
                $scope.modal.hide();
            };

            $scope.resetPassword = function () {
                //http://abanpet.com/resetting/send-email

                console.log($scope.username.username);

                var strMobile = $scope.username.username;
                if (!(strMobile.substring(0, 1) == '0' && strMobile.length == 11)) {
                    $scope.username.username = '0' + $scope.username.username;
                }
                console.log($scope.username.username);

                var dataResset = {
                    'username': $scope.username.username
                };
                $http({
                    method: 'POST',
                    url: BaseUrl + '/resetting/send-email',
                    data: dataResset
                }).then(function (responce) {
                    $scope.showAlert(responce.data.message);
                    $scope.closeModal();
                    $state.go('login');
                }, function (err, status) {
                    console.error(err);
                });
            };

            $scope.focus = function (e) {
                var element = e.target.previousElementSibling.classList[2];
                e.target.previousElementSibling.classList.remove(element);
                e.target.previousElementSibling.classList.add(element.replace('-outline', ''));
            };
            $scope.blur = function (e) {
                var element = e.target.previousElementSibling.classList[2];
                e.target.previousElementSibling.classList.remove(element);
                e.target.previousElementSibling.classList.add(element + '-outline');
            };
        })
        .controller('MenuController', function ($scope, $rootScope, $state, $cordovaSQLite, $ionicHistory) {
            $scope.logOutUser = function () {
                $rootScope.loginInfo = null;
                $rootScope.userID = null;
                $rootScope.LoginUser = false;
                window.localStorage['logined'] = "";
                window.localStorage['userId'] = "";
                $rootScope.imgProfile = imageProfileDefualt;

                $ionicHistory.clearHistory();
                $ionicHistory.clearCache();

                var query = "delete from user_message";
                $cordovaSQLite.execute(db, query, []).then(function (data) {
                });

                query = "delete from animals";
                $cordovaSQLite.execute(db, query, []).then(function (data) {
                });

                query = "delete from animalsphoto";
                $cordovaSQLite.execute(db, query, []).then(function (data) {
                });

                query = "delete from fos_user";
                $cordovaSQLite.execute(db, query, []).then(function (data) {
                });

                query = "delete from animalscategory";
                $cordovaSQLite.execute(db, query, []).then(function (data) {
                });

                $state.go('login');
            };
        })
        .controller('SearchController', function ($scope, $ionicSideMenuDelegate) {

        })
        .controller('ContactController', function ($scope, $state, $cordovaNetwork, $location, $ionicPopup, $http) {
            // alert(mobileNumber);
            $scope.showAlert = function (str) {
                $ionicPopup.alert({
                    title: 'هشدار',
                    template: "<div style='direction:rtl;text-align:right'>" + str + "</div>",
                    buttons: [{// Array[Object] (optional). Buttons to place in the popup footer.
                            text: 'تایید',
                            type: 'button-default btn-submit'
                        }]
                });
            };
            $scope.focus = function (e) {
                var element = e.target.previousElementSibling.classList[2];
                e.target.previousElementSibling.classList.remove(element);
                e.target.previousElementSibling.classList.add(element.replace('-outline', ''));
            };
            $scope.blur = function (e) {
                var element = e.target.previousElementSibling.classList[2];
                e.target.previousElementSibling.classList.remove(element);
                e.target.previousElementSibling.classList.add(element + '-outline');
            };
            $scope.goToMap = function () {
                if (!$cordovaNetwork.isOnline()) {
                    $scope.showAlert("لطفا ارتباط اینترنت خود را چک کنید");
                } else {
                    $state.go('map');
                }
            };
            $scope.goToSendMessage = function () {
                if (!$cordovaNetwork.isOnline()) {
                    $scope.showAlert("لطفا ارتباط اینترنت خود را چک کنید");
                } else {
                    $state.go('sendMsg');
                }
            };
            $scope.messageContact = {};
            $scope.SendMessageContact = function () {
                if (!$scope.messageContact.name || $scope.messageContact.name.length < 3) {
                    $scope.showAlert("لطفا نام خود را به درستی وارد کنید");
                    return false;
                }

                if (!$scope.messageContact.email || !validateEmail($scope.messageContact.email)) {
                    $scope.showAlert("لطفا ایمیل خود را به درستی وارد کنید");
                    return false;
                }

                if (!$scope.messageContact.phone || $scope.messageContact.phone.length !== 11) {
                    $scope.showAlert("لطفا شماره موبایل خود را به درستی وارد کنید");
                    return false;
                }

                if (!$scope.messageContact.subject) {
                    $scope.showAlert("لطفا موضوع را وارد کنید");
                    return false;
                }

                if (!$scope.messageContact.msg) {
                    $scope.showAlert("لطفا متن پیام را وارد کنید");
                    return false;
                }

                $http({
                    method: 'POST',
                    url: BaseUrl + '/contact',
                    data: $scope.messageContact
                }).then(function (responce) {

                    if (responce.data == 'ok' && responce.status == 200) {
                        $scope.showAlert("پیام شما ارسال گردید");
                        $scope.messageContact = {};
                    }
                },
                        function (err, status) {
                            console.error(err);
                        });
            };
        })
        .controller('RegisterController', function ($http, $location, $ionicNavBarDelegate, $rootScope, $cordovaNetwork, $scope, $state, $ionicPopup, $ionicHistory, $cordovaSQLite, $ionicModal) {


            $scope.showAlert = function (str) {
                var alertPopup = $ionicPopup.alert({
                    title: 'هشدار',
                    template: "<div style='direction:rtl;text-align:right'>" + str + "</div>",
                    buttons: [{// Array[Object] (optional). Buttons to place in the popup footer.
                            text: 'تایید',
                            type: 'button-default btn-submit'
                        }]
                });
            };

            $ionicModal.fromTemplateUrl('partials/setting/modalRegister.html', {
                scope: $scope,
                animation: 'scale-in'
            }).then(function (modal) {
                $scope.modal = modal;
            });

            $scope.openModal = function () {
                $scope.modal.show();
            };

            $scope.closeModal = function () {
                $scope.modal.hide();
            };


            $scope.user = {};
            $scope.user.sex = 0;
            $scope.onRegister = function () {
                if (!$scope.user.name || $scope.user.name.length < 3) {
                    $scope.showAlert("لطفا نام خود را به درستی وارد کنید");
                    return false;
                }
                if (!$scope.user.family || $scope.user.family.length < 3) {
                    $scope.showAlert("لطفا نام خانوادگی خود را به درستی وارد کنید");
                    return false;
                }
                if (!$scope.user.email || !validateEmail($scope.user.email)) {
                    $scope.showAlert("لطفا ایمیل خود را به درستی وارد کنید");
                    return false;
                }
                if (!$scope.user.mobile || $scope.user.mobile.length !== 10) {
                    $scope.showAlert("لطفا شماره موبایل خود را به درستی وارد کنید");
                    return false;
                }


                //$scope.user.mobile = "0" + $scope.user.mobile;

                var data = {
                    'user': $scope.user
                };

                $http({
                    method: 'POST',
                    url: BaseUrl + '/mr/regs/users/mobiles.json',
                    data: data
                }).then(function (response) {
                    if (response.data.status == 0) {
                        console.log(response.data.Message);
                    } else {
                        $scope.openModal();
                    }

                }, function (err, status) {
                    //console.error('error: ' + err + ' status: ' + status);
                });



            };
            $scope.loginToSite = function () {

                $http.get(BaseUrl + "/mobile/mobile/user.json",
                        {headers: {'x-wsse': 'UsernameToken Username="' + $scope.user.mobile + '", PasswordDigest="' + $scope.mdCode.code + '"'}}).success(function (response) {

                    window.localStorage['logined'] = 'UsernameToken Username="' + $scope.user.mobile + '", PasswordDigest="' + $scope.mdCode.code + '"';
                    window.localStorage['userId'] = response.id;

                    $rootScope.loginInfo = window.localStorage['logined'];
                    $rootScope.userID = response.id;
                    $rootScope.LoginUser = true;
                    //window.location.href = "#/about";
                    $state.go('contact');
                    $scope.closeModal();
                    $ionicHistory.clearHistory();

                    $ionicHistory.nextViewOptions({
                        disableAnimate: true,
                        disableBack: true
                    });

                    $ionicNavBarDelegate.showBackButton(true);

                    $rootScope.imgProfile = response.photo;
                    //console.log($rootScope.imgProfile);
                    $rootScope.ShowHidden = function () {
                        if ($rootScope.LoginUser) {
                            return 'ng-hide';
                        } else {
                            return 'ng-show';
                        }
                    };

                    var query = "INSERT INTO fos_user VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
                    $cordovaSQLite.execute(db, query, [response.id, response.username, response.username_canonical, response.email,
                        null, response.enabled, response.salt, response.password, null,
                        null, null, null, null, null, null, null, null, response.name, response.family, response.phone,
                        response.mobile, response.sex, response.post_code, null,
                        response.address, response.photo]).then(function (data) {
                        if (data.rows.length > 0) {
                            flagReadMessage = true;

                        }
                    }, function (err) {
                        console.error(err);
                    });
                }).error(function (error, status) {
                    if (status == 403) {
                        $scope.showAlert('اطلاعات شما معتبر نمی باشد');
                    } else if (status == 404) {
                        $scope.showAlert('اینترنت شما ممکن است قطع باشد');
                    }

                });
            };
            $scope.mdCode = {};
            $scope.submitOKmdCode = function () {
                $http.get(BaseUrl + '/mr/finds/' + $scope.mdCode.code + '/users/' + $scope.user.mobile + '/by/token.json'
                        ).success(function (response) {
                    if (response.status == 0) {
                        $scope.showAlert('کد شما اشتباه است');
                        return false;
                    }
                    $scope.loginToSite();
                });
            };


            $scope.focus = function (e) {
                var element = e.target.previousElementSibling.classList[2];
                e.target.previousElementSibling.classList.remove(element);
                e.target.previousElementSibling.classList.add(element.replace('-outline', ''));
            };
            $scope.blur = function (e) {
                var element = e.target.previousElementSibling.classList[2];
                e.target.previousElementSibling.classList.remove(element);
                e.target.previousElementSibling.classList.add(element + '-outline');
            };
        })
        .controller('PanelController', function ($http, $cordovaToast, $state, $jrCrop, $rootScope, $cordovaNetwork, $ionicPopup, $scope, $cordovaSQLite, $ionicSlideBoxDelegate, $ionicModal, $cordovaCamera, $cordovaImagePicker) {
            $scope.user = {};
            $scope.showAlert = function (str) {
                $ionicPopup.alert({
                    title: 'هشدار',
                    template: "<div style='direction:rtl;text-align:right'>" + str + "</div>",
                    buttons: [{// Array[Object] (optional). Buttons to place in the popup footer.
                            text: 'تایید',
                            type: 'button-default btn-submit'
                        }]
                });
            };
            $scope.ShowToast = function (str) {
                $cordovaToast
                        .show(str, 'long', 'bottom')
                        .then(function (success) {
                            // success
                        }, function (error) {
                            // error
                        });
            };
            setTimeout(function () {
                if ($rootScope.LoginUser) {
                    var query = "SELECT * FROM fos_user WHERE id = ?";
                    $cordovaSQLite.execute(db, query, [$rootScope.userID]).then(function (data) {
                        if (data.rows.length > 0) {
                            $rootScope.imgProfile = data.rows.item(0).photo;
                            $scope.user.id = data.rows.item(0).id;
                            $scope.user.username = data.rows.item(0).username;
                            $scope.user.email = data.rows.item(0).email;
                            $scope.user.enabled = data.rows.item(0).enabled;
                            $scope.user.salt = data.rows.item(0).salt;
                            $scope.user.password = data.rows.item(0).password;
                            $scope.user.name = data.rows.item(0).name;
                            $scope.user.family = data.rows.item(0).family;
                            $scope.user.phone = data.rows.item(0).phone;
                            $scope.user.mobile = data.rows.item(0).mobile;
                            $scope.user.sex = data.rows.item(0).sex;
                            $scope.user.post_code = data.rows.item(0).post_code;
                            $scope.user.address = data.rows.item(0).address;

                            if (data.rows.item(0).photo == null || data.rows.item(0).photo == '' || typeof data.rows.item(0).photo == "undefined") {
                                $scope.user.photo = imageProfileDefualt;
                            } else {
                                $scope.user.photo = data.rows.item(0).photo;
                            }

                        } else {
                            if ($cordovaNetwork.isOnline()) {
                                $http.get(BaseUrl + '/mobile/mobile/user.json',
                                        {headers: {'x-wsse': 'UsernameToken Username="' + $rootScope.loginInfo}}).success(function (response) {
                                    $scope.user = response;
                                    if (!$scope.user.photo) {
                                        $scope.user.photo = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAnIAAAJyCAYAAABALi2VAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAfqlJREFUeNrs3Ql8VOW9x/+TZDKTyWRfSEIWIGETCAHZBFmsuNWlWqFWe61aa2t7tf3bf5frtb1tvfq3V6pite3VutYVlyqKGwoq+xogELZAFiAJJCH7ZCaTjf/zG3m4hxhgQiYb+bxfr3nNzMkkmTxzTp7vec6zBBw7dswAAABA/xNIEQAAABDkAAAAQJADAAAAQQ4AAIAgBwAAAIIcAAAACHIAAAAEOQAAABDkAAAAQJADAAAAQQ4AAIAgBwAAAIIcAAAACHIAAAAEOQAAABDkAAAAQJADAAAAQQ4AAIAgBwAAAIIcAAAACHIAAAAEOQAAABDkAAAAQJADAAAAQQ4AAIAgBwAAAIIcAAAACHIAAAAEOQAAABDkAAAAQJADAAAgyAEAAIAgBwAAAIIcAAAACHIAAAAEOQAAABDkAAAAQJADAAAgyAEAAIAgBwAAAIIcAAAACHIAAAAEOQAAABDkAAAAQJADAAAgyAEAAIAgBwAAAIIcAAAACHIAAAAEOQAAABDkAAAA0BkWigAwjO3bt3fLzw0ICDCam5sNj8djREREGA6Hw2hrazMWL17svY+JiTGsVqsxbNgwIzIy0liyZIlxxRVXGAkJCcauXbuMLVu2GCEhId6fYbPZjJqaGmP+/PlGbm6ukZKS4n3fs2bNMt5++20jOzvbeOCBB4x//OMfRnV1tXH11VcbzzzzjHH55ZcbSUlJ3tfL79i0aZOxevVq4yc/+Ylx6NAhY9++fUZhYaH3940YMcJ48MEHjZUrVxp79+71fm3//v3e3ye/Y+jQocaBAweM0tJSo7i42CgpKTHKy8uNoqIi44ILLjB+/etfGzk5OUZDQ4P3b5Z7t9ttOJ1O7/Of/vSnRlBQkNHa2mq0tLR4y0DuGxsbva+R5/L3Hjt2TN5TgPq9QfIz1POAe+65J0i9LqKpqSlE/Uy5hapysZ6u/NXvCdKP5Wfqz0R+XnBwcIv6XS5136zuG2NjY+tVeTnLysqOqefHAgMDjfj4+GPDhw9vS0xMlG2Geq1ht9tlu/Huu+8a27Zt85ZJamqqkZWVZdx5553ev0E+z9GjRxsXX3yxUVVVZTzyyCPGXXfdZWzYsMFYtWqVcdVVVxlz5871Ph8zZoxRUFBgTJkyxdi8ebMxbdo0Y82aNUZmZqbx6aefGmPHjvV+7haLxfsZTpo0yVi0aJExe/ZsY+rUqRy8AEEOAHqGhFEJJO2CXIB8Sd071PPg0NBQt3oeqALTMPX6sWq7XYU36yuvvBKhgtx3VHgLVPeBKsgFqa8FHtMJrQPq5wV0tF2CnArQbernt6lw5r1Xv++Lurq6AnV/TMKdCnLH1PYKFeDy1XsqlbCn3nurhD8JdRJIT/OrAYAgB6D/kGCjgk+MCkgpKmyFqRAVogJRuAQxFYDCVHiz/uMf/4hwuVx3qBAW0NDQECAtcR6PJ0C9PkCFtaD6+nppfTomrXBqm01a31RYkrAmrwlS9/LcMN/OlrTMyU0/Vsao99skLXGS9STIqb+pxeFweCTYSdiTVtW4uLi2pKSkXLVttXruVPcV6m8+oL6+W/2cOvYEAAQ5AL1Gh5sOyGXMSHVLVrcUdUs7fhsUFhYWt3z58uQPP/wwoa6uLkyCl1BhzhvC5CY/Wlrf1GObNyl1EMjkXgcsaa3r6f+HKlR+7X9iZWXlyS+yWOQS61AV9C6Vt6xubWpbS3R0dLUKcyXqXr6hSN12qdvK4/enK1cAIMgB6BxpeQr4SqC6Bcm9BC+XyxWvAk1Wc3Pzea2traPUtpFRUVFpN910U4z0OTt+uVKarQJ0a5lsO1Xwkt9jDmo61Jhb03R409v1z5LvPdXP1cHodK1y5vBk/t0daf9zJLDJ5d/2P0+2Hd9uM7/H2traCPV4iPSjy87OblM/r+3RRx9tHjRo0KHRo0dnNzY2fqS+7zP1M2rVrUW9toW9EABBDoDPwU0uf6qbRT0Oqa+vT3I6nRNUcButQka6CiDDVq5cOXzWrFnSFy1cwokOVRJcpF/b6cLSqYJVR0Gso/BlbpnTP0u+t6PQd7qf48vv6ehndRTYhJSZ+W9o/3fqr8nrhAzqUOXrDcWqfC2qLEeWlJSMXLVq1Tyr1dowZsyY7arMV6jgt1z9jK0qMDqNr1r2AIAgB+Dk0CIBIyQkJFiFikgVKs6rqKiYokLczN/85jdD1baJ0h9NbtJfTUbHns3v8Mf7PNXz033N37+3o+2nCrDtmV9nDn66BU8FPLk0bd2wYcOcnTt3zlm8ePFtkydP/iItLe0N9RmtVkG6nj0WAEEOILx5w5vdbg9Vt3gV3AYFBgbOXrp06YX5+fnfVs/lMiAF1UskLMt0IlVVVWn79++/dfXq1RdfddVV7w0ePPhVm82Wq0K3k9GwAAhywAAjl07Dw8ONsLCwpMLCwvHr1q27oqGhYfY///nPEUeOHAnv6PX6sqUeZNALAwwGZNAWEralH15xcXHq008/ffeyZcuuuPTSS5eqMPdmRETENofDUUegA0CQA85xEt5CQ0OTGhsbR7/zzjujd+/effXq1auv/Oijj74W3HSfM93PS18ObN8PDd1HylrPpSf96fTnkZ+fP1xur7zyyu033njj6xUVFYujo6O3qmBXzGcDgCAHnEOkYpdVImTajw8//HDOtm3bbt+zZ8/sjz/+OEyHNnMn/eNzo53UCqe/Zh4tip757HRfRPk85KYDtTx2Op32Z5999nYV9m6/+eab329qanomPT19swrqR/iMABDkgH4eAmSJqLi4uJA1a9Zcsnnz5h+8+eabl8uqCLIUljmsSTiQMKeDgnm0ZUchjpDQc/RnJJ+D/mz0cx3CZYDEyy+//K2UlJRp11xzzSfx8fGvjR49eqX6WiOfFQCCHNDPSCWvApys73nBsmXLfrp48eKLDx8+nGIOArrlTYcFqfB1a0/7ANd+El79GD0T4tp/TvqxfEZ6KhP57A4cOJDw7LPP3jp48OCL1PPn09PT/xQaGtrMZwWAIAf0kwCnKm4jMTFxxMsvv3xPbm7upYWFhSP0PGc6lJlb1tqHs/bzpbWfoJdQ0HM6Ws3CHLCFvvSqP1OZGqagoGDI448//psdO3aMycrKWpSUlLSY0gRAkAP6cIUvqwQkJydnPv/88z89cuTIbBXixrZfbcAcCE41/xpBrW99ru2D+qm+1v55XV2d49133/3upk2bLsrOzr5t4sSJi5YuXbro+uuvN1S4N6666ipj3bp1RlNTkyHbnnvuOSMyMlJOAow1a9YYd955p3fOwJUrVxrqZxh/+tOfjMOHD3t/z6RJkwy1j3lPGkpKSox9+/YZgwYNMo6vf3sicEZHR3sfh4WFGdOnTz+pFdhfRo8ezY4CEOSA/ksqx5iYmLAdO3bc8/bbb89T9xOkQgX7hbTSFRcXJ6jbtdu3b78gLi7u8pCQkOfVl1dRQgBBDkAvk1a4ioqK6AULFvxj/fr1V5eWloZIK5z0mzJfhsPAo1tdZV+QQCf95yorK29TYX/YxIkT31X7zlvqZaWUFECQA9ALpIJWFfPohx566M/Lly+/8vii9HqNVO8lMwzsIKdHt8pjaaGTS6Xr1q2btW/fvklHjx49f8yYMX9V+8kmSgsYGAIpAqD3He/UHllVVfXrn/3sZ69+9tlnV9lstkDdT07uJcSZJ/PFwNxPZH8wj1I+HugCKyoqwt54442bn3rqqX/Z7fZfqLAXzr4CnPtokQN6WVBQUIDT6Rz15z//+Q8ffPDBjTLlhMz873K5vF/X04eYp6TAgN1XvPPL6RU65F72FRnlqgNdeXl56v/8z//8ed++fTPi4+MfUN+Tp17bSOkB5yZa5IDePJOyWILcbvelP/jBD75YvHjxjSEhId4KWSpr3eJiXgOV0acDm3nKGT3nnGyTMKe3S8utCnZBixYtmv/yyy+vVZsfUs+Hq9fTPAcQ5AD4gwQyq9Ua5PF4vvnYY48tLCsrS5TK2Ol0nrhcpgc26MpbWuIY6ADdP87cMqvnnWsf9GtqahzPP//8HStXrnxJ7V+XqROFIC63AgQ5AF0IcNLHyeFwhNXV1X37hRde+N3OnTvHtJ8QFjjb/UvvR3p+t8rKyvDPP/98+q5du57ct2/f99RrYrtj7jcAvYM+ckAPVbDS4hYbG2vk5+dH79+//7fvvvvuvIKCgqF64XR9OZXLp+jKftZ+yS89UEadMIy47777nrjuuuu+ERUV9Ve1r22hxACCHAAfSCtcaWmpsWPHjsFLliz50xtvvHGLx+PxBjfdgd3c7wk4G3o0q778qlt49X1lZWXUCy+88IPp06dPVvva/ZGRkf+SlR0A9F+0rwPdTCpUWfboyJEjCffdd99Dr776qjfE6UldpX+TDnS6AgbOdl/TI1rNa+0KPepZrFmzJrOoqOiVRYsW/d7hcISzzwEEOQCnYLPZZBBDbHZ29q9VmPs36aSuW010patb4vQlWOCs/qGbBsqYRz3LTfY72Rd1aCspKQlZsGDB/WvXrv15VFRUtB4xDaB/ocYADP9O66ErTqvV6r3JQufvvPPOL1966aUf19fXW8yXv/RjubQqla5cguXSKrq6/+kwZ963zct7yf5mt9sNt9ttPPPMM7+qrq6eqva7P6akpGzVI2ABEOSAfkNaKvxFLps2NjZKfzijtrbWcvjw4d+99tprd1VUVIS37wNnDpB6SgmCHM7W6fYtoVcHEXpam6qqqih1kvGt3bt3D/7BD37wh9mzZ39UXFxMYQIEOaD/8Pd0DFJJqgoyeNeuXT9bsmTJHSUlJeG6QpUWkdO1mAD+0tH+pLeZW97kxGP16tWTCwsL//Hzn//8oVmzZv193759FCDQH+ovigDwPxXWAlXlOP/NN9+8v7i4OE5PCyF03zigr4U+ta8mP/DAA/+zcOHCFxISEmI5sQAIcsCAI5euXC7X8Keffvr+ysrKMOknp/vCmW9An6oMjp9o1NfXh7///vu3rlmz5o9hYWFRlAxAkAMGVIhrbGxM/Otf//qHgoKCETJ4QV/CYrJf9HX6pEPtwwGvvvrqjzZs2PCbkJCQSEoGIMgBfZrun9aVmwxU8Hg8Ya+99trPly5depNsax/imCsOffUERG4yGEJPXeJ2u21/+9vffrF+/fpHbDZbMq3IQN/EYAdAcblcXfp+CWh79uyxbN269Sdvv/32f8q0DrqClHnhdL84eZ200slgCMIc+tKJjJ6U2jz4prGxMeTll1++ff78+WHjxo37D7UPH6S0gL6FFjnA1CJxtjcJZ7W1tdcuWbLkNlnySIc23SqnBztIgNPTPgB9iZ76Rrcw6z5zTU1Nga+99tqN2dnZf1EnJam0zAF9Cy1ywFeVVZdCYENDQ/Kzzz577969e8fqpZDMge1U83sBfUX7/bL983/961/X2Wy2xtmzZ9/j8XjKKDGAIAf0GRUVFZ2u9CSwSatFZGSk8fe///0+FeImS6uG98A6fjkVOBfovp0qzM1X+3tFVlbWg2pzOSUDEOSAPiEiIqJTr5cAV1dXp29Za9asuba+vt5b4UmYY5kjnEv0Gq4ej8fywgsv3HnzzTcHX3LJJf+pttVQOgBBDuh1sbGxnXq9TNNQWVkpc27ZFy1adG9paWmS7l+k17IEzhVyYqJboBsbG62vv/76Hepx6+zZs++uqalhXkSgN0+0KALgq47enblJUAsLCwvPy8v793Xr1l2vKrpA88oNVGw4l5jnQJT93OVyWf75z3/e9dZbb90cHR19IuTR/xPoebTIAYqMOu2M0NBQo6amZvw777xzp9PptOqpG/TIPyo1nEv0KFbZv+VebjJA6PHHH//zsGHDdsbGxm4NCQkxwsPD6RsKEOSAnrd3795OVWqq4rKtW7fuB0eOHBkm2yTISSudVHCs4IBzNczpKXV0qCstLU18/fXXf3r33Xf/e2NjY4sM/GHfB3oWl1YB4/8WsvflJq13OTk553/66aeXNjQ0WHTrm9zM83AB5+oxovuAejweY9myZdeuWbPmlqioqCD2e6Dn0SIHGF8NXvC1VUIqrMOHD88qKCgY1NFlJFrkcK4yr/qgVVRUDHriiSd+Hx8fX3HNNdcsqa6upo8oQJADelZKSopPr7Pb7caOHTsmLF269OaGhoaQ9gGufSUHDASlpaVDFixY8Fd1ghMwYcKE9/USdWcrIyODQgUIcoDv9GoMZyKDHHbv3n3h1q1bx+nARoDDQCb7v7RMq+MiLTc399vjx49f2dTUxPxyAEEO6Dkff/yxTxWW3W5PWbVq1TWq4gqQ1Rv0Sg7tQxyXVzGQ6H6in3322fyJEycuve666xbJZNkACHJAjzjvvPPO+BqHw2GsXr168po1ay6S5xLiOgprEuIIchgo9GhWuVVUVIQVFxdnqc1vqhvzkAAEOaBnyPJaZxIYGBh85MiRb8hI1VMFNS6zYqDR+7xelm7ZsmXXzJgx482MjIytXe0rB4AgB/iksLDwjJVVW1tb8s6dOyef6WcR4jCQyP6uuxjIcaKOkbHr16+fP3LkyFyr1drM8QAQ5IBuN27cuNNWVHJZdceOHWM3btw4RVdYHYU2Ki0M5ECnVzdZvnz55VddddWLGRkZ+2iVAwhyQLeLiIg45deOh7aQAwcOXKQqpWBdaRHagK+OD/Ok2EIdKyP27NkzY9iwYfvV145xrAAEOaBbpaenn/JrspJDaWlp+Pbt20friou+cIBx4hiQVjh9XEioq62tjfj444+vnzZt2pLExMQq3X8OAEEO6Ban6yNns9mM8vLyCWVlZRPN4Y0QB3zFPPhHLq/KvHK5ubkzSkpKpkRGRi5tbGykkACCHNB9JKx1RFoXmpqaQlatWnV5UVFRst5OiAP+jxwPupVaL1tXU1MTt2/fvgvcbvdyl8vV0plluzIzMylUgCAH+C41NbXjA8RiMcrKykI3bNiQqSqjr/UHItAB/9dPTugRrE6nU6YimXnbbbfFJCUllbe0tFBQAEEO6B5FRUWnDHKHDx+eXF5ePkO3POgWB0Ic8H/kuND95OQmgW7Hjh2jHA5H6tChQ8ubmpooJIAgB3SPnTt3drg9KCgouKKi4vy6urowSgnomDm8ycmPPslpaGhIys3NnVtfX7+jpaXF5ySXlZVFoQIEOcB3W7ZsOVWQC1GVUGZ1dfXXKi5a5ICTjwlhPi6am5st2dnZc/Ly8p5TQa7S1591yy23UKAAQQ7w3c033/y1bdLnRwW4kF/96lcTZNSdnuy0M522gYGioy4Hcjl15cqVFz766KMRSUlJlfSTAwhyQLew2+1f2ybBrb6+Pvnw4cOpOtjpjtwA/o954I85yElwq6ioiFTHzkh1jBUS5ACCHNAtsrOzv7ZNVT5B1dXVMsghXJ4T4gDfQp3uM6dD3ebNm+cWFBSsUEHOpwnl5syZQ0ECBDnAd5s2bfraNlURBauKZ4KeVkEqJXmsR+cB+Noxc1KY09u2bNkyY/jw4SHqcSN9SwGCHOB3un+PuUJqbW0N2rVr1wTzot/m5bkAnDnYSXDLyckZv3DhQuugQYNo2QYIcoD/LViw4GsVUG1tbdDEiRNHykAHXSGZW+UAfKWjVjZ9rMi9OpbCKyoqktTzcl+C3JAhQyhUgCAH+O7w4cNfC3I1NTUxqgKKNFdUBDjA90BnPl727t07ToW5HW0+HESTJk2iMAGCHOC73NzcrwU5p9M5npIBuka3ZhcWFp5XVFQU2NraesYgxzxyAEEO6JQdO3ac9DwwMDDA5XIxvTzgJ3v37s288sorA2VaHwY8AAQ5wK9WrlzZflOgw+GYQMkAXaNDW0FBwahLLrkkJDQ0tIkgBxDkAL+68sorT3re1tbW+swzzxDkgC7Sl1YPHTo0bM+ePeepILfhTEGOwQ4AQQ7olFmzZp30vKWlZeh///d/p1IygH+CnMvlsm7ZsmV6a2vrxmNnSHKXX345BQcQ5ADf5eXltQ9yWarC4fgAukgGqVosFu9yXSUlJenf/e53ua4KEOQA/youLj7puQpxqQEBAVLhMPsv0EUyd1xwcLCsu5qQlJQUpY6tGkoFIMgBfmOeR+74VZ9EdU+IA7pIT6AtYe7o0aNXuFwuB0EOIMgBfnXXXXedeCzTI/z2t78doiofghzgRyrI2Z1OZ5hevxgAQQ7wC6vVag5yQUeOHEmnVICu0ws5SEt3VVWVUVRUlKEe7z3d93zjG9+g4ACCHOC70tJSc5BLLi8vz2KuK8A/9OXVmpqawB07dkyMjo7+iOMLIMgBfpOTk3Pisc1mG1dVVcW1H8CPQU6Cm/Q7raysHHzPPfcEtLS0kOQAghzgH9IRW8icVzIDfWNjYxClAviHhLjjYS5AHVvDXC5XqApyDZQMQJAD/GLevHnee5vNZjzwwAMxKtjRIgf4gZwcieN95QLcbvfckpKSJHWM7T/V94wfP56CAwhygO+kE/bxIGetrq6eIkFO9+sB0HW6T1xNTU1zcXFx2umCHACCHNAperCDCnKJdXV101WlQ4sc4KcAp0+IpHXu6NGjAfX19Q7dnQEAQQ7ospqar+YnDQ4OjlFBrkkqHFrjgK7Ta60KmaNRHV+BKswNIsgBBDnAbxobG3XrQYhUNMdH2FEwgB/JyZEMJCoqKkonyAEEOcBvmpubvfeBgYHBDQ0N3grH3JIA4OzIMWQe8KCOL0teXt7w6urqE9sBEOSALqmoqPDeW63WeKfTaaGCAfxHH08S6pqamgLUCVP0448/fqIlHABBDuiS7du3eyuZ8PDwkSrIWXWlA6Dr9LFksViMlpYW75J4U6ZMMdSxRuEABDmg6371q18ZDofDeOSRRxI9Hk8wJQL4N8jJdD7SL07um5qaRhYWFka73e7qjl4/dOhQCg0gyAG+i4mJMcLCwqS1IEz68dAaB3RPoBPqOLM5nc7QUwU5AAQ5oFOkj5zL5bKqimWmqmxYngvwEz1oSIe44/3kAqurq2MaGxtLKCGAIAd02dGjRyXIxaqbjdIAupfH47GoYy5W3VMYAEEO6Lry8nLDbrcPamxsDGbEKuA/7bspyPHV1NRkKSsrG6TuKSCAIAd0nbTI2Wy2OLfbzUAHoJsCnT5JOt4iF0eQAwhygF/I5KQqyEW5XC6LbkFgQmCge7S0tATW1dWFyVQkAAhyQJfV1tbK3FYR0lJAeAP8p6MTIgly6uQpimW6AIIc4BdyaTU4ODhW+sjpbQQ6wD9Bznw8He8jF1xWVpZAkAMIcoDfgpzFYomTVR0IcID/yLyMOsDpY0uW6ZJRqxxrAEEO8IucnBxj0KBBiS6XK8g8apWKBvAvOb6am5tl7sZBHF9A1wVSBIBhPPvss0ZsbGy0ntfKPIEpgK4Ft/akla62ttZeV1dndHQD4Dta5ABl3rx5xlNPPRWi14QkxAHdQx9bKSkpxoIFC4z6+noKBSDIAV1TUFBgNDQ0RJpbEJh+BOi69seRfhweHm6ZO3euUVVVRSEBBDmga8rLy8M9Hk+IPNadswF0n5aWFlndwVZdXf21dbpGjx5NAQEEOcB3paWlg1SQs+sWA1rjAP8wH0fSbUGfKLW2ttoOHz6cUFdXd5BSAghyQJdUVVXJ5KQszwX0UKhTx1tQfX19mNPppGAAghzQNSUlJQnNzc12/ZwWOaB7g1xLS0uwOoGKJsgBBDmgy0pLS+ObmppCOqpwAPifOnEKLi8vj3G5XBQGQJADuqaysjJSKhZzkKNVDug+bW1tlpqamki3201hAAQ5oGtk7UcV5ILkMQEO8J9THUtqe5DL5bI3NjZSSABBDuga8yTAOsgR6AD/0fMzmo6pgJaWliB1o3AAghzQNa2trQHtQxshDvCfjo4nlsIDCHKAX8il1ba2tkCCHOBfumW7/fJ36ng7Jl/raC1WAAQ5oFNaW1stqoIJJMAB3afdsSWt4AEcbwBBDuiypqYmORZoGgC6N7ydpK2tLYAl8QCCHOCPIGdVd0GUBOB/pxg4JCEuiCAHEOSALvN4PFYu8QA9R443CXEcdwBBDuiy5uZmjgWgm5xqQIP0SyXIAV0TSBEAXy3grSsUKhYAQH9BKwTwVZALYGJSoHt0dJIUoEhLuLpRQEAX0CIHGN7Rc4HtKhkKBeiBcAega2iRA5SWlpZgHeCoYIAeEUAfOYAgB/iFzCPHckFA92m/lrHexjEHEOQAfwS54PaXVqlggO4NdqzsABDkAL+QTtf0kQN6JcxREABBDuialpYWjgWgZ0NcQPtBRgAIcsBZCQwMPGZuhaNyAfznFF0VjlksllaW6AIIckCXJSUllZeUlMglVgl1BpUL4N8gp0+UdKBTIa4lOjq6prGxkQICCHJA14wbN25fZWVlo8vlCtFBjkAH+IdeU9Xc6h0cHOwZPHhweUNDAwUEEOSArhk9enTh5s2b66qqqkL0Ni6vAv7R0bGkglxTcnLykfr6egoIIMgBXSMVisPh8F7jaW1tZfoRoJsDXVBQkCcxMbEiNDSUggEIckDXDBkypFRVKC5d2TD9COAfpzopslgsTUlJSWV2u51CAghyQNdkZWUVOxyOI+rhaEoD6J4gZ35stVrl0moDLXIAQQ7osjZFVTBN5pF1DHYA/BPkdIBrtzxXa0tLi3ekOACCHNAlP/rRj4ywsLCNCQkJF5WVlVkpEcA/pM+pnBTpABcUFOR9fPTo0dqsrKwOv6eiooKCAwhygO/GjRsnl3p2lZaWulUFY5WWAgD+oVu69bQ+6lgzZA45WrwBghzgF1OmTDHsdnv2xo0by1XlEinbGLUK+DfM6WNKHWttgwcPPiKtdQAIckCXZWRkyKXVA3FxcWvU03R1C6JUAP8wt7xJmLNarc3Jyckl9I8DCHKAXxw4cEAqF09aWlpueHh4U21tLXMiAH4gfeJ0y5u+xBocHNw8ePDgwwQ5gCAH+MXBgwe992PGjFmvwlxjbm4uQQ7wk/Zzydnt9uaUlJRij8dD4QAEOaDrJk6c6L0PCQnJGzRoUKB0xqaSAfwX5Nr1kWuNiYmp5hgDCHKAX6jw5r232WzV8fHxG1WFM1c9DaRkgK5p3z9OAl1wcPCxtLS0Q263mwICCHJA1+nZ5VUF03Leeee9qx5eRJADus68qoNulbNYLCWyvnFDQwMFBBDkgK47evToicpm+vTpqyIjI+sqKipiKRnAP0wrpRxTx9dBdWtTgY6CAQhygP9aDeR+0KBBu1NTU/OrqqpimecK6BoZtSoBTo6t41OPHAsJCSl98MEHT7kE3pNPPknBAQQ5wHevv/66+WnriBEjtubk5ExRjwMoHaBrJ0n6JlSIa4mLizvMMlwAQQ7wm5iYmJOex8bGbnnrrbeOEeSArtGtbnq91dDQ0GPqeKuhtRsgyAF+M3z48JOeq0qm0GKxHGtqaqJwAD/QAx3CwsLaIiMjqwlyAEEO8Jv2LXKqkilXlU0NAx6ArtEtcbqfnMPhkMEOtQQ5gCAH+E37aRBUpbNj6tSpX3z44YfzpSXBNOLO27Jwqk7aAL7OPAVJVFTUsZSUlEMEOYAgB/jN2rVrT3ouFc6IESN2qofz5blUOnqdSPNSQwBOz3wCJLfw8PCq5OTkQy0tLRQOQJAD/GPmzJntg1xbfX39utO1LgDwsaKxWAwJbuq4OhYWFvZRWlraUYIcQJAD/CYzM7N9kDNqampydXDTrXHCPC8WgDPTrXES5CIiIupzc3NP2z0hJSWFQgMIcoDvlixZ8rVtjY2NdXFxcdVKtO6sba6YCHLAmUn/UumacHygQ1t6enruihUrTvs9l112GQUHEOQA37333nsdVUAt06ZNW718+fJrPB7Pie0EOKBz5CRIAt2gQYPaxo8fv9Xcwg2AIAd02TXXXPO1baqyaaqrq1urXNPY2HjSNArmBcABnDnEHV/+zhodHV3dUZDTo8MBEOSATps+ffrXtqlKpbW8vHxla2trs3oabJ52hBAHdI4cL4mJiV+Gh4fXmkeAW61WGclqHD161KiqqvL2QQVAkAM6JS0traMgJ+tC7o+NjT1QV1c3XLfESUWj+/wAODMd3CIiIrZGRUXV6+d2u93YuXOn8be//c2YMWOGkZSUZLCaCkCQAzrt5Zdf7rDyUeGtcdKkSdvLysqGu91ub3gjxAGdD3JyYhQTE1O9ePFi7zY5IZIuCzKH4+HDh2XeRmPIkCEGEwUDBDmg06Kiok56rvvCWSwWtwpyG1asWHG9y+U60dcHgO8hTs8Zl5KSUqiCmvcAkm179uwxDh06ZMTGxnqDHccWQJADzkr7CiQ6OtoYNmyYBLnm4uLitSro7auoqBihBznovnJUPMCZg5ycAIWGhjrVSdH6sLAw7/Gze/dub3gLDg7mOAK6gCFCwPHWAfNNLu9Iv51HHnlEQt3+xMTEEnmdVEB6MmAqH+DM5HiR4ykpKanYZrOVylQ+jz/+uLd/HACCHNA9B0ZgYIDb7ba5XC67qniGqMehujVOlhtiHizAN9LiJpKTkw+qANdWUFBgHO+moA6jAKu62dUtJPCrDRQY0ElcWgWMky+RqvrEVltbe1VTU9P3ysvLExYuXOiuq6ubKi0IUgEd7zt3onUOwKnpwQspKSn7f/nLXzbt2bNHGhDiKysrL3U6nReqE6UsFfZqa2pqPmhsbHxFhblaSg0gyAGdoi/zSIuACmvX/v73v3/q6NGj0ad6PQt+A76RfnByXCUmJjap8DajoqJiZFFR0T0//vGPT1rg+PPPP7/i3nvvbbnxxhufptQAghzQKVlZWd57q9Ua9NJLL53X0NAQQakAXdfc3GzIAId9+/bdk52dfc/WrVuN6urqEyFPt9hJq3htbe2Yuro6uRbbTMkBvqGPHKDIJVO5ud3ueFXhzPJ4PIEsFwT4oZJRx5HT6TS++OIL75xxEuL0sSUhTk+yLXbu3Dnjww8/TKfUAN/RIgcopaWl3nubzTaopKRkmnpIr2vAT0FO1NbWnniu54yTmx5EJIqKika3tLQMUQ/3UnIAQQ7wmazzeDzIJVRVVbUwiAHwD+lPKuFNbjqwyTYJceaWOVFWVhbmdDrjKTWAIAd0iiy/JVSAs6tKJkC3HBDogK7RYU23vrXfro8xvQJEQ0ODlVIDCHLAWVU26r5N99dhwl+g6ySg6dY3fTlVP5cQZw53x1eB4MADCHJA5yub4/fHdOVCkAO6Tl82bb9OsV4hxRz25KZeT/9UgCAHnD0upwLdf1xxogQQ5AC/MbXItekRdQB6hj7eZMUUq9XaSokABDmgU2w2m773qBtNckAvHYfh4eEeSgIgyAGdIjPPH69I6lVFQpADekFkZKQ7KSmpjpIACHJAp0RFRekgV6Met+lLrVxiBXpOTExMWXp6ehUlARDkgE6JiIjQQa5WHjNqFeiVE6qKtLS0WkoCIMgBneJwOHSQc9vt9hr1kNnlgR4WGhpaFx8f30BJAL5jVXBAUlt8vL45IyIiFgcGBrbSIgf0DN2VISYm5vDw4cMrKRHAd7TIAUp+fr73Pjg4+FhoaGiDTAxMqQA9E+D0SZM6kTqcnp7uomQAghzQKStXrjxRoSQlJeXZbLbW5uZmjg+gB8KcDnLJyclFY8eOpVAAghzQOTNnzjzxOCgoKDs6OjqgoaGBAQ9AN9LLconw8PDW/fv317744ovG7bffTuEABDnAd0OGDDEHuaKkpKT84uLi8ygZoPvJOqzSN+7gwYPlOTk5BDmAIAd0jp5H7nil0pSRkbF648aNBDmgh4JcWlraoRkzZhxwuegiBxDkgE769NNPTzyWPjuqUsmzWCxtLS0tjOwGuj/ItQwdOnTDpEmTip1OJwUCEOSAzvF4Tl7eceTIkbltbW0B0lIgzH15OtoGoPP0QIfg4OCmmJiY7Pj4eJde9xgAQQ7w2cSJE0963tLSsjMyMrK2pqYmSoc2TT8mxAFdo4+hIUOGVNXV1R148803jdbW1pMGHwEgyAFnFBYW1j7IlaWlpRVWV1dPPFXlA8A/1LF2ZOjQoQdVmKMwAIIc0HkLFy486XlAQEBLenp6bk5OzkTWXQW6sRKyWIzExMSqkSNHHibIAQQ54KyMGDGifZA7lpqauv7dd9/9vg5x5lno289ID+DshIWFybFWqW5OghxAkAPOypQpU74W5FSlsul030OIA7ouODi4PC0t7V9xcXEGAx0AghxwVjpokTNqa2vzZYSqPJYO2OaWOAD+ER0dXRsbG1ukjjfD7XZTIABBDui8vLy8rwU5p9PZqiqY6rq6umgJcoJWOODstO+aoI+ljIyMWrvdfnD9+vUnXpuZmUmBAQQ5wHd//OMfv7YtKCioefLkyeu++OKLK80Vj7mVDsDpyfHS1tZ2Yv5FeayOLRkZLvdtKsjtnThxYkV1dTWFBRDkgLNz8cUXd9SC0FxfX79t1apVVzY1NZ30NVrmAN/oY0VOfCTAmU+CHA5H/bBhwz6z2+1Gc3MzhQUQ5ICzM2vWrI5aEloqKiqWP/30079pa2uz6FY5uZdWBQC+BTndKqdXQ9HhLjIysk76x+Xk5Bjmk6WUlBQKDiDIAb4bPXr017YFBQUdi4mJ2RkVFVVSX18/RLYR4oCuBzt9UhQeHu5StwPbt28/aSDR3LlzKSiAIAf47t133/3aNqlYPIoKeftKSkqGmPv56IqIS6zA6ckxYz5O5NjRfeTUiVL5eeedV5qYmEhBAQQ54OwdOHCg4wPEYvFkZmbmbty48RKZHkGHN6YhATpPBzo5KQoODm7OyspaExsb2yyrOwAgyAFn7VSLdEuQO3LkyPro6OjDKsglmVviaI0DfAtv0gKn52LU2+Lj42tGjBix6pNPPvG2zpm1n9cRAEEOOK3IyMgOt8v0CM3NzRtUpVNYVFSUJNtYexXoXJAz3+tQFx4eXjNr1qwV5eXlFBJAkAO6Rjpbd0RCW2BgYEVWVlbupk2bZsglIdlGmAN8J8HNPHJVjp/o6OjyhISEBqvVSgEBBDmga9LT00/5NZvN5lKVz5aQkBCjsbGRAAd0kp6CREiYi4qKOhYUFJT/wx/+sMPjaenSpRQaQJADfJeWlnbKr1mt1mNut3tbUlJSQWFhYbp5oAOhDjg93RKnJwGW4yciIsI1Y8aMtXJiBIAgB3RZ+87W7VsTHA7HgYyMjDwd5AhwgG/Mgx202NjYPVdfffXH6gSJAgIIckDXnaqPnBYaGlqTlZWVs2zZsiuYEBjoXJA73tfU2zInU40kJCTk19XVHfR4PBQQQJADum7ixIlnCnKNLpdrld1u/4Xb7aZ3NuAj82oo8jg+Pr4pPT09+7333jvlfIw33HADBQcQ5ADfFRcXn/brMrJOVUYFI0eO3JeTkzOWEgN8Iy1xcllVLq9KcEtISDAmTZq02XypFQBBDuiSTZs2nfbrcnkoMjKybPTo0TslyNFPDvCNecoeCW+JiYlF48aN23G6fqkACHJAp3zjG98442tUkKuuqKjYoR5y3QfwkZ565Hhfubbk5OTFSUlJFQQ5gCAH+M3IkSN9CXLHRo0atd1mszV5PB76yQGdCHPSMhcfHx84bty47QUFBcbpBg0NGzaMQgMIcoDvvvzyyzO+Jjg42HC5XIWqIsrLzs4ex+VV4Mz0aFUxYsSInZMmTVrD/HEAQQ7wK6fT6VOrQlJS0v6xY8fmSJAjxAGGT8eNNmzYsJWJiYkHTzVaFQBBDjgrmZmZPr0uOjravXbt2m3q4b9RaoDvpGXuvPPO27F169YzTsSYkZFBgQEEOcB3jz76qG8HjMViVFZWliQkJLSWl5cH0SoHnJ6eENhut3tmzZq1TI4hjhuAIAf41eDBg31+7fDhw3NURZT72WefZclz3QfI3GeO/nMYSNrv73JMCN03Tr42derUzwcNGnTQZrNxbAAEOcC/fJl+RAsPDz/Q0NCwdPXq1aPcbneIDnEy4alMqWDu3A0MBO2DmXn/1yFPBblVy5cvb/ElxN19990UKkCQAzpxIFg6dSg0DB06dNngwYNvys/PT21fmdGRGwOV3vc7OhYmT568KjY2tpWTHIAgB/idzGvVGQ6HY995551XrIOcVFx6yaH2l1mBgUL3h2u/bcSIEfnBwcF79AoPAAhygF+NHj26U68PDw8/vHfv3o8///zzLJfLFaovp8rlVb2uJGtJYiDQ4Uy3tJmf65OZK6644t3t27c7fT0mLr74YgoWIMgBvuts6FLhzTNy5Mgvk5OTb9u3b1+6rsT0AuG0xmGgar/vq2OibcaMGR8PHTq0kWW5AIIc0C1UMOvU6xsaGmT06paxY8dukiBnDoRcVsVADW/mPnLSKi3P09LSDpeXl++VEOfrCdPMmTMpVIAgB/iuoqKi09+jwlzDoEGDNoSHh3+7vr7eqi8n6akXCHMYSCHOTAc6WdbuggsuWL9jx46GpqYmn/vH3XrrrRQsQJADfFdTU9Pp76murjZmzJix7PPPPy9VQW6orsDMYQ4YCMzzxskxoLsYREREOK+++uqXMjIyaiTIASDIAd1iypQpZ/V9kZGRO0eMGLG5oKBgiKrEAnQlRmscBmKYk/1ej+CWS6vquFo+duzYLxISEgz6xwEEOaDb1NbWntX3uVyutmuvvfa5jRs3XlxZWRmjKzLCHAYSPULVPP1IfHx8zfXXX/9aWFhYvcLxAHTXSRRFAJy95uZmIzMz83NVaRV7z4yOTyxMpYWBRA/w0ffH547bPmrUqNV6Kh693ZcbAN/RIgcoK1asOPuDyGJpysjIWFVSUjJeRrNKmOMyEgYiHcLsdrtr7ty5H1mt1ory8nLCGUCQA7pXZmZmlyqv6dOnP3v48OGZW7ZsyTK3UAADQfuluaZMmbIjKytrcbPi8XgoIIAgB3SvjIyMLn2/1WrNmTRp0qri4uKU8vLyWEoUA4kerSqkf+jMmTOXqGNqn8zPGBISQgEBBDmge0lft65Qldgxi8Xy+wsuuMDx4Ycf/kBPfKqXKzL3/TGP7gP6RUVhsXj7uelpRfQ+Lf3f9EAHvW3evHkv3XTTTX/xeDxtrK0KEOSAHtHVOa7k++fOnVutKrJ/HDhwICs3N/d8qeRku3nWe3Plx1qs6C90eNOhTO/L7UNcampqxezZs98KDg52dna1FAAEOaBXySUkVaFtvPTSS9/dt2/fRFWRBUho060ZegAEAyHQ3+iwpi+hmgf06BMVtf8f++Y3v/n6hAkTPi8sLKTQAIIc0HOio6P98nNUJdd29dVXv7p+/fpLVq9ePUeCnHT2lspPHutKTypEoL8wz4so99IVwTxnnNxPmjRp1wUXXPCqCnguLqcCBDmgx1sc/PVzLBZL4fe+970/qzB3oarwLPpSqr40xSVV9Df6xMPcv9NqtXr3ZbklJiaWqH3+/pkzZ250Op0UGECQA3qWVEr+DIWDBg1adtNNN73w6quv/lBVdIHy86UVg2lJ0B+ZW950oBN6PdUbbrjhhenTp78nIY79GyDIAT0uNta/M4YkJyd7xo4d+/9UV1fHffbZZ1d5PB6rVH7mtVip8NDfgpz58qoM5HE4HI3f/e53n5szZ87/1tXVNalQx34NEOSAnufvPmuNjY3SJ879k5/85N6QkJC2Dz744Bq1zaorxY4qOwIe+vrxoU9E5LnNZmu+7LLLPpw5c+YjtbW1pf4+GQLgG9ZaBbqJjOpTlV7evHnzHrr00kuX6stROrTpPnPmy1V0EkdfJPtlcHDwiZMMh8PhnjBhws4LLrjg/vr6+mL2W4AgB5yT5PJTSEjIlptuuunBadOmbdHbpULUwU4/lv5GjGZFX2WeAzErK2t3amrqfS6XawchDiDIAecsqeTkMqvD4dj4U2XSpElb9OVT8/QNuqLU3wP0NdLCLCcbF1544bakpKR7m5ubP6ZUAIIcMCDCnIzmS0lJ2fhLZdy4cbtlu7nfESEOfZneP+VEZMyYMT+qqan5rK6uznC73d55EmVEtl7lwR83AL5jsAOgSP8ff4e39hOmSpiLjY398pprrnnI5XI9VlBQEN9RxUVFhr4oPj6+/Ne//vW9MTExmxsaGrzbZJSqTK0jKz3Y7XbvPfsvQJADelx2dna3tGLIZVXdUiEtGHKfmZm5/MCBAyVKvLRmmMOfOQQCfUlWVtaWkSNHbpDRqXqCa7nUqk9G6N8JEOSAXpOenu73n2kekWoWFRVVVlBQ8Nr7778/XAW5MHNwa99vDugrLrvssiXqZMRZXV3d7b9LBUYKHCDIAb4LDw/vsd8VHBzclpqamjN48OC6vLy8MHPrm56jC+hpej1gaWWTx+ZluURkZOQGta+2SX84AAQ5oE85cuRIj1aY48ePXzVnzpy3Dx069BNZ9cF8mYpLq+gt5j6b5vkNL7roovUbNmwoW7duXY+8j8svv5wPAyDIAb7r6VYGWfVhxIgRG+x2+/fdbre1fWUK9FaQM59w6BOLWbNmfTx27Nhy6fMJgCAH9DmVlZU9XmGef/75K4YNG3a4qqoq2nswHh/xJy1zQG8yX1oNCQlxZmZmfj516tQmmW4EAEEO6HMuvPDCHv+dMTExJWlpaduzs7PH6HBHaxz6AvPl1eHDhxc1NTWVHzp0qMdartXv5EMACHKA73bu3Nnjv9PhcMgI1lKr1dqiKkiLnqYE6K3wZh49LWRuuGnTpu3Iz88/un379h4bUT1r1iw+EIAgB/jujTfe6PHfKcEtKSlpc2RkpKuqqipCnjNqFb2lo0E2NpvNGDJkSNGECRNq6B8HEOSAPmvKlCm98nsdDsc+i8XS2NraGqErU6C3A52QUBccHOxKSEjIS0lJaaN/HECQA/qsMWPG9MrvjYiI2BcUFOTRFai+cYkVvRni9D4YFxeXl5qauiE+Pt6gRQ4gyAF91qhRo3rl90ZGRtZGR0dXFxcXpx5vAaHCRK/Rl/b15f1x48btUY8PSx/SnrzkP2TIED4MgCAH+O6JJ57old8rwS0xMXH77t27x6kgF9jU1MSHgV7TfuT0iBEjDoSGhtbW1NRw2R8gyAF9V0lJSa9VnJmZmWuVeR6Pxy5zyOllkoDeDHHR0dFGamqqc/DgwcciIiIoIIAgB/RdvTGPnGa1WnfY7fYWl8vlnRSYUavoLeaBDrGxsQcTExPXyRQk9NkECHJAnzZp0qRe+902m21zdHR02dGjR8PNM+oDPR3izEEuPj6+QN32Sb85OcEAQJAD+qzQ0NDeDHKNERERVVartcfXfAXM5CRCh7mMjIwjDQ0NFevXr+/x98FgB4AgB3TKwoULe/X3jxs37ouDBw9OqqioCOLTQG/QLW8ej0fmN2yYOnXqB1lZWe7a2loKByDIAX1bb80jZ6pE12/atKmprq7OLiNX6ZOEnib7nG4RHjx48OGkpKRC2Re51A8Q5IA+r7dWdtACAgLWRUdHb1QV6RxCHHph//Pe9GjpIUOGHGxpaclfsmRJr7yf3prXESDIAf1UVVVVb1ekZYMHDy5UIW4OnwZ6mpw8SIjTKzrEx8cfnDBhggzAoXAAghzQ961du7bX38O4ceOyP//889skVNIqh144mfD2k1O3Y+rxnm3bthlOp7NX3svMmTP5QACCHOC7GTNm9Pp7aG5u3jx06NDyysrKQXwi6GkS4qRVbtiwYUeDgoJ2vvTSS95tveGOO+7gAwEIcoDvkpKSev09qEp0Z0ZGxpLs7Owf8omgJ+lLqiI9PT3nRz/60dre7m4AgCAH+MztdveFt1E/Y8aM1e+///4PGxsbTyxgrjuit19CCThbet8Sekk42bcsFkvr2LFj102ZMqWqsrKSggIIckD/0JsTApsr15kzZ36WmZm5d9OmTaPaf01I5Uugw9mS0Kb3HXMrnLcysFhk3d+axMTEtR999JEhU4/0lhtvvJEPCyDIAb7rK4uCt7a2Hrn66qufVkHuMQltemmklpYWb5hrX/kCnaFPAuQWHBzsnTdOj1aVL0+ePPmzadOmrS0vL2dZLoAgB6CzgoKCWtPS0j5xOBwPu93u4PatJ7TGoSv0Wr7my/YS2CTQJSQklA0bNmxVampqXXR0NIUFEOSA/qMvLUM0atSofb/61a/+8/77739EKlmpcKX1RO7Nc30BnSX7kL68qif/lXt14tBy4YUXPqu+/pZcUmXNX4AgB/Qrfanikkp11qxZr02fPn3++vXrLzAvnSSVsO4nB3SG3nf04AZ9aVW2qf1t6d133/2kx+OpkLnjWJYLIMgB/UpfqrhkxGpMTMyR22+//dHi4uK/l5eXx8tC5rpVjkoWZ0Mup8oJgPS31JdVxYgRI/Kuu+665yMiIsqlNU631AHoJ8c2RQD0Lccvex0bNWrUZ//2b//2RHx8fCmlgq6S1jc9YEZIYIuNja2dO3fuIqvV+r4OeAAIcgD8EOZUxVurwtw/5s+f/3J0dHS1VMSnu6Sq55sDTrV/SFiTfUgCXXh4uHPkyJFfqsf/rUJdCyUE9E9cWgX6sMbGxvLJkyc/FBQU1Pz000//v06nM/R04Q843f6h5yMMCQlpmjNnzkfq4U0Oh6PNarWeCHsACHIA/Ki+vr7uiiuu+L3b7Q594YUX7lLhzkZoQ2fpy6rqvunGG2985u677/4vm83WJpdY5WaetxAAQQ7oV+x2e596PzKyUC6DqYrWW/mq8HZs/vz5D+zcuXP8ihUrLuETQ2fp/m+TJ0/e9L3vfe+vVqu1Wg9skP1NbgAIckC/tHLlyj71fqT1RNZ/LSkp8T6PjIyUbTV1dXX71f0l7TulM7ccfDVkyJCDxcXFB+vr6/vse8zMzOSDAghygO9+97vf9an3o/sz6UtduuVEBbp6h8NhdFQJE+ZwOnr/sNlsTVu3bg3qzbVUz+S6667jAwMIcoDvxo0b1y/eZ3BwcJnT6WxWQS7YHNwIcPBVeHh4VVJSUqtcugdAkAPOCTExMf3ifdpstprQ0NBGyXR6m143U9AqhzP+07dYWtWNnQQgyAHnjoiIiP4S5BpUkGs2BzY9f5w8J8jhVPR+ofahxpCQkDbWUwUIcsA5Izw8vF+8T7vd3iB9nMzbzGuvMjM/TsUU9tv0uqsACHLAOSEqKqpfvM/Q0NB6Feaa2vePoyUOZ6L3j8jIyKNxcXHNtMgBBDngnCHTe/QHDofDqcKcRz8nwKGzRo4cuSMzM7PN4/FQGABBDiDI9XCQq1NBrqn9Ukr6OaEOZ2K32yv1RNMACHLAOaG/XFoNCwurCwkJ8ehKmBY5dIbVapURq62s5AAQ5IBzikyy20+CnMtmszXTmoKzERoa6lJBLlCmrJEbAIIccE6IjY3tF+8zMjKyzmq1OoODgw3prC6BTh7ryV1pocMZTgTqXS5XY1VVldGXBzsMGzaMDwsgyAGdCkj94n3KJWCHw7ExMDBwtnoaLEt36eW7dJADTiUmJqbx4YcfbtMnAX3V+vXr+bAAghzgu4KCgn7xPsPCwqQlxdW+NUXPC0ZrHE4nJCTEFR0d3WIO/wAIckC/99RTT/WL9ylBLSYmpioiIsJTUVHhXabL3LIigY5KGqci09dERkayzipAkAPOLVOmTOk37zU0NDQvJyenXgW5ML2N8AYf9506FeSYDBggyAHnlhEjRvSb9xoWFpafkpLSvGvXLm8LnYw+lCAnLXMsu4QzBbnw8PAWghxAkAPOKSNHjuxPQa5YBblsq9Wa7PF4gnR404EOOBW1zzSqMNfW1NRkNDY2UiAAQQ44N4SHh/f59yitbxaLRVpVmtPT0z9Ujy9RQS6cVR3gKxX226QfpYS4yZMne6euYb8BCHJAv9cfLjXpy6jSUV1VwusTExPrCwsLw2W73CTQMY8cTkftH22tra3HZs+ebWRkZDBdDUCQA9BT5BJqaGioERERIfPelcbGxjbLtCkS7nR4I8jhdNRJgM3tdgcOHz7cexme0asAQQ44J8glpr4uOjraeOWVV27Nz8+/w+FwRMTFxSXpFR6EbpUDTnMyYGloaPCu1av2oQCXy0XqBwhyQP+3YsWKPv3+JKSp4Ja8cuXKOz799NOZEupGjRp1UguctMwxahWn43a7ZVLgHzz99NPxu3fvnnTdddddGxQU1Od2mnHjxvFhAQQ5wHfTpk3r0+9PluZ68cUXr/niiy+mS3irqakxNm3a5L08Jp3XJczp1R2AjkjQ/+STT675/PPPr/J4PBaZWPrSSy/9ttpv/kXpAAQ5oF+z2Wx9+v2Fh4cHlJSUjJHpRuS5XFKV/k0S3nQ/Jy6r4nQk5Kv9J0Qey/QjTqczYfny5fPVvt/ngtwvfvELPjCAIAf4buXKlX32vUlACwkJSd2/f/8E/Vz6xVmtVu+9TEkiLXJSUUsgVZU1Hyg63I+E7B9yAqDCXMCOHTsufPHFFwPbaMoFCHJAf3bRRRf12fcmc9wtW7Zs9N69e73LT+g+cdKqIswjDwlxOBU9fY0EOrkkL49ra2vj1H40Rp0Q5FJCAEEO6NeVXF90fNmtwD179kw+cuRIIp8UukIa3nTLnIQ56Sv3xRdfXBYfH5/bl46Ba6+9lg8LIMgBvgsJCemT70sulRYVFSVKZSvPGZmKs6X3HT3SWW7Nzc3Bat/6zpNPPvmECnVMKgcQ5ID+qaGhoc+9J30prLCwcNqBAwfG8imhK/QJgF4BRAe7/Pz8cWVlZZk1NTVbKSWAIAf0S32xb5lUtNXV1ZadO3derCrZOF0J0yqHrp4g6JtoamqyrFq1as6wYcO2sl8BBDmgX0pISOhz03fIZdV9+/YlrF69OlMWOTdXxMDZnBjo0c3H+156tzc3N9vUfnbBrbfeGlhVVdXGNDYAQQ7od4qLiw273X5iJGhfIO9n//79F+Xn558vz/VoQ+Bs6CXczPcS7lpaWmQakmkFBQUTBw0alM0+BhDkgH6nrq7O+Oijj7wrKEiAcrlc3lCnV07oDaGhoWEHDx68tLa2Nlyemy+p0iqHswlyer8x38tNRkRv2rTpou9///tbWH8VIMgB/Y6MWs3PzzcyMjKMNWvWGFlZWd7HsbGxRkVFhTdE9eiBabEYR48ejV+7du14CZXm30+Igz9Cnfne4/HYdu3adW15efnzar+r7u3Lq+effz4fEtCbQS47O9vvPzMnJ8e74LNUqk899ZQxefJkY/bs2d6btKaEhoYae/fuNcaMGSP9ioy//OUvxqOPPmqsWrXKuPzyy43Vq1d716eU71P/qIzx48cb7777rjFx4kRvJb5o0SLjww8/NO677z5j27Ztxs9+9jNj8+bNxp49e4xvfOMb3u+R3/X22297K1VZImns2LHeyVoXLlxo/PznPzcKCgqMN9980/jhD39o5Obmen/v+vXrjRkzZnh/fmJiohETE+N9X/KasrIy72sOHz5svP/++8Z3vvMd7/qZ8vvk77300ktlfU0jNTXV+7vkvV1//fXeyyJXXHGF9+/MzMw0Nm7caGzdutWYN2+e8d5773l/nrQsye+T191///3GN7/5TZn80/v6wsJC7+8oLS31Lk4tqxpI2amzceOFF17wtkDJe5Z7eb/y3uRvl7KQ7fL7JOzI73vmmWe8E9LK91ZVVRkXXHCB8be//c1bvtJ6NGzYMCMvL8/7t8jfJrc777zTePzxx6UVwFsO1dXVxqRJk7yfo6xW8M477xizZs3yvr85c+Z4y1DK/eGHHzbeeustQ1U4xu9//3sjJSXFu29IOcrPmzBhgvdvk3VT5T1eeOGF3r/39ddfN66++mrj+eef95bZQw895B2lKr9X3oPcy/uT3y2fq3zWsk/Iz5eyl31LKryzveRkHqCg+yZJUDtdS5/8fqfTOUbtR6P0JTD5PkIcuinYBci+po6PCaNHj/6iN7sYyH4u/ydKSkq8XR7kf6H8b/zkk0+8/9/+/d//3fu/Z8mSJd7/6fI/SsgxLce7/D+T/wWffvqp9//Ijh07jLlz53r/J8vJmfwfk2P9iy++MP74xz8aH3zwgUzxY9x7773e75X/WVIXyP+wqVOnGrt37/b+H1AnVd5BUW+88YbxxBNPeOuHQ4cOGbfffrv3valy8/7fkd8l/3s3bNhgpKWleeuguLg44+mnnzbuuece7/9Jud10003eukbek7wmPT3d+3vlf/2f/vQn45ZbbjGSkpK82+644w7v/zmpb1TYNqTPrNQdX375pfdvlf9t3/3ud43BgwcbjzzyiDF9+nRjy5Yt3u+T9yi3b3/72946QP5m+b8v/xOlbvjWt75lzJw501vX3HjjjXoksxEREeF9LPWa7A+33Xab92+X/69/+MMfvH+n/N+W+kHqVflbbrjhBqO+vt5bV8v/aSnnW2+91fjzn//s/SzkfUpdIq+Xv+uuu+7y1ukHDx70/k3yffJ5yffK75N667/+67+89bTUWYsXL/b+HPl/KK+Jjo72fu7y+cnf+8ADD3jrAjkBl//18pnI3ySfodQj8jOkjpDPTP4uySryN8r/evk/3xODfaSuoUUO6IHWMAlMElBVmPJWKkOHDjWSk5O9AaszB7v8w5F/NBKu4+PjvUtqScWzc+dO7z9XuYzbUThT/wDD1T+iK1XFESrPJURKCJTwR6BDd1AnNeGqwrtQVbRfSGXcG2Q/l31bjhEJLHK8SICRbXKSdarjBaBFDsCpWiq8YU4vUC+VSWeD3PEO5SdGxcpjaWmUVkU5+2w/GbH8ThUmE1RlerVuxdOd0+mIju7idrvt6gTj+g0bNrxZV1eXd6bX633SH+RnyXEhrUsS3PR6sLJdTqwAEOSAs6bXp9QhqzOVl36tuc+RhDMJZHI5Wl+2MH9dwqLaHr1gwYI0ea3uH2cebQj4m+yTKsilHzlyZNqNN96Yd7pWOdkHDxw44L2EJZfPZB/VLdmdJQFOwtsrr7zi3b+l5ZsTFoAgB/RpEtBknjiHw+G9Nw9mUBWiVT2/5FQjVAlz6C6HDh2KzMvLmxwWFvayee5Cc4CT/U/6Mklwk5MOuUnr2dkGOR0C9QkO89gBBDmgX5BKa9CgQd7+dxLmpBKUCrG8vDziL3/5y1X6kqoOdLqipLUC3UGfIOzZs2fC+vXroysrK6vbhzjpEC4d/6UD+i9/+UsKDSDIAZAKUkaT6dGsFRUVSdnZ2TOkpcN82VUuQenLvLTIobscOnTovCVLlsy2Wq3vmfuDyv6nRwz21tyKAAhyQJ+iV2uQ4fES2lQlGbRnz57Lm5ubA8xBT7fOAd21H0pAk33xwIED8SrAnf/jH//4PZmaR5PwJlPzsB4rQJADYCJBTeY/lBYPFeBCX3/99am6ctVf18+pRNFd+6AeIS2PCwsLp6pA5ygrK2uQ5zLth0yfQ0sw0PcEUgRA75LKU0btSUV66NCh8WvXrr3Ee3B2YbQscLb7osjPzx+3Zs2ayTJxrUy6KxNyy+TZTAUCEOSAAU3CmEzXILOmy+obcpPHMjmwdCRfv379hZWVldHyWrnMZZ5+xFzRAt21f4oDBw6kyOVVmb3/yiuv9E41IpdVe3qpOgBnxukV0IOVZGRkZMCRI0eGbtiwYd6uXbtGNTc3B51//vmfxsbGfpmfn5+Uk5PzfR3YzC1wDHBAT+yfuq+crKiwc+fOOW63+wV1XyN95WRkNQCCHDAgScuaTJ6qwtvFjz766AN5eXnT5ZKViIuL+5YKc7kulyvs4MGD48yVqn5MiEN3az+gZvv27ePVPjmyuLh4o1xWlfVC1T7siImJaaBlGCDIAQOGXjty9erV33nkkUf+v/z8/BHmrx89ejT2008/neM9IE19kAhv6On91LzPqfCW8vjjj/8xOTl5Sary8MMPZzkcjjC73V6rvrwqPDz8KfX6ekoOIMgB5zRV8Vlyc3Mve/LJJ++XECfTOJxqUl8ZuQr0NL2mqd4vJdC53e7gDz744JuDBw+epR6HyRQ5WkZGxmVPPfVUxu9+97ufdLQCBACCHNDnSACTfkIy35tuvejosqf0MdKXRmVS35qamsEff/zxHbt27TqPS1Loi2R/lZMIcz85PSVJcXFxmH6dDNSR/nOFhYW20tLSW1Sg23XLLbc84XK5KESAIAf0XVKB7d2719i4caMxdepUIywszLtOqvR7k3szmbJBApxUjAUFBdbt27f/cM2aNVd5D7jja0qerlUO6K0wp+/1Yx3o5Cb7tB5FfXxEtf2JJ564Lz4+vvTKK698W05wAPQ8xpIDPpBWCo/HY8joPbmUJJWWDmJSsZlvuhJUYS2oqKjo+ueee+62iooKq4Q3ac3QLR1AX9vH9T4s+6e+6f1Z9l196V9eK8fA0aNHEx5//PHHli1bdnVISEinQiN9QAH/oEUO6GRF58tyWRLa8vPzL3jwwQf/rsJftLToSSUo282VI9BXmMOVeV/X28ytcbpFWe737t2b+ve///2vtbW1jdOmTVuWmprqDX2nOoYkAL7zzjtyedYYNWqU8Z3vfIfCB7qAFjnAz1TlFlBcXHz+z372szeOHj0arddT1fdS+TGxKvraSYpc9jdPeSP7qpx86ImppX9o+6CnW5Z37NiRsnr16jvU9lT5ObplT/Z1vb/r50L/bFqmga6jRQ7oenA7aR3UqqqqsU8++eT/V1pamizPpcLSrRu6RY4KDH2JHuxgDnamLgLex9KlQAczea28RsKdbFfBLEgFufkjRozI/dGPfrTA6XQ2mfdzHRKle4KsZAKAIAf0CRLQZOkiuZQkfYTsdrvt9ddf/w9VqV1hvnxKcEN/C3aaeVCO+bEOd3r/Li8vD1L7/m9qamoOjRo16p+HDx82ZDSrHCPJycnewRJbtmwxfvvb31LAAEEO6BtUcDOWLl1qSKV1/vnnBxcXF39fPb/Z6XRSOBgQdEuzBLuDBw+Gr1u37ncZGRllERERn+iuBNJHVIKcHC8A/NygQBEAZ08qL6mk4uPjY3bt2vWLxx577H8k1JlXaAAGQpiTY0FC2/bt24e/8cYbC5uamq6UYwNA96K2AboQ4uRyalRU1KBt27bdu2jRop+73e4gaXlgjjgMpONAuhbokxe5lJqdnT26ra3ticsuu8yutv+LUgIIckCfq7wiIyNl6oVRq1ev/uObb755nYQ4PSqP6UUwUOjpeOTkRfZ7PbBh69atGep4ePCSSy5pVfeLKSmAIAf0mRAXFRVlFBUVzX7++ef/sGLFioulRUL3E5IKTSqzU82lBZxrx4OetsQ895wcA5s3bx7d1NT05x//+MdV6msrKS3A/+gjB3Sy0oqOjjby8vLmL1iw4Mlly5ZdLFMqmCsywShVDBTmueeEPoHR88ZJn7nnnnvu7+r5DOZPBAhyQK+HuE2bNv3uwQcffHLLli3jdWDTk6bqG33kMJCOC/PqD3qbrOAgz49fZh372GOPvawe3ymt2QD8h0urgC9nPIGBRkxMzHgV3u7dtm3btbW1taGnq9CAgRbmzMyBTrfC5eXlpdfV1S2orKycOWPGjP9Vm9ZScgBBDuh2Vqs1qLS09Lo333zzZxs2bJgjk6DKyFT6wAG+hTzdb+7IkSMRH3744c0lJSUjJk6c+Bf15dcpIYAgB3SboKCgyKqqqjvefvvtm3Jzc8+XEGdeO5UWOODMQU76ysngBzlu5BjauHHjtLq6uv8cOXJkizqO3qKUAIIc4FeBiqpoJj/77LN3vf/++9+TqUXUpgA91QIAn4+lE1OT6JMfue3Zsydz4cKFTzY1NcXNmjXrRfU1N6UFEOSArlY6EtjCqqurv3/33XffV1pamqSnVJB+P3qeOEalAr6RY0UmztaDH/Q8cy0tLcaBAwcS7r///oU33HDDDJvN9qj6Wq463looNYAgB3TK8Us/0TU1Ndc3Njbe+ac//WmKbn0zLz8kFZHuwK0vsQI47cmR93Kq3Jv7lqrg5t3ucrlsL7zwws1RUVHzR44c+Vun0/nP+Pj4SpnWB4APxxhFgIHs+FqpAdXV1aPdbvc/lL+sXr16irQa6MAm4U3upQVBwpvu60OIA3yjW7SlVU6OJT09if6aBDwV4EL+4z/+49EXX3xxUVVV1Wz1+jDmnQPOjBY5DNgAJ4EsLCwsWlUas/73f//3bhXgLq2vr/d+XYc2HdbkuSDAAZ3TvhuCPn7MU5To40ssX778kqKiotHz5s17aciQIc+oMFdEKQIEOeBEpSFn/3FxcdI/Z2JeXt6PP/jggyvz8/PT5Ot6mS36wAE9d0zqAUS65W7//v0p6uTqF5dccsl4tfnRiIiILykpgCAHKgzDbrcbNTU1o1etWvW9pUuXXpOTkzNBzz6vWwvksb6kw/QiQPfSl1p1oJOTKTkOa2tr7f/617+uHj58+OT33nvvKXXsvqJenk+JAQQ5DDBSOagzekt4ePjU6urqOQsWLLhuxYoVU80ViZ4iQUhFIt/DhL9Azx6nOtCZw93+/fsTH3744T/OmDFjrsViecHhcKxQx3IBreYAQQ4DgPqHLxXExW+99dasbdu23bxz587h0slaD1rQ66LqAQ1Cj0xlwl+g+3V0aVU/Nw86Wrt27ayhQ4fO/PTTT1eHhIQ8Gh8f/15tbS0FCIIcRYBztXJQIS56yZIl169YseK/du/enVhfX2/T81iZBy2YWwJ0pWJuoQPQvcdqezrIyfGq52+UbcXFxQEHDx6cpU7Ihl188cWZEydO/FR9baNMYwIQ5IBzpFIICwuzRkVFzfvnP//5LRmJqs7aY2VUnLnFTZ/5dzS9ga5YaJEDup95pRQ9b6MENzlm9QTcetoSObmS+3379qWUlJT8bvv27d+eMGHC2yrUfaRCXg7HKwhyQD8OcHa7PTg+Pv6WJ5988jtFRUWTy8rKYs3TGuh/8ua+NboVrv3PokIAeu7YbU+OW9lubhXXr9P3MpHwunXrzs/NzR29YsWKH6hA9/+zdy/QUZcH3scTJnPLZTIJIQSQW4gGQQwidygBglKLVql0rVq3l63ate3rvme3Pfvu9thtz27f3XX3PT3u1r5nj62HKh61UEDtqkEpBBDCxdxhcs/kfplMMpPMJRfwfZ68PJynY0CIDMxMvp9z/mdu/yHkn5nn//s/19/n5+f/IiEhoZPvLwhyQBQRV+jpIsB9QwS4P/d4PAv6+vpSVFhTI+Aud8LQn6PwByIr1I33/dRrzKWBgYHEs2fP3trY2Pg/jx079rUlS5a8t27dul+K1ys4oiDIARFMFuRymZ+ampqVBw4c+KuGhoY5co44tRqDaj4FELtlgBoMMTw8bHI6nXN7e3u/I8qEe3Jzcz9MSEjYJXY7zJECQQ6IIDK8ORyOuLfeeivuoYceShJX4V+vra0dm9BXjUCVgU6NSAUQe/TBSfpI18HBQUNdXV12Z2fnvObm5hXr16//gygHfiterxMbV3YgyAGRcBUutgRReE8tLi7+WmFh4Xr5vJp7SlJ940wm06U1HQHEVjmg35cXb/L7L+d/lMHO6/VOKS8vX9rS0rKkurp66aZNm94PBALvJSQkNImygkkiQZADbjQZykQhnCwK6syBgYGHjh49+rXKyso8UTibVBOLGvGmltliUl8gNqkmVTmdkLxwUxdsaiS6GvnqdrsNH3744bZDhw5ty83NrfjqV7+6W5QL74jg1yjKlD41MhYgyAFhCm+iwE0Wd7McDkeuKJR3iPD2YGFhYZraRxXEas4pNa2I2ghzQOxRNXLq+61fwKkQp5cBsptFVVXVErmJcuUftm7d+t7Zs2d39vb2lprNZpfYesebjgggyAETuNKWAc5qtdrr6+uznU7nN10u19e++c1vTlP7qAEN6la+RxXkqmZO9ZcDEJvlhF4WqHWS1XdfzTsXOvH3xdfj33777fvkNm3atMCWLVver6ioeFEEvgpR7nTTlw4EOWAChbLs45KYmGi22WwzRXhb1NHR8dALL7ywpaura56cuV0GNRXaVEDTg5o+sOFKU44AiJ1yY7y55kLLBv2xeo8Kdn19fdY9e/Y8VFhYeE9BQcEfExISdosQeFKURS0i1A1ylEGQAz6jIJa1b5mZmXGlpaULS0pKHjl79mzB3r1754oAN0ctvaMvo6XonZ0JbACullqGT4Y7NTCqt7c3ad++ffcXFRWtyc7OdorXPjabzb9OS0srS05ODlDGgCAHhAQ42Uk5KytrxqFDh5a9+uqrGw4fPvyFioqK1X6/P368/UMLYkIcgImWP3qTq+obJwdMdHZ2TpXb6dOnl7377rvrhBOLFy/+w/Tp00/29/e30F0DBDlM+ithcYU7JSUlZVt5efm6l1566e4zZ84sa2trS1f76KsxqAI2dIZ3whuAz1MO6f1rVd859Zwsg2Soq62tvV1udrv9z1avXn0qEAhUpaenF4ttj8Vi8VMOgSCHSXP1K4JbXFJS0h3i/rLnn39+c0lJyRdbW1unNzY2XipYFXXFKwvV0NUZLlczR4EK4FrLJVV+qAmFVZiTF5KyxUD1x+3v70967733NopdN86ePftb//RP/7TdarUenj9/fnFqamqx2PcTyiAQ5BCTBaUo7Mzi6nXVzp07v+BwOB6pqamZU19fn6qCmrpVtXD6SDRViKr+cZe7sqYABXCtZZMe5EIvFNUFZGhNnbzf1taW+Oabb25PS0vbtmzZshav1/u+yWQ6tHz58qPi9Q6OLghyiIlC0mKxGBMTEze9++67G8vKyuTcb7OHh4ctoUtmqatg2eFYL1j1W71GLrQGjv4qAK6VKndU+aFfEKqLSH2AlbroVFMeSX19fabDhw8vOHr06HdnzZr1Z11dXW9Pnz79oM1m2yfKPka7giCH6AtvsikiKSlpdkZGxkPiinVbZ2dnXnd3tz0QCFjGe48+hYgqRPWANl5NG7VvAK5HeRXa7zb0Nb0MUiNbQy8e5fNim9LQ0JDR2tr69ZSUlO0fffTRj1euXPnKqlWrCq1W6ynKLBDkEA1Xt4a0tLR79u7d+9gvfvGLe7xer83j8SRebQFGYAMQSSFvImXQ8PCwsbe3115UVGQ/efLkj3fu3PlXt912m1wS7NcGg2Gv2MXP0QVBDpEQ2uQm2zcN4sp0g8lk+vbp06e/8K1vfSvD7/fLptOxdgfZ503vZ6LWQySgAYj1MjIYDFrk1t/fv6msrGxNUlLS87m5ucWiPHxTlIFviX38YqMwBEEON87FNQsThoaG0sWV54Ner/e+n/70p4t7enpuFYVVvL6+qVouR8d6pwAmA7XOqyTLQZ/PZxHbDHGh+5DT6cyfP3/+E/n5+QcCgcDbYhen2J/CEQQ5hC+8yZo0o9FoGRgYmCkKogf/+Z//Ob+6uvrL7e3t8XKeJX2UV2htm6qVY7ksAJOFLO9k2afuq1GvovyME+Vomig776upqbmvsLDwz9euXbtvxowZ74h9HKKcDYi3MHoLBDl8Pmrx+cTExCl9fX1TxZXkalH4bHj++efzS0pKVug1bWoEqd6Mqoc6feZ0/SoVAGL2pCoufmULhCr39LWhVbgTYU5uS48fP750z54939y0aVOhKHOPiP0/MJlMvWI3aulAkMO1kVeMoiCRo07TOzs7b3U4HKveeuut+4qLi7cODg7Gq30U/YpTX4xa7aeG8KuNEAdgMpBlnSoD1cWsmlxYr6FTF7xNTU3zXn755ad++9vfPlVQUFBkNpvfFeXrQaPR2CZCXRstGSDI4YqsVqsMcNZgMDi/qKgor62t7YH9+/fveOmll4x6yFNNpKrwudzcbqHzvo23xBYAxPJFsbrAVX2G9T7C+rQm+oTE8j2FhYUbxN0NGRkZcY2NjQf9fv+ronz+WJTTzSIM9lGOgiCHS2Ttm1x1oaSkZGllZeWfnzp1auOLL764SPZ7U4WRvqpC6JB8vUC50hJaTNgLYDLRu5+MV/5dbv46vdx1u91x+/bt22wymTbn5eU1iXL6v0VZvG/JkiWlfX19PQQ6EOQmKfnlT05OjrPZbPNOnz4tm093iMJiU3t7+61DQ0NxKsTpi9YDAG58WS0Fg8E4cZE9T1xsP5OVlbWtt7f3UEpKyuvTpk2rF+V4kwh+9KUDQW4ykFd4MsCZzeYlhYWF9zQ1Nd1fWlo6v7u7e14gELi033iDEvSlagAA4S2r9SCnauh8Pl9cfX393IaGhm/Mnz9/y9y5c5vdbvehxMTEP0ydOvWUKKOHOXoEOcRggSD7v4kveYq4etu2d+/eLwwMDKwTV3a3i1uTvq8Mb/pyWTpCHADcHPqFtNFoHLvIFmFultyOHj26KicnZ4e4KC8XZfh/2+32d9PT0zvozkKQQwwQX+p4Ed4eO3jw4KojR44sFV/6xeJqLl29rkaUqto32Yyqj6pSAU6/MgQAhJc++EG/iJZlthowoQ2gmHLu3Llb5TZnzpytLpfraZvNdk5cvB8XF/FyBYk+jihBDlFWACQlJc1MTEzc4Ha7NzQ2Nt5TUVGRow9e0JfJUiNPTSbTWHhTI1Kv1D+O2jkACB8V0lQZrV9QqxkAVDmtRsXK+83NzcliWynur8zOzn6wra3tXnFbmJycXGg0GhsptwlyiGBmszleXH2tFoHtCy+88MLyysrKLSLE2YaGhgyhBYEKcRfXSx0rCPTnxhudCgC4MdRMAaHzcOr0MlxedOvze0q1tbX2hoaGr9TU1NzT1dX19blz5/5hwYIFZeI8cWxgYMDLUSbIIQKo/hIWi2XNiy+++OUjR458q6mpyeb3+02iIDBcLoRdaeqQqwluhDsACG/Z/lnld+h9fY461ZpycfWIlO7u7vXiYv9uu90ePHXq1IcPPvjgTpPJ9K7chaNNkMMNdrFmLV58geempaXd++yzzz4mrrzuEldY1qGhobHJe2XTKQBgcp4jQkOgDHQ+n88aCASse/bs+co777xz37Rp0+oWL14s+9C9I3aplNfzet88EORwHV1c5sUovoxm8UUsSE1N/R//9m//tubChQsmEdoMco4hVcXOMlgAQJiT9NYXdY6QgyPEuSOppaUl71e/+tUdL7300nPZ2dkV4vnXxLlklzjX9Ilt9BOaXghyuA5/lISEKeK7lNzf379Y3H9o7969m51O56KBgYFEWY0um1XlIAa9D5z2XvWl5UACwCSnL6moLaFokN1wKisrl3d3d9+9e/fub65Zs+aY1+t9R+xzTJxj/HKyYaYyIcjhGplMJoP4EqW73e51paWlj+7atWudx+OZ1dvbOxbM1MjT0ClC1EgniRUZAGByBrbLUecKvU+0ek4EuXiXy3VnT0/PnUVFRU9Onz798I4dO/aJ13fbbDa3OL8w2TBBDlf64lksFjlxr0UEtKza2tov1tTUPCCujpa2trbO1K+i1JWUmjJEXWXpwU3NBUegAwCEhjx5zpAtOurcoc4Z8pwiAp3cEurr6wscDseaJUuWPHTfffcdGBwc/ENKSkprUlJSf+gIWRDkJvWXSq66kJqaOqukpGRJc3Pz5paWlnt/97vf5angps8bpF9ByVt9TVR1K7+UKugBAKCfP2RouziR8KXaOFVBIJdq1CsMenp6Eg8ePFggt9zc3O+uXLnyiLi/X7y3TIS6OgZHEOQm7RdJXvUkJiZmJScnLzp16tTCYDD4wFtvvbVVBLNL3wrVTBo6r5v6kulXV3ro08Ne6D4AgMlNb6WR5xn5WIY6FfBUiNMH0EnV1dXz5PbKK688sX79+tPiqb1ivxKLxeKwWq1MNkyQi/3wJmvLRHAzpKamLmhpaVkkvhCP+Hy++1999dXk8d5zuXndxptfSH0xmcQXAPBZ56PxQp2a7eBy5x69cuDo0aPL5TZjxozzVVVVReLp18T5rUKEujLxepCjTJCLKfKKJyMjIy4YDK58//3380tKSh4uLy9f0NramkHNGQAg2gKgqqnr6Ogw7Nu3b9OHH3649M477+wwGAw709PTD9nt9qqRkRGf3+/nwBHkopv4QNvEFc+qX//615sOHDiwvaWlZXZfX19SaDMpIQ4AEMn0Sgd9XjrZV7u3tzftyJEjaeXl5X83a9asb3d3d59etGjR71asWHGioaGhiz7bBLmoIT+sIrzFibB2q7gyeeBf//VftzidzjsaGxtnyUkY9S+DGsBwpaVYAACIBHoFRGi/bTURvQh0qXI7d+5cbmZmZsHChQur7Xb7wU2bNr0jHn+sz6gAglxEhbfExEQ58jR12rRpDz/77LMPuVyuBW63e0FHR4dZ31f2k1NfAH0gAwAA0WC8AXfqsZrfVG5tbW1ZcrPZbGurqqqe2Lt3b5O4f3Tq1Kk7xf5NHEmCXERcncjlsbKysvJ37tx5b2tr6z1NTU0L6uvrU/UPtvrQyxo4ecUi76tAJ8OcvC9vCXQAgEilWpHGayZV5zk1YEJNiSX39Xq9RrHlOByOnPT09Hyn07k9KSnphMVieVdsH4pz3yBHlyB3w69GTCZTSmpqav7hw4fvF1ccG6urq7M9Ho9R30f1IVBzu+kjS/XgRogDAEQ61YoUOq+pvqkKDHW+0/eV73e73cb+/v48m822xOVyfaW4uPjdBQsWnBDn1N+Ic+UQ50KCXNiPkdlsXi6uJu7+4Q9/eH9FRcV6cd8yMjKSEDrLtT4NyHgL2OsfVj64AIBo8Fl9usebLmu8QCjC3BSxTaupqXk8NTX1q3V1dT8Qge43a9euPTk0NCTnqGO4K0Hu87tYVWwUH6pMcXWR39nZec9f/uVffrGvry8jGAzKhYbj1aoLet83AADw2cS51eB2u6379++/XZxH//fOnTsHly5dWrRjx4794rX/FudgucbriNg4uRLkPtvFQDZFfHASxWYZGBhYI0LcY4888sjmnp6eTH1wgmoyVUthMbQaAICJudgkm9DX12c/ePDglw8cOPDl6dOndy9evLjE4/G84XK5Dohzr1ecd/1iG+WIEeT+JLzJhYNNJpNVfFhsIrwV+P3+r5rN5oKf/exnKao/gApvatms0CZTffACAAC4evLcKfvVqfOs3Lq7uzPFtvWPf/zj1sTExKG77rrr9G233ba3p6dnd0JCgkucu30cuUkc5OSHRHwwDJ2dnRmNjY3LAoHA5l/+8pcbW1tbl8tFgwcHBy+NwlEfLkm/r64i9I6eAADg2o13PlW3wWDQfObMmXVVVVXr3njjjSc2bNhQ5HQ6j6SkpJy0Wq1dItQFOQdPgiAnPyRJSUlys/X29mZVV1dvfv/99+8tKSkpGBgYsHm93k8tQSKvEtTVgT73WyiCHAAAEzs36xPlq/OtqjhR52JZyTI0NCQn3M8TgS5v//79P8jOzi7Mz88/mZmZuTcrK8vR0dHhn8zn4pgNcvKPmpqaKptP5xw6dGiDCG6bzp07t+Tjjz9eKlK+Ub8SULNOqwAnP0iqKVU1rzLiFACA63eO1gPcyMjIpQCnQpw6T6v7ct+Wlha53XvkyJF7Fy5cuOO+++472NPT86E439fa7fYK2W1qsp2jE2LtgyFr31JSUtIsFsvaXbt2LaqoqJBt7ZvFhyRevxJQ++uTGeqDGkKDW2jTKoEOAICJUedRGeD0x6F9zvW1yfV95X5nz55dKDez2fzMXXfdVfXSSy/tb21trVy9enWFCH2VBLkoC3AiuMVlZmamHj58eF1JSck3REL/0r//+78nX27/y92/0msAAOD6nLfVBMJXOseO97yqzVPn7OHh4bgTJ04slpvdbo8Twa5oaGjo5aSkpJKUlJQyglyEfxBMJlNcVlZWXGlp6Zri4uLv7d+//5729vZMPeHL0aXjTdALAACim5qcXwZD2e/97bff3jB79uzl4qlaEeT+Mycn53ciL3gIchEY4mw2m2wrX15UVPTkgQMHZB+4W2VgU33e9OWxAABAbNAHIcpzfegk/SIbJLa1teWdOnXqX7Zu3bp63rx5u5OTk9//JAYDQVQGOfl3EH8QQ0NDw49+9atfPeFwOG5XbefqD6z+VmrwAgAAiB36uuZqsKKe0+Tzbrc7/c033/x2dnb2PZ2dnbs3bNjwm/T09Kqurq6YmQM2KoOcxWJJFUn7NVkL5/F4rPofQ42C0WvjQgcvAACA6A5x6ryu7uujW9VrVqtVTmESX1tbO6e5ufkHDofjSwcPHvzbqVOn7l+1apWc1iTqj8WUaPvDmc3mxwcHB4tKS0u/JP4AVvW8PmRZhjj5R5RJXVW1AgCA2AhxKrzJ7lT6OV5V5qhmVzkHnXqPuG88efLkwldeeeU33d3dP0tMTDTFQj5IiKI/XLwIcF9/+eWXfypu58tRKiq46SFOr5FT7eYAACA26F2nQoOY3j9ezimnT1mitdalf/DBB8+mpaWZV61a9X/E465oPh5RkXLkHyAQCHxl586d/8vpdI6FODmgQb0mqSpVeasndNZBBQAg9sKcPnG//rzaQvvOq4B3cU1X22uvvfZUeXn5M2az2T7e6k2TOsjpB/LzbjKU+Xy+ebt27fqrlpaW21VNnP7H05f6AAAAGI/KD7Lblcfjsb/++uvfqaqq2iGeS4jWZtawNK36/f7r8u/IAy3Sskmk5hfLysrWi0B3KU2PV50KAABwOSrESbKWrrW1deZ//dd//cP69esd27ZtO2a32z+JtpkupkTywZbNp729vU+dOHHiHtVhUYY4efBVfzh9HTYAAIDLUZlBZQwZ6hwOx6yampp/Ea/N0Vv8wrGFQ1hq5K7HAAN5MH0+3wKRlP9WVnmOt5QHtXAAAOBqqeW95EAIVSkkFRUVrd26dev2/Pz8F8TrF6IpX4QlyCUmJn7uf0OunfrGG2/c73a7p8oQp6fk0EXrWcQeAABcDdWyJ/vg66tBvP322zs2bNjwemZmZmc0Na+GJcg1Nzd/7n/DbrdnlZaWFgSDQaMe1hQGNwAAgGslA5w+HYmqpSsvL1/W0tKSNzIy0iW2sNQMLVq0KDqC3OedKVkmZKfTufTkyZP5IjUb9Nf0ZlU9zFEbBwAArsZ4s1/4/X7r0aNH792wYcNB8XgkWn6XsAS5nJycz/X+pKQk45tvvnmn1+s1qKQ8XkdBwhsAALhWoYMkVVPq6dOn1zz88MNZJpOpJVoGUoYlyBUXF3+ug5uZmbnw448/3h4MBq30fwMAADdCZWVlnsPh2LB27drXZPSYtEFuwYIFE36vXOD2+PHjS0tKSpaIUDdFX4aLMAcAAMLF7/cnfvTRR6s3b968x2QyBSdtkPs8Tat2uz3u0KFDMwcGBsbmMGGqEQAAcCPISqPm5uZH3W73LywWS/31bl7Nzs6OjiDncrkm/N7h4WFDIBBYbzAYLOqgagvdAgAAhIWsNBoYGJjq9XrtcknQaKhEirhRqyMjI8nyIIqDF6+CHLVxAADgRggEAnH9/f1pcj7bSRvkRBD7PG9P9ng8Rrkklz48WE3gBwAAEA4ydwSDwTi32z3NbDZP3iDX29s74feKA5gq0rBFDXJQy31RKwcAAMJJZo2RkZE4r9drm9RBrr+/f8LvHR4eTvH7/Zf6x6laODWXHAAAQLjIplWPx5Mmglz8J1EQPMIS5Hp6eib8XqvVmiYOoFU/doQ4AABwI/h8vriWlpZ50ZI7whLk2traJvQ+edBsNlvq4OCgRe8PJ4OcXBsNAAAgXGTekKNVnU7n/Ozs7E+iYV33sAS5OXPmTOh9RqMxrqOjI93tdierAyrDHYMcAABAuKkFCDwez7Tvfve7SeK+b1IGuWeeeWZC75s6dWrcz3/+81kiyJnlY4PBMFYTpwY9EOgAAEA4yezh9/tnNDY2rhFB7oPr+W+vXr06OoLcRJtWA4GAsaOj4zb1WE4CzGTAAADgRpC1cTJz+Hy+rKKiovX9/f3XNcg9+uij0RHkKisrJ/Q+m812S29v7zx1MFVNnD56FQAAIFxBTuYNj8cTV1FRse6JJ56I+MqksAS5c+fOTeh9iYmJc+UkfPK+Gi2iwhyjVgEAQDipSiM5BUl7e/ttjz/++Njgh0kX5A4dOjShg5eWlpbd2dk5U0/GKsCxVBcAALhR+vv7bWVlZbNHRkZarte/uWnTpugIcn/zN39zze9JSUmJ271796ySkhKTfCxr4fT+cQQ5AAAQTnKggxq5GgwGLUVFRRtHR0dfmXRBbsWKFdf8noyMjLgDBw7MkMFNtVGr+Vv0pboAAADCQVYYaeu8Gz/66KPVfr//ugW55557LjqC3ET6yKWlpdlcLteM0AOqauGojQMAAOGk98sfHh42tLW1Lfnrv/5rWTsXsf/nsAS5s2fPXvN7kpOTZ4ggN1MPbapWTg90AAAA4aLXyvX09ORkZGQs8Pl89ZMqyLW2tl7T/vKAGY3G6X19fWM1cioN6wcTAAAgnGQfOdnFy2QyjS1IMDg4mFxcXLxa5JD665FFHn744egIct/73veuaX+bzRa3b9++W1555ZWxIKfPGcf8cQAA4EZQ/fTllCOyUsnv91u7u7vv/PGPf7xLhLqI/D+HJcgNDQ1d0/4jIyPx4kAtDgaDCXyMAADAzaQtC5rgdDpzR0dH4wOBQEQ2D4YlOJWXl1/1vrKq0m6328SByuGjAwAAIoGaQaOmpmZZdXX1bPFUcyR29QpLkJNtzNeSer1e79Senp6ZfGwAAEAkBDjVX667uzv57Nmza7dv397s9/snR5C79957r3pfq9Uad+rUqamtra1ZfHwAAMDNFDrQMhgMJp87d+7eL33pS6/7fL7JEeT6+vquel/ZobCzs3Oxx+MhyAEAgJse5IxGo+y/P/Z4dHTU2NjYuKG0tHR2d3d3i1qsYCKWLVsWHUHO5XJd9b6ymrKrqyt3YGAgmY8PAAC4mWRQk02qaio0eb+urs5WU1OzYuHChS2yAiqShCXIHTt27KpTb0pKSobD4bg10g4MAACYnFTzqtLZ2ZkSCATmbN68Oa6/vz/2g9yiRYuu7ocnJMS53W67SLlzVQpm8l8AAHAzQ5yafkSFudHRUXNXV9f6hoaGF71e74RrnubNmxcdQe6OO+64qv0sFktcVVVVel9fX5I6eAAAADeDGqkamkfkfLeNjY15hw8fXuz3+0sm+u9v3LgxOoJce3v7Ve1nNpvj2traVvl8vmw+PgAA4GZSAU5f511NRyKCXNbBgweXer3ekokOePj7v//76AhyHR0dVxvkzJ2dnbMHBwfN+oEDAAC4mUEuVHNzc/LKlSvn/MVf/EXcwMBAxPyfwxLkenp6rjrI9fb2pgeDQT49AAAgIoKcolcwyelILly4sGDmzJmmvr6+iBmhGZYg19DQcFX7GQwGW2NjY87o6Oi4BxAAAOBGu7jO6lifOZVRpNbW1rxDhw4tHBgYKJ/Iv7t169boCHL333//Z+5jMplk4MvYvXv3otBZlAEAAG600L5xqolVPd/W1nZLWVlZzpQpU8ojJbOEJcjJER9Xsc+U4eHhvGAwONY/Tk28p1IwAADAjaSHM3lfre6gnm9qakr/4he/mPfDH/7w9263O3aD3NU0rRqNRnNzc/OSoaEhm3wsAxw1cgAAIJINDg7O9vl8BnF7PhL+P2EJcuXln910nJCQkNzd3X2Hqr0jxAEAgEjX0dEx9/jx41m9vb1t1zoNSdTMI3fkyJErvn5xQdpkg8Fwp2pKVQeDQAcAACJVc3NzTmNj47yUlJQ2fSDEzRKWILdu3borvi77w/X391vee++9GfIgqE6EE51gDwAA4EYQIe4Wk8l054MPPnjM4/HEZpD7yU9+csXX5YoOZWVlyXv27Bl7LIf30kcOAABEutHR0SkNDQ1rHQ7Hb10ul+9aKqHWrl0bHUGurq7uiq/LqUdaWlrmqMf6UF/CHAAAiEQqp4ickxMIBGbccsstdTe7eTUsQa6qquqKrxuNRpPT6bxDPygAAADRoK2tbWZKSkrGmjVr6nw+X+wFueLi4iu+bjKZzMFgMFc9pjYOAABEMtm/X/F4PDOdTufynJycE9cS5GbPnh0dQe7xxx+/4oGQAx1+8pOfrNAHORDkAABApFIZReaVwcHBhI8++mhLIBB4U9zvvtp/Y+XKldER5ERCvexrcmBDa2vr1Lq6umx9DTNCHAAAiOQgJ3OLDHIyu1RUVCwsKCiYlpeX1z08PHzT/l9hCXLV1dVXCnLxnZ2duRcuXJgiD4pamovmVQAAEKlU06payMDr9SYZjcb506ZNqwoGg7EV5Orr6y/7mghrBpfLlavSLeENAABEG4/HM8vpdK5JSkoqHBoauqoquc+aZzdigtwDDzxwuRAXJ35Zw89//vNLba96mzMAAEAkkvPdylq5hIT/H50CgUB8VVVVnsgxaefPn++6Wf+vsAQ5fWRHaJATv7Cxq6trjtpPHhj5vLoPAAAQiWTl08jIyKXHRUVFq7ds2TIrOzu7S38+6oPc4ODgZYOceC3D4XBsVQdEhTjVTw4AACBSg5y+NvzQ0JAxEAgsF7dlw8PD52MmyJ08efKyQU4k1rtdLtelx/JAUBMHAAAiXWg3MBHgbFVVVev7+vreGB0d/cyFV7dv3x4dQe4K/d3iGxoackV6HauFk9vNXtoCAADgarONXisnM0xZWdmayspK+8jIyGcGuX/8x3+MjiBXUFAw7vPilzecOHHCrg6IPtCBEawAACBS6QFOZRc5FYnD4ViQn59vttlsN6WFMSxBzu12j/u8+AUzOjs7N1+8H6fmkVMHAwAAIBLpq1CpSid56/V64x999NHMRYsW1dyMiYHDEuTa29svF+RuaWtru3u8lKvfAgAARBJ9SdHQ58+ePZvv9/uLR0dHrzh0dcWKFdER5AYGBi4X5FJ6e3tlveMU/QCEjgIBAACINGrKtNB14j/++OP1ZWVlvxwZGem/0ry4Tz/9dHQEucst0WWxWOb19PRcCm30iQMAANEgdLCDyjBGozHu9OnTa77//e8bb0Y/ubAEuaVLl37qOdkX7ve///1SORPyeO8h0AEAgGihApvs49/d3Z2am5u7cMaMGT03us9/WIKc+EU+9ZzBYMhwOp23yVBLeAMAANEktBtY6Fy4paWl+bW1tcfF48vOq7Zx48boCHIisH36ByUkzPN6vav4KAAAgGildwtTS5LKMFdSUrL8ueeeM1osltEbWVEVliAnEumnnjMYDLkDAwNJKskCAABEk9BaOf1xXV3dosTExKTk5ORAzAU5+QslJCTkiCAXT4gDAADRTNbEqSZVlWtaW1tvLSsrW56Wlvbe5bJOTk5OdAS5vr6+Tz3n8XhyxWbgzw8AAKKVqomTYU5foSoYDMadOXNmzTPPPFMoXrthQ1fDEuR+9KMf/cljq9VqePLJJ+f6/f4pfAQAAEC0CV2JSl/hQamvr797eHjYJvbtj+ogFzoh8MjIyC2BQGAqHwMAABCNQueH00Oc6ivndDq3NTU1LRBh78x4/8bixYujI8idO3fuTx5bLJZcr9c7g48BAACIRTLMydWr6uvrF86ePfvMjfq5YQlyR48e/ZNfLCMjY3EgEDDpnQMBAABiicvliq+srFy2Y8eOXTdqYuCwBLmVK1deum8ymeI++OCDRX6/38SfGAAAxCJZWTUyMhJfW1tb0N3dnS6CnDt0n7lz50ZHkHvqqacu3bfb7XF79+7NCQQCDHQAAAAxS/aT6+npWXLmzJkVFy5ceD/09RUrVkRHkNPnkRNBztzZ2ZmlfkHmkQMAALFGdh2TOae/v//8sWPH1no8nk8Fuaeffjo6glxTU9Ol+ykpKTMCgUAif2IAABCrVGVVb29vQmNj49LHHnssbnh4OOw/NyxBzuFwXLqfmJh4+9DQkFXepzYOAADEMhHe4t1u9/xVq1bZAoGANyqDXFVVVZwKbqmpqfPPnz8/FuQYtQoAAGKRmktO3g4MDMyoqKhYMjQ0dEzfZ82aNdER5Hbs2DF2m5SUFPfyyy/nDg4OJsnHBoOBIAcAAGKSzDmjo6NxPp8v5YMPPtjo9/v/JMh95zvfiY4gl5qaOnablpaW1N7evlQk0nj5+EbNqQIAAHCjqS5kHo/H3NzcvPY//uM/PrXaVVQEOafTOXbrcrnm9/T0zBr7QQkJYykVAAAgFqlWx5GRkbiOjo75KSkpU86fPx/WpsiwBLktW7aMNaseOHBgukilDHQAAAAxT886g4ODtuPHj98pclCpei4vLy86gpxsQpW/TE9Pz8KhoaEk9RyDHQAAQCySAx30QBcMBm0nTpxYbjQaS8NZmRWWICdS6Fhoa29v3zE8PJzKnxcAAEyGMKcqrHw+X2JnZ+fSJ5980ihy0UhUBTmRQuOsVmt8c3PzqGwnlmSwo3kVAADEKhXiZOYRWcjgcDg2iUA32+VyNeg1dhEf5EpKSuIyMzNntLe3p8kgJ38huTHYAQAAxKLxKqu8Xq9dZKFb0tLSGsKVgcIS5Gw2mxy5ervYpoemVAAAgFijjwNQtW/9/f2JgUBgziOPPCJDXXh+bjj+UTlqVSTPW/r6+lJUSpW/nPwlAQAAYpnWTy65sbFxc2trq6G+vj56gpzL5ZLb2vPnzyep5SpUoAMAAIjV8KYbHh5OKC0tXed0OufL1sqoCXJ1dXXpnZ2di0dHRxNUeGOwAwAAiGWqSVXeqlbI6upqm8hEt916663RE+Rqa2uzurq6kkUS/dQvBwAAEMv02rlAIJAhMtEDPT090RPkjEZjdk1NTZasgZOJVM2rQpgDAACxSLU8yqyj5x3ZOtnQ0HB7dXW1PWqC3MjISFpHR4ddpVL5i6kNAAAg1ugZR888Q0NDcY2NjdNPnz6dE46fG5bpR0SI+0+RQM3yvsFguJRQmYIEAADEMn2Qp8o+Z8+enVFQUCCD3OmoCHKtra02FdrkGqsAAACxHuBCyeZWmYO6urpS3W73EvHU69f754alaVUEuT9Jo5KsmZMbAABArFG5R1Vkycd6ZVZTU9PfhePnhqVGTo7MCJ38Vw18SEhI4K8NAABiihrkIJfikllHjRFQy5Q6nc6w/NywpKqVK1e6Fy1a9In4ZeLFf15G009EKp0ifkFGOwAAgJgjQtsUEeDOy0mAhQviscw+8eL+JyL/TJk6dWpY+pqFJcht27bt/4r//Ij4HRIMBsOQCHMi041axC8yyp8aAADEWo4TOcdqNBp9IsilivAWFJnngiBz0LDIRGar1eoPxw+OZ0oQAACA6MQq9gAAAAQ5AAAAEOQAAABAkAMAACDIAQAAgCAHAAAAghwAAABBDgAAAAQ5AAAAEOQAAABAkAMAACDIAQAAgCAHAAAAghwAAABBDgAAAAQ5AAAAEOQAAABAkAMAACDIAQAAgCAHAAAAghwAAABBDgAAAAQ5AAAAEOQAAABAkAMAACDIAQAAgCAHAAAAghwAAABBDgAAAAQ5AAAAEOQAAAAIcgAAACDIAQAAgCAHAAAAghwAAABBDgAAAAQ5AAAAEOQAAAAIcgAAACDIAQAAgCAHAAAAghwAAABBDgAAAAQ5AAAAEOQAAAAIcgAAACDIAQAAgCAHAAAAghwAAABBDgAAAAQ5AAAAXJP/J8AANgj8Tjlj6qIAAAAASUVORK5CYII=";
                                    }
                                });
                            } else {
                                console.log('No network');
                            }

                        }
                    });
                }
            }, 1000);
            $scope.flagEdit = false;
            $scope.ShowEdit = function () {
                $scope.flagEdit = !$scope.flagEdit;
            };
            // Edit Form User Information Mobile
            $scope.EditOnlyImage = function () {
                // /users/{id}/photos/mobiles/edits.
                $http({
                    method: 'POST',
                    url: BaseUrl + '/mobile/users/photos/mobiles/edits.json',
                    headers: {'x-wsse': $rootScope.loginInfo},
                    data: {'photo': $scope.user.photo}
                }).then(function (respone) {

                    if (respone.data.message == 1) {
                        var query = "UPDATE fos_user SET photo=? WHERE id=?";
                        $cordovaSQLite.execute(db, query, [$scope.user.photo, $scope.user.id]).then(function (data) {
                            //$scope.showAlert('عکس شما بروزرسانی شد');
                            $scope.ShowToast('عکس شما بروزرسانی شد');
                        }, function (err) {
                            console.error(err);
                        });
                        if ($rootScope.LoginUser) {
                            $rootScope.imgProfile = $scope.user.photo;
                        }
                    } else {
                        $scope.showAlert('خطا در سرور');
                    }

                });
            };
            $scope.ClickEditBtn = function () {

                var strMobile = $scope.user.mobile;
                if (strMobile.length < 11) {
                    strMobile = '0' + strMobile;
                }

                if (isValidPhone(strMobile))
                {
                    $scope.user.mobile = strMobile;
                    $http({
                        method: 'POST',
                        url: BaseUrl + '/mobile/users/infos/edits.json',
                        headers: {'x-wsse': $rootScope.loginInfo},
                        data: $scope.user
                    }).then(function success(response) {
                        // console.log(response);
                        var query = "UPDATE fos_user SET id=?,username=?,email=?,enabled=?,salt=?,password=?,name=?,family=?,phone=?,mobile=?,sex=?,post_code=?,address=?  WHERE id=?";
                        $cordovaSQLite.execute(db, query, [$scope.user.id, $scope.user.username, $scope.user.email, $scope.user.enabled,
                            $scope.user.salt, $scope.user.password, $scope.user.name, $scope.user.family, $scope.user.phone,
                            $scope.user.mobile, $scope.user.sex, $scope.user.post_code, $scope.user.address, $scope.user.id]).then(function (data) {
                            $scope.showAlert('اطلاعات شما بدرستی ویرایش شد');
                        }, function (err) {
                            $scope.showAlert(err);
                            console.error(err);
                        });
                    });
                } else {
                    $scope.showAlert('شماره موبایل را معتبر وارد کنید');
                }
            };
            $scope.focus = function (e) {
                var element = e.target.previousElementSibling.classList[2];
                e.target.previousElementSibling.classList.remove(element);
                e.target.previousElementSibling.classList.add(element.replace('-outline', ''));
            };
            $scope.blur = function (e) {
                var element = e.target.previousElementSibling.classList[2];
                e.target.previousElementSibling.classList.remove(element);
                e.target.previousElementSibling.classList.add(element + '-outline');
            };
            $ionicModal.fromTemplateUrl('partials/setting/modalProfile.html', {
                scope: $scope,
                animation: 'scale-in'
            }).then(function (modal) {
                $scope.modal = modal;
            });
            $scope.openModal = function () {
                $scope.modal.show();
            };
            $scope.closeModal = function () {
                $scope.modal.hide();
            };

            var options = {
                quality: 50,
                destinationType: Camera.DestinationType.DATA_URL,
                sourceType: Camera.PictureSourceType.CAMERA,
                allowEdit: true,
                encodingType: Camera.EncodingType.JPEG,
                targetWidth: 210,
                targetHeight: 280,
                popoverOptions: CameraPopoverOptions,
                saveToPhotoAlbum: false,
                correctOrientation: true
            };
            $scope.turnCamera = function () {
                $cordovaCamera.getPicture(options).then(function (imageData) {
                    $jrCrop.crop({
                        url: imageData,
                        width: 200,
                        height: 200,
                        title: "برش عکس"
                    }).then(function (canvas) {
                        // success!
                        var image = canvas.toDataURL();
                        $scope.user.photo = image;
                        $scope.EditOnlyImage();
                        //$state.go('optionProfile');
                        //$scope.closeModal();
                    }, function () {
                        // User canceled or couldn't load image.
                    });
                }, function (err) {
                    console.log('Error' + err);
                });
            };
            var options = {
                maximumImagesCount: 1,
                width: 210,
                height: 280,
                quality: 50
            };
            function convertImgToDataURLviaCanvas(url, callback, outputFormat) {
                var img = new Image();
                img.crossOrigin = 'Anonymous';
                img.onload = function () {
                    var canvas = document.createElement('CANVAS');
                    var ctx = canvas.getContext('2d');
                    var dataURL;
                    canvas.height = options.height;
                    canvas.width = options.width;
                    ctx.drawImage(this, 0, 0);
                    dataURL = canvas.toDataURL(outputFormat);
                    callback(dataURL);
                    canvas = null;
                };
                img.src = url;
            }

            $scope.openGallery = function () {
                $cordovaImagePicker.getPictures(options)
                        .then(function (results) {
                            for (var i = 0; i < results.length; i++) {
                                $jrCrop.crop({
                                    url: results[i],
                                    width: 200,
                                    height: 200,
                                    title: "برش عکس",
                                    circle: true
                                }).then(function (canvas) {
                                    // success!
                                    var image = canvas.toDataURL();
                                    $scope.user.photo = image;
                                    $scope.EditOnlyImage();
                                    //$state.go('optionProfile');
                                    //$scope.closeModal();

                                }, function () {
                                    // User canceled or couldn't load image.
                                });

                            }
                        }, function (error) {
                            console.log('Error' + error);
                        });
            };
        })
        .controller('myAnimalsController', function ($http,$cordovaToast, $jrCrop, $cordovaNetwork, $cordovaSQLite, $rootScope, $scope, $ionicPopup, $ionicListDelegate, $ionicModal, $cordovaCamera, $cordovaImagePicker, $ionicSlideBoxDelegate, $state) {

            // code to run each time view is entered
            $scope.animalsUser = [];
            $scope.animalsUser.infoAnimals = [];
            $scope.animalsUser.defaultPhoto = [];
            $scope.onlined = $cordovaNetwork.isOnline();
            $scope.animalCategory = [];

            //Option List Animals
            $scope.listCanSwipe = true;
            $scope.newPushed = null; //get index new animal
            $scope.showAlert = function (str) {
                var alertPopup = $ionicPopup.alert({
                    title: 'هشدار',
                    template: "<div style='direction:rtl;text-align:right'>" + str + "</div>",
                    buttons: [{// Array[Object] (optional). Buttons to place in the popup footer.
                            text: 'تایید',
                            type: 'button-default btn-submit'
                        }]
                });
            };
            $scope.ShowToast = function (str) {
                $cordovaToast
                        .show(str, 'long', 'bottom')
                        .then(function (success) {
                            // success
                        }, function (error) {
                            // error
                        });
            };
            function refreshAnimalTable() {
                var queryDel = 'DELETE FROM animals';
                $cordovaSQLite.execute(db, queryDel, []);
            }
            function refreshAnimalPhoto() {
                $http.get(BaseUrl + '/mobile/all/pictures/animals/mobile.json',
                        {headers: {'x-wsse': 'UsernameToken Username="' + $rootScope.loginInfo}}, {cache: true}).success(function (response) {
                    //$scope.imagesAnimal = response;
                    var queryDel = 'DELETE FROM animalsphoto';
                    $cordovaSQLite.execute(db, queryDel, []);

                    var query = 'INSERT INTO animalsphoto(id,animals_id,photo,photoDefault,created_at,updated_at) VALUES (?,?,?,?,?,?)';
                    var item;
                    for (item = 0; item < response.length; item++) {
                        $cordovaSQLite.execute(db, query, [response[item].id, response[item].animals.id, response[item].photo, response[item].photo_default, response[item].create_at, response[item].update_at]).then(function success() {

                        });
                    }
                });
            }
            $scope.getCategorytypeClient = function (id) {
                if (id == null) {
                    return 'Unknown';
                } else {
                    var i = 0;
                    for (i = 0; $scope.animalCategory.length; i++) {
                        if ($scope.animalCategory[i].id == id) {
                            return $scope.animalCategory[i].animalsType;
                        }
                    }
                }
            };

            var query = "SELECT * FROM animals WHERE user_id = ?";
            $cordovaSQLite.execute(db, query, [$rootScope.userID]).then(function sucess(result) {
                var i = 0;
                var arrayCheckListDBClient = [];
                if (result.rows.length > 0) {
                    if ($cordovaNetwork.isOnline()) {
                        for (i = 0; i < result.rows.length; i++) {
                            arrayCheckListDBClient.push(result.rows.item(i));
                        }
                        $http({
                            method: 'POST',
                            url: BaseUrl + '/mobile/checks/animals/syncs.json',
                            headers: {'x-wsse': 'UsernameToken Username="' + $rootScope.loginInfo},
                            data: arrayCheckListDBClient
                        }, {cache: true}).then(function (response) {
                            if (response.data.sync == 1) {
                                console.log('sync');
                                $scope.animalsUser = [];
                                $scope.animalsUser.infoAnimals = [];
                                $scope.animalsUser.defaultPhoto = [];

                                for (i = 0; i < result.rows.length; i++) {
                                    $scope.animalsUser.infoAnimals.push(result.rows.item(i));
                                    var query = "SELECT * FROM animalsphoto WHERE animals_id = ? and photoDefault = 'true'";
                                    $cordovaSQLite.execute(db, query, [result.rows.item(i).id]).then(function (res) {
                                        if (res.rows.length > 0) {
                                            var j;
                                            for (j = 0; j < res.rows.length; j++) {
                                                $scope.animalsUser.defaultPhoto.push(res.rows.item(j));
                                            }
                                        }
                                    });
                                }

                                console.log($scope.animalsUser.defaultPhoto);
                            } else {
                                console.log('No sync');
                                $scope.animalsUser = [];
                                $scope.animalsUser.infoAnimals = [];
                                $scope.animalsUser.defaultPhoto = [];
                                $scope.animalsUser.infoAnimals = response.data.infoAnimals;
                                $scope.animalsUser.defaultPhoto = response.data.defaultPhoto;
                                if (response.data.infoAnimals.length > 0) {
                                    var index = 0;
                                    var idAnimal = null;

                                    var queryDel = 'DELETE FROM animals';
                                    $cordovaSQLite.execute(db, queryDel, []);

                                    var query = 'INSERT INTO animals(id,user_id,active, name, age, sex, weight, stature,microChip,color,codeParvande, goneh, nezhad, dateCreateParvande,Animalscategory_id,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)';
                                    for (index = 0; index < response.data.infoAnimals.length; index++) {
                                        idAnimal = response.data.infoAnimals[index].id;

                                        $cordovaSQLite.execute(db, query, [response.data.infoAnimals[index].id, $rootScope.userID, response.data.infoAnimals[index].active
                                                    , response.data.infoAnimals[index].name, response.data.infoAnimals[index].age, response.data.infoAnimals[index].sex
                                                    , response.data.infoAnimals[index].weight, response.data.infoAnimals[index].stature, response.data.infoAnimals[index].micro_chip
                                                    , response.data.infoAnimals[index].color, response.data.infoAnimals[index].codeParvande, response.data.infoAnimals[index].goneh
                                                    , response.data.infoAnimals[index].nezhad, response.data.infoAnimals[index].dateCreateParvande, response.data.infoAnimals[index]._animalscategory.id
                                                    , response.data.infoAnimals[index].create_at, response.data.infoAnimals[index].update_at]).then(function (result) {

                                        });
                                    }
                                    refreshAnimalPhoto();
                                    console.log(response.data.infoAnimals);
                                }

                            }
                        });
                    } else { // else offline
                        for (i = 0; i < result.rows.length; i++) {
                            $scope.animalsUser.infoAnimals.push(result.rows.item(i));
                            console.log($scope.animalsUser);
                            var query2 = "SELECT * FROM animalsphoto WHERE animals_id = ? and photoDefault = 'true'";
                            $cordovaSQLite.execute(db, query2, [result.rows.item(i).id]).then(function (response) {
                                if (response.rows.length > 0) {
                                    var j = 0;
                                    for (j = 0; j < response.rows.length; j++) {
                                        $scope.animalsUser.defaultPhoto.push(response.rows.item(j));
                                    }
                                }
                            });
                        }
                    }
                } else {
                    //check online 
                    if ($cordovaNetwork.isOnline()) {
                        $http.get(BaseUrl + '/mobile/animals/user/mobile.json',
                                {headers: {'x-wsse': 'UsernameToken Username="' + $rootScope.loginInfo}}).success(function (response) {
                            $scope.animalsUser = response;

                            if (response.infoAnimals.length > 0) {
                                refreshAnimalTable();
                                refreshAnimalPhoto();

                                var index;
                                var idAnimal;
                                var query = 'INSERT INTO animals(id,user_id,active, name, age, sex, weight, stature,microChip,color,codeParvande, goneh, nezhad, dateCreateParvande,Animalscategory_id,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)';
                                for (index = 0; index < response.infoAnimals.length; index++) {
                                    idAnimal = response.infoAnimals[index].id;

                                    $cordovaSQLite.execute(db, query, [response.infoAnimals[index].id, $rootScope.userID, response.infoAnimals[index].active
                                                , response.infoAnimals[index].name, response.infoAnimals[index].age, response.infoAnimals[index].sex
                                                , response.infoAnimals[index].weight, response.infoAnimals[index].stature, response.infoAnimals[index].micro_chip
                                                , response.infoAnimals[index].color, response.infoAnimals[index].codeParvande, response.infoAnimals[index].goneh
                                                , response.infoAnimals[index].nezhad, response.infoAnimals[index].dateCreateParvande, response.infoAnimals[index]._animalscategory.id
                                                , response.infoAnimals[index].create_at, response.infoAnimals[index].update_at]).then(function (result) {

                                    });
                                }

                                refreshAnimalPhoto();
                            }

                        });

                    } else {
                        $scope.ShowToast('حیوانی جهت نمایش یافت نشد');
//                        console.log('حیوانی جهت نمایش یافت نشد');
                    }
                }

            });
            setTimeout(function () {
                if ($cordovaNetwork.isOnline()) {
                    ///animals/category/mobile.{_format} 
                    $http.get(BaseUrl + '/mr/animals/category/mobile.json',
                            {headers: {'x-wsse': 'UsernameToken Username="' + $rootScope.loginInfo}}).success(function (response) {
                        $scope.animalCategory = response;
                        console.log(response);
                        if (response.length > 0) {
                            var i;
                            for (i = 0; i < response.length; i++) {
                                var query = 'INSERT INTO animalscategory (id,animalsType,describtion,created_at,updated_at) VALUES (?,?,?,?,?)';
                                $cordovaSQLite.execute(db, query, [response[i].id, response[i].animalstype, response[i].describtion, response[i].create_at, response[i].update_at]).then(function success() {

                                });
                            }
                        }
                    });

                } else {
                    var query = "SELECT * FROM animalscategory";
                    $cordovaSQLite.execute(db, query, []).then(function (result) {
                        if (result.rows.length > 0) {
                            var i;
                            for (i = 0; i < result.rows.length; i++) {
                                $scope.animalCategory.push(result.rows.item(i));
                            }

                        }
                    });
                }

            }, 1000);

            var options = {
                quality: 50,
                destinationType: Camera.DestinationType.DATA_URL,
                sourceType: Camera.PictureSourceType.CAMERA,
                allowEdit: true,
                encodingType: Camera.EncodingType.JPEG,
                targetWidth: 640,
                targetHeight: 480,
                popoverOptions: CameraPopoverOptions,
                saveToPhotoAlbum: false,
                correctOrientation: true
            };

            $scope.turnCamera = function () {
                if ($cordovaNetwork.isOnline()) {
                    $cordovaCamera.getPicture(options).then(function (imageData) {
                        $jrCrop.crop({
                            url: imageData,
                            width: 640,
                            height: 480,
                            title: "برش عکس"
                        }).then(function (canvas) {
                            // success!
                            var image = canvas.toDataURL();
                            $scope.photoInsert = image;
                            $scope.addPhotoToAnimalGallery();
                        }, function () {
                            // User canceled or couldn't load image.
                        });


                    }, function (err) {
                        // error
                    });
                }
            };
            var options = {
                maximumImagesCount: 1,
                width: 640,
                height: 480,
                quality: 50
            };
            function convertImgToDataURLviaCanvas(url, callback, outputFormat) {
                var img = new Image();
                img.crossOrigin = 'Anonymous';
                img.onload = function () {
                    var canvas = document.createElement('CANVAS');
                    var ctx = canvas.getContext('2d');
                    var dataURL;
                    canvas.height = options.height;
                    canvas.width = options.width;
                    ctx.drawImage(this, 0, 0);
                    dataURL = canvas.toDataURL(outputFormat);
                    callback(dataURL);
                    canvas = null;
                };
                img.src = url;
            }
            $scope.openGallery = function () {
                if ($cordovaNetwork.isOnline()) {
                    $cordovaImagePicker.getPictures(options)
                            .then(function (results) {
                                for (var i = 0; i < results.length; i++) {
                                    $jrCrop.crop({
                                        url: results[i],
                                        width: 640,
                                        height: 480,
                                        title: "برش عکس"
                                    }).then(function (canvas) {
                                        // success!
                                        var image = canvas.toDataURL();
                                        $scope.photoInsert = image;
                                        $scope.addPhotoToAnimalGallery();
                                    }, function () {
                                        // User canceled or couldn't load image.
                                    });
                                }
                            }, function (error) {
                                // error getting photos
                            });
                }
            };
            //these all function for edit information animal
            $scope.currentAnimalSelect; //get current animal select index id
            $scope.currentAnimalId; //get current animal id index id
            $scope.ShowModalEditAnimals = function (animalId, index) {

                //current animal selected for represent information
                $scope.currentAnimalSelect = index;
                $scope.currentAnimalId = animalId;
                $scope.FlagInsertOrEdit = false; //false mode edit
                $scope.imagesAnimal = [];

                var query = "SELECT * FROM animalsphoto WHERE animals_id = ?";
                $cordovaSQLite.execute(db, query, [animalId]).then(function (result) {
                    if (result.rows.length > 0) {
                        if ($cordovaNetwork.isOnline()) {
                            $http.get(BaseUrl + '/mobile/pictures/' + animalId + '/animals/mobile.json', {cache: true},
                                    {headers: {'x-wsse': 'UsernameToken Username="' + $rootScope.loginInfo}}).success(function (response) {
                                $scope.imagesAnimal = response;
                                $ionicSlideBoxDelegate.update();
                                if (!$scope.$$phase) {
                                    $scope.$apply();
                                }
                            });
                        } else {
                            var i;
                            for (i = 0; i < result.rows.length; i++) {
                                $scope.imagesAnimal.push(result.rows.item(i));
                                $ionicSlideBoxDelegate.update();
                                if (!$scope.$$phase) {
                                    $scope.$apply();
                                }
                            }
                        }
                    } else {
                        if ($cordovaNetwork.isOnline()) {
                            $http.get(BaseUrl + '/mobile/pictures/' + animalId + '/animals/mobile.json', {cache: true},
                                    {headers: {'x-wsse': 'UsernameToken Username="' + $rootScope.loginInfo}}).success(function (response) {
                                if (response.length > 0) {
                                    console.log('response is');
                                    console.log(response);
                                }
                                $scope.imagesAnimal = response;
                                $ionicSlideBoxDelegate.update();
                                if (!$scope.$$phase) {
                                    $scope.$apply();
                                }

                            });
                        } else {
                            var i;
                            for (i = 0; i < result.rows.length; i++) {
                                $scope.imagesAnimal.push(result.rows.item(i));
                                $ionicSlideBoxDelegate.update();
                                if (!$scope.$$phase) {
                                    $scope.$apply();
                                }
                            }
                        }
                    }

                });
                $scope.openModal();
            };

            //Edit Animals Information
            $scope.deletePhotoAnimal = function (index, id) {
                if ($cordovaNetwork.isOnline()) {
                    $http({
                        method: 'DELETE',
                        url: BaseUrl + '/mobile/photos/' + id + '/animals/mobile.json',
                        headers: {'x-wsse': 'UsernameToken Username="' + $rootScope.loginInfo}
                    }).then(function (response) {
                        if (response.data.message == 0)
                        {
                            $scope.imagesAnimal.splice(index, 1);
                            $ionicSlideBoxDelegate.update();
                            $ionicSlideBoxDelegate.previous();
                            if (!$scope.$$phase) {
                                $scope.$apply();
                            }
                            $scope.showAlert("عکس بدرستی پاک شد");
                        }
                    });
                } else {
                    $scope.showAlert("شما به اینترنت متصل نیستید");
                }

            };
            $scope.SetDefaultImage = function (index, id) {
                if ($cordovaNetwork.isOnline()) {
                    $http({
                        method: 'PUT',
                        url: BaseUrl + '/mobile/animals/' + id + '/defaults/' + $scope.currentAnimalId + '/picture/mobile.json',
                        headers: {'x-wsse': 'UsernameToken Username="' + $rootScope.loginInfo}
                    }).then(function (response) {
                        if (response.data.message == 0) {
                            var i = 0;
                            for (i = 0; i < $scope.imagesAnimal.length; i++)
                            {
                                $scope.imagesAnimal[i].photo_default = false;
                            }
                            $scope.imagesAnimal[index].photo_default = true;
                            $scope.animalsUser.defaultPhoto[$scope.currentAnimalSelect].photo = $scope.imagesAnimal[index].photo;
                            $scope.showAlert("عکس پیشفرض بدرستی انتخاب شد");
                        }
                    });
                } else {
                    $scope.showAlert("شما به اینترنت متصل نیستید");
                }

            };
            $scope.addPhotoToAnimalGallery = function () {
                if ($cordovaNetwork.isOnline()) {
                    //photos/animals/mobiles.json
                    var data = {
                        'photo_default': 0,
                        'photoInsert': $scope.photoInsert,
                        'animal': $scope.currentAnimalId
                    };
                    $http({
                        method: 'POST',
                        url: BaseUrl + '/mobile/photos/animals/mobiles.json',
                        data: data,
                        headers: {'x-wsse': 'UsernameToken Username="' + $rootScope.loginInfo}
                    }).then(function (response) {
                        if (response.data.message != 1) {
                            $scope.imagesAnimal.push(response.data.message);
                            $ionicSlideBoxDelegate.update();
                            $scope.$apply();
                            $scope.showAlert("عکس جدید اضافه شد");
                        }
                    });
                } else {
                    $scope.showAlert("شما به اینترنت متصل نیستید");
                }

            };
            $scope.EditInformationAnimal = function () {
                if ($cordovaNetwork.isOnline()) {
                    //conver Array to Obj
                    var dataSendServer = {};
                    for (var i = 0; i < $scope.animalsUser.infoAnimals[$scope.currentAnimalSelect].length; i++) {
                        dataSendServer[i] = $scope.animalsUser.infoAnimals[$scope.currentAnimalSelect][i];
                    }

                    $http({
                        method: 'POST',
                        url: BaseUrl + '/mobile/animals/' + $scope.currentAnimalId + '/edits/infos/mobiles.json',
                        data: dataSendServer,
                        headers: {'x-wsse': 'UsernameToken Username="' + $rootScope.loginInfo}
                    }).then(function (res) {
                        if (res.data.message == 0)
                        {
                            $scope.$watch($scope.animalsUser.infoAnimals[$scope.currentAnimalSelect]._animalscategory, function () {
                                //change category type in animal list
                                var i = 0;
                                for (i = 0; i < $scope.animalCategory.length; i++) {
                                    if ($scope.animalsUser.infoAnimals[$scope.currentAnimalSelect]._animalscategory.id == $scope.animalCategory[i].id) {
                                        $scope.animalsUser.infoAnimals[$scope.currentAnimalSelect]._animalscategory.animalstype = $scope.animalCategory[i].animalstype;
                                        $scope.animalsUser.infoAnimals[$scope.currentAnimalSelect]._animalscategory.describtion = $scope.animalCategory[i].describtion;
                                    }
                                }
                                // console.log($scope.animalsUser.infoAnimals[$scope.currentAnimalSelect]._animalscategory);
                            });
                            $scope.showAlert("اطلاعات این حیوان بدرستی ویرایش شد");
                        }
                    });
                } else {
                    $scope.showAlert("شما به اینترنت متصل نیستید");
                }
            };
            $scope.DeleteAnimal = function (idAnimal, index) {
                if ($cordovaNetwork.isOnline()) {
                    $http({
                        method: 'DELETE',
                        url: BaseUrl + '/mobile/owners/' + idAnimal + '/animals/mobile.json',
                        headers: {'x-wsse': 'UsernameToken Username="' + $rootScope.loginInfo}
                    }).then(function (response) {
                        if (response.data.message == 0)
                        {
                            $scope.animalsUser.infoAnimals.splice(index, 1);
                            $scope.animalsUser.defaultPhoto.splice(index, 1);
                            $scope.showAlert("این حیوان از لیست شما پاک شد.این حیوان در سامانه کد الکترونیکی وجود دارد");
                        }
                    });
                } else {
                    $scope.showAlert("شما به اینترنت متصل نیستید");
                }
            };
            //set icon out-line
            $scope.focus = function (e) {
                var element = e.target.previousElementSibling.classList[2];
                e.target.previousElementSibling.classList.remove(element);
                e.target.previousElementSibling.classList.add(element.replace('-outline', ''));
            };
            $scope.blur = function (e) {
                var element = e.target.previousElementSibling.classList[2];
                e.target.previousElementSibling.classList.remove(element);
                e.target.previousElementSibling.classList.add(element + '-outline');
            };
            //create form modal for edit and insert
            $ionicModal.fromTemplateUrl('partials/setting/modalAnimalEdit.html', {
                scope: $scope,
                animation: 'scale-in'
            }).then(function (modal) {
                $scope.modal = modal;
            });
            //opens modals
            $scope.openModal = function () {
                $scope.modal.show();
            };
            //closes modals
            $scope.closeModal = function () {
                $scope.modal.hide();
            };

            $scope.showSavabegh = function (idAnimal) {
                $rootScope.idAnimalForSavabegh = idAnimal;
                $state.go('savabegh');
            };




        })
        .controller('historyAnimal', function ($scope, $http, $rootScope, $cordovaNetwork, $ionicModal, $ionicPopup) {

            $ionicModal.fromTemplateUrl('partials/setting/modalImageView.html', {
                scope: $scope,
                animation: 'scale-in'
            }).then(function (modal) {
                $scope.modal = modal;
            });

            $scope.$on('$destroy', function () {
                $scope.modal.remove();

            });
            $scope.closeModal = function () {
                $scope.imageShow = null;
                $scope.modal.hide();
            };
            $scope.openModal = function (image) {
                $scope.imageShow = image;
                $scope.modal.show();
            };

            $scope.showAlert = function (str) {
                var alertPopup = $ionicPopup.alert({
                    title: 'هشدار',
                    template: "<div style='direction:rtl;text-align:right'>" + str + "</div>",
                    buttons: [{// Array[Object] (optional). Buttons to place in the popup footer.
                            text: 'تایید',
                            type: 'button-default btn-submit'
                        }]
                });
            };
            if ($cordovaNetwork.isOnline()) {

                var after = 0;
                $scope.showMessage = "اطلاعاتی جهت نمایش موجود نمی باشد";

                $scope.id = $rootScope.idAnimalForSavabegh;
                $scope.historyArray = [];

                $scope.loadMore = function () {
                    if ($scope.busyScroll)
                    {
                        return false;
                    }
                    $scope.busyScroll = true;
                    //History/
                    var url = BaseUrl + "/History/";
                    url += $scope.id + "/id/-1/filter/" + after + "/offsets/8/limits";

                    $http.get(url, {cache: true}).success(function (data) {
                        var iCount = data.history.length;

                        if (iCount > 0)
                        {
                            for (var i = 0; i < iCount; i++) {
                                $scope.historyArray.push(data.history[i]);
                                after++;
                            }
                            if (iCount === 8)
                                $scope.busyScroll = false;
                        }
                        $scope.$broadcast('scroll.infiniteScrollComplete');
                    });

                    $scope.$on('$stateChangeSuccess', function () {
                        $scope.loadMore();
                    });
                };
            } else {
                $scope.showAlert("دستگاه شما به اینترنت متصل نیست");
            }
        })
        .controller('myMessageController', function ($scope, $http, $cordovaNetwork, $ionicModal, $cordovaSQLite, $rootScope, $ionicPopup, $ionicListDelegate) {
            // read message of local database
            $rootScope.messageNotReaded = [];
            $scope.SendMessageBody = {};
            $scope.showAlert = function (str) {
                $ionicPopup.alert({
                    title: 'هشدار',
                    template: "<div style='direction:rtl;text-align:right'>" + str + "</div>",
                    buttons: [{// Array[Object] (optional). Buttons to place in the popup footer.
                            text: 'تایید',
                            type: 'button-default btn-submit'
                        }]
                });
            };
            //current message for show
            $scope.messageIdShow;
            $ionicModal.fromTemplateUrl('partials/setting/modalShowMessage.html', {
                scope: $scope,
                animation: 'scale-in'
            }).then(function (modal) {
                $scope.modal1 = modal;
            });
            $ionicModal.fromTemplateUrl('partials/setting/sendMessage.html', {
                scope: $scope,
                animation: 'scale-in'
            }).then(function (modal) {
                $scope.modal2 = modal;
            });
            $scope.$on('$destroy', function () {
                $scope.modal1.remove();
                $scope.modal2.remove();
            });

            $scope.closeModal = function (index) {
                switch (index) {
                    case 1:
                        $scope.modal1.hide();
                        break;
                    case 2:
                        $scope.modal2.hide();
                        break;
                }
            };
            $scope.openModal = function (index) {
                switch (index) {
                    case 1:
                        $scope.modal1.show();
                        break;
                    case 2:
                        $scope.modal2.show();
                        break;
                }
            };
            $scope.messageRead = function (index) {
                if ($rootScope.messageNotReaded[index].is_read == 0) {
                    $rootScope.messageNotReaded[index].is_read = 1;
                    var query = "UPDATE user_message SET is_read = 1 WHERE id = ?";
                    $cordovaSQLite.execute(db, query, [$rootScope.messageNotReaded[index].id]).then(function (data) {
                        $rootScope.messageNotReaded = [];
                        var query = "SELECT * FROM user_message WHERE is_read = '0' ORDER BY created_at DESC";
                        $cordovaSQLite.execute(db, query, []).then(function (data) {
                            if (data.rows.length > 0) {
                                for (var i = 0; i < data.rows.length; i++) {
                                    $rootScope.messageNotReaded.push(data.rows.item(i));
                                }
                                console.log($rootScope.messageNotReaded);
//                                window.cordova.plugins.backgroundMode.configure({
//                                    text: 'پیام خوانده نشده دارید',
//                                    title: 'نرم افزار آبان پت',
//                                    silent: false
//                                });
                                flagReadMessage = true;
                            }
                        });
                    });
                }
                //config modal for show message
                $scope.messageIdShow = index;
                $scope.openModal(1);
            };
            $scope.SendMessage = function () {
                $rootScope.messageNotReaded = [];
                var data = {
                    'message': $scope.SendMessageBody.msg
                };
                if ($cordovaNetwork.isOnline() && $rootScope.LoginUser) {
                    //mobile/sends/messages/tos/admins/mobiles
                    $http({
                        cache: true,
                        method: 'POST',
                        url: BaseUrl + '/mobile/sends/messages/tos/admins/mobiles.json',
                        headers: {'x-wsse': 'UsernameToken Username="' + $rootScope.loginInfo},
                        data: data
                    }).then(function (response) {
                        if (response.data.message === '0')
                        {
                            $scope.showAlert('با موفقیت ارسال شد');
                            $scope.closeModal(2);
                            $scope.SendMessageBody.msg = '';
                        } else if (response.data.message === '-1') {
                            $scope.showAlert('با خطا مواجه شدید');
                        }
                    });
                } else {
                    $scope.showAlert('برای ارسال پیام باید آنلاین باشید');
                }
            };
            $scope.deleteRead = function (index) {
                $scope.YesNo = false;
                var myPopup = $ionicPopup.show({
                    template: "<div style='direction:rtl;text-align:right'>آیا می خواهید این پیام حذف شود؟</div>",
                    title: 'هشدار',
                    subTitle: 'هشدار:برای همیشه حذف می شود',
                    scope: $scope,
                    buttons: [
                        {text: 'نه'},
                        {
                            text: '<b>بله</b>',
                            type: 'button-default btn-submit',
                            onTap: function (e) {
                                $scope.YesNo = true;
                            }
                        }
                    ]
                });
                if ($scope.YesNo) {
                    var query = "DELETE FROM user_message WHERE id = ?";
                    $cordovaSQLite.execute(db, query, [$rootScope.messageNotReaded[index].id]).then(function (data) {
                        $rootScope.messageNotReaded.splice(index, 1);
                    });
                }
            };


            $scope.checkDuplicateMessage = function (id) {
                var flag = 0;
                var search = "select * from user_message where(id = ?)";
                $cordovaSQLite.execute(db, search, id).then(function (result) {
                    if (result.rows.length > 0) {
                        flag = 0;
                    } else {
                        flag = 1;
                    }
                });
                return  flag;
            };
            $scope.refreshMessage = function () {
                $rootScope.messageNotReaded = [];
                if ($cordovaNetwork.isOnline()) {
                    if ($rootScope.LoginUser) {
                        $http.get(BaseUrl + '/mobile/messages/user/mobile.json',
                                {headers: {'x-wsse': $rootScope.loginInfo}}).success(function (response) {
                            console.log(response);
                            if (response.length > 0) {

                                var query = "INSERT INTO user_message VALUES (?,?,?,?,?,?,?,?,?)";
                                var i;
                                for (i = 0; i < response.length; i++) {
                                    $scope.checkDuplicateMessage(response[i].id);
                                    if ($scope.checkDuplicateMessage) {
                                        console.log("inserting mode");
                                        $cordovaSQLite.execute(db, query, [response[i].id, $rootScope.userID, response[i].created_at, response[i].updated_at,
                                            response[i].message_type, response[i].message, response[i].user_name_message_owner, response[i].message_owner, 0]).then(function (data) {

                                        }, function (err) {
                                            console.warn(err);
                                        });
                                    }
                                }

                                var query = "SELECT * FROM user_message WHERE is_read = '0' ORDER BY created_at DESC";
                                $cordovaSQLite.execute(db, query, []).then(function (data) {
                                    if (data.rows.length > 0) {
                                        for (var i = 0; i < data.rows.length; i++) {
                                            $rootScope.messageNotReaded.push(data.rows.item(i));
                                        }
                                        console.log($rootScope.messageNotReaded);
//                                        window.cordova.plugins.backgroundMode.configure({
//                                            text: 'پیام خوانده نشده دارید',
//                                            title: 'نرم افزار آبان پت',
//                                            silent: false
//                                        });
                                        flagReadMessage = true;
                                    }
                                });

                            } else {

                                var query = "SELECT * FROM user_message WHERE is_read = '0' ORDER BY created_at DESC";
                                $cordovaSQLite.execute(db, query, []).then(function (data) {
                                    if (data.rows.length > 0) {
                                        for (var i = 0; i < data.rows.length; i++) {
                                            console.log("db Client " + data.rows.item(i));
                                            $rootScope.messageNotReaded.push(data.rows.item(i));
                                        }

//                                        window.cordova.plugins.backgroundMode.configure({
//                                            text: 'پیام خوانده نشده دارید',
//                                            title: 'نرم افزار آبان پت',
//                                            silent: false
//                                        });
                                        flagReadMessage = true;
                                    }
                                });
                            }
                        });
                    }
                } else {

                    var query = "SELECT * FROM user_message WHERE is_read = '0' ORDER BY created_at DESC";
                    $cordovaSQLite.execute(db, query, []).then(function (data) {

                        if (data.rows.length > 0) {
                            for (var i = 0; i < data.rows.length; i++) {
                                $rootScope.messageNotReaded.push(data.rows.item(i));
                            }
                        }
                    });
                }
            }
            ;
            $scope.refreshMessage();


        })
        .controller('gallery', function ($scope, $state, $http, $cordovaNetwork, $ionicModal, $cordovaSQLite, $rootScope) {

            var after = 0;
            $scope.showMessage = "اطلاعاتی جهت نمایش موجود نمی باشد";
            $scope.idImage = [];
            $scope.items = [];

            $scope.backtoGallery = function () {
                $state.go('gallery');
            };

            $scope.setIdGallery = function (idItem) {
                idGallery = idItem;
                $state.go('galleryShowImages');
            };


            $scope.loadMore = function () {
                if ($scope.busyScroll)
                {
                    return false;
                }

                $scope.busyScroll = true;

                var url = BaseUrl + "/galleries/";
                url += "-1/" + after + "/8/id/desc";

                $http.get(url, {cache: true}).success(function (data) {
                    var iCount = data.length;
                    if (iCount > 0)
                    {
                        for (var i = 0; i < iCount; i++) {
                            $scope.idImage[data[i].id] = after;
                            $scope.items.push(data[i]);
                            after++;
                        }

                        if (iCount === 8)
                            $scope.busyScroll = false;
                    }

                    $scope.$broadcast('scroll.infiniteScrollComplete');
                });
                $scope.$on('$stateChangeSuccess', function () {
                    $scope.loadMore();
                });

            };


        })
        .controller('galleryShowImages', function ($scope, $state, $ionicPopup, $http, $cordovaNetwork, $ionicModal, $cordovaSQLite, $rootScope, $ionicScrollDelegate) {
            var after = 0;

            $ionicModal.fromTemplateUrl('partials/setting/modalImageView.html', {
                scope: $scope,
                animation: 'scale-in'
            }).then(function (modal) {
                $scope.modal = modal;
            });

            $scope.$on('$destroy', function () {
                $scope.modal.remove();

            });
            $scope.closeModal = function () {
                $scope.imageShow = null;
                $scope.modal.hide();
            };
            $scope.openModal = function (image) {
                $scope.imageShow = image;
                $scope.modal.show();
            };
            $scope.backtoGallery = function () {
                $state.go('gallery');
            };

            $scope.showMessage = "اطلاعاتی جهت نمایش موجود نمی باشد";
            $scope.idImage = [];
            $scope.items = [];
            $scope.loadMore = function () {
                if ($scope.busyScroll)
                {
                    return false;
                }

                $scope.busyScroll = true;

                var url = BaseUrl + "/galleries/";
                url += idGallery + "/" + after + "/8/id/desc/show";

                $http.get(url).success(function (data) {
                    var iCount = data.length;
                    if (iCount > 0)
                    {
                        for (var i = 0; i < iCount; i++) {
                            $scope.idImage[data[i].id] = after;
                            $scope.items.push(data[i]);
                            after++;
                        }
                        //console.log($scope.items);
                        if (iCount === 8)
                            $scope.busyScroll = false;
                    }

                    $scope.$broadcast('scroll.infiniteScrollComplete');
                });
                $scope.$on('$stateChangeSuccess', function () {
                    $scope.loadMore();
                });
            };
//            $scope.zoomImage = function () {
//                // e.target.classList.add('scale-Zoom');
//                $ionicScrollDelegate.$getByHandle('imageZoomer').zoomBy(2, true);
//
//            };
//            
//            $scope.scrollMainToTop = function () {
//                $ionicScrollDelegate.$getByHandle('main').scrollTop();
//            };

//            $scope.zoomX = function (xZoom) {
//                var element = document.getElementById('imgZoom');
//                switch (xZoom) {
//                    case 1:
//                        element.classList.remove('scale-Zoom-2X');
//                        element.classList.remove('scale-Zoom-4X');
//                        element.classList.add('scale-Zoom');
//                        $ionicScrollDelegate.$getByHandle('imageZoomer').zoomBy(1, true);
//                        break;
//                    case 2:
//                        element.classList.remove('scale-Zoom');
//                        element.classList.remove('scale-Zoom-4X');
//                        element.classList.add('scale-Zoom-2X');
//                        $ionicScrollDelegate.$getByHandle('imageZoomer').zoomBy(2, true);
//                        break;
//                    case 4:
//                        element.classList.remove('scale-Zoom-2X');
//                        element.classList.remove('scale-Zoom');
//                        element.classList.add('scale-Zoom-4X');
//                        $ionicScrollDelegate.$getByHandle('imageZoomer').zoomBy(4, true);
//                        break;
//                }
//
//
//
//            };
        });

angular.module('app.directive', [])
        .directive('darashNavView', function ($rootScope) {
            return{
                restrice: 'E',
                templateUrl: 'partials/homePage.html'
            };
        })
        .directive('ionMenu', function () {
            return{
                restrice: 'E',
                templateUrl: 'partials/menu.html'
            };
        })
        .directive('ionMap', function ($location, $compile, $ionicLoading, $ionicPopup) {
            return{
                restrice: 'E',
                template: '<div id="map" data-tap-disabled="true" style="width:100%;height:70vh;display:inline-block"></div>',
                replace: true,
                required: 'ngClick',
                link: function ($scope, elm, attr) {

                    $ionicLoading.show({
                        template: '<ion-spinner icon="ios" ></ion-spinner>'
                    });
                    $scope.showAlert = function (str) {
                        var alertPopup = $ionicPopup.alert({
                            title: 'هشدار',
                            template: "<div style='direction:rtl;text-align:right'>" + str + "</div>",
                            buttons: [{// Array[Object] (optional). Buttons to place in the popup footer.
                                    text: 'تایید',
                                    type: 'button-default btn-submit'
                                }]
                        });
                    };
                    var map;
                    function initialize() {

                        var myLatlng = new google.maps.LatLng(35.758873, 51.313967);
                        var mapOptions = {
                            center: myLatlng,
                            zoom: 16,
                            mapTypeId: google.maps.MapTypeId.ROADMAP
                        };
                        var map = new google.maps.Map(elm[0], mapOptions);
                        //Marker + infowindow + angularjs compiled ng-click
                        var contentString = "<div style='color:#000;text-align:right;direction:rtl'><img src='img/aban.JPG' /><br/>تلفن: <a style='color:#000;' hrerf='tel:021 4462 3063'>021 4462 3063</a></div>";
                        var compiled = $compile(contentString)($scope);
                        var infowindow = new google.maps.InfoWindow({
                            content: compiled[0]
                        });
                        var marker = new google.maps.Marker({
                            position: myLatlng,
                            map: map,
                            icon: 'img/marker.png',
                            animation: google.maps.Animation.BOUNCE
                        });
                        marker.setTitle('کلینیک دامپزشکی آبان');
                        google.maps.event.addListener(marker, 'click', function () {
                            infowindow.open(map, marker);
                        });
                        $scope.map = map;
                        google.maps.event.addListenerOnce(map, 'idle', function () {
                            $ionicLoading.hide();
                        });
                    }

                    $scope.centerOnMe = function () {
                        if (!$scope.map) {
                            return;
                        }
                    };
                    function loadScript(url, callback)
                    {
                        // Adding the script tag to the head as suggested before
                        var head = document.getElementsByTagName('head')[0];
                        var script = document.createElement('script');
                        script.type = 'text/javascript';
                        script.src = url;
                        // Then bind the event to the callback function.
                        // There are several events for cross browser compatibility.
                        script.onreadystatechange = callback;
                        script.onload = callback;
                        // Fire the loading
                        head.appendChild(script);

                    }
                    loadScript("http://maps.googleapis.com/maps/api/js?key=AIzaSyB6BRl6KQbNAOr2rERIIUZf2sMMmYoshhw", loadMap);
                    function loadMap() {

                        google.maps.event.addDomListener(window, 'load', initialize);
                        initialize();
                    }
                    $scope.backToContact = function () {
                        $location.path('#/contact');
                    };
                }
            };
        })
        .directive('loading', ['$http', function ($http) {
                return {
                    restrict: 'A',
                    controller: function ($scope, $ionicLoading)
                    {
                        $scope.isLoading = function () {
                            return $http.pendingRequests.length > 0;
                        };
                        $scope.$watch($scope.isLoading, function (v)
                        {
                            if (v) {
                                $scope.show();
                            } else {
                                $scope.hide();
                            }
                        });
                        $scope.show = function () {
                            $ionicLoading.show({
                                template: '<ion-spinner icon="ios" ></ion-spinner>'
                            });
                        };
                        $scope.hide = function () {
                            $ionicLoading.hide();
                        };
                    }
                };
            }])
        .filter('Rial', function () {
            return function (dateString) {
                return dateString + 'ريال';
            };
        })
        .filter('ConvertedToDateShamsi', function () {
            return function (dateString) {
                if (dateString != null)
                {
                    return moment(dateString, 'YYYY-M-D HH:mm:ss').format('jYYYY/jM/jD');
                } else {
                    return "تاریخ ندارد";
                }
            };
        })
        .filter('cut', function () {
            return function (value, wordwise, max, tail) {
                if (!value)
                    return '';
                max = parseInt(max, 10);
                if (!max)
                    return value;
                if (value.length <= max)
                    return value;
                value = value.substr(0, max);
                if (wordwise) {
                    var lastspace = value.lastIndexOf(' ');
                    if (lastspace != -1) {
                        value = value.substr(0, lastspace);
                    }
                }
                return value + (tail || ' …');
            };
        })
        /// persian mony for currency in tables
        .filter('monyCurrency', function () {
            return function (moneyText) {
                moneyText = String(moneyText);
                if (!moneyText) {
                    return '0';
                }
                var separator = ",";
                var int = moneyText.replace(new RegExp(separator, "g"), "");
                var regexp = new RegExp("\\B(\\d{3})(" + separator + "|$)");
                do
                {
                    int = int.replace(regexp, separator + "$1");
                } while (int.search(regexp) >= 0)
                return int + ' ريال';
            };
        });
 